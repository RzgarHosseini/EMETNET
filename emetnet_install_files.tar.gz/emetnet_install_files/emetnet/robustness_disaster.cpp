//This script calculates robustness of the networks

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include "enet.h"
#include "esolver.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <eutils/eregexp.h>
#include <fstream>
#include <iomanip>
#include "erandomwalk.h"
#include <istream>
#include <iostream>
#include <iterator>
#include <signal.h>
#include <eutils/estrarrayof.h>
using namespace std;

enet net;
int num=0;

estr getFilename(const estr& str)
{
  estr tmpstr;
  eregexp re("[^/.]+\\.[^.]+$");
  tmpstr=re_match(str,re);
  eregexp re2("^[^/.]+");
  tmpstr=re_match(tmpstr,re2);
  return(tmpstr);
}

int emain()
{
  ldieif (argvc<4,"syntax: ./robustness_disaster <size.dat>  <universe.net> <environment.flx> --num");  
  estr solver="esolver_clp";
  estr sizestr=argv[1];
/*  estr snum=argv[6];
  estrarray partizan=snum.explode(" ");

  int num=0;
  num=partizan[0].i();
*/
  int internal_secretion=0;

  epregister(solver);
  epregister(num);
  epregister(internal_secretion);
  eparseArgs(argvc,argv);

  net.load(argv[2]);
  net.correct_malformed();

//  cout << "# solver: "<<solver<<endl;
//  cout << "# internal_secretion: "<<internal_secretion<<endl;
  erandomWalk rw(net,solver,0);

  rw.internal_secretion=internal_secretion;

  int i;
  rw.getEnv(argvc,argv);
	rw.load(net);
  rw.calcPhenotype();

	estr str;
  estr test=sizestr+"-rr";
	estrarray parts;
	efile fu;
  efile files;
	fu.open(argv[1],"r");
  files.open(test,"w");
  int counted=1;

 
	while (fu.readln(str)) {			// While the file isn't finished, read line by line
    if (counted>num){
       parts=str.explode(" ");		// cut the string based on delimiter, here a space, and assign the resulting fields into an array called "parts"
       int startindex=26;
	     eintarray numarray, writearr;
	     int tmp = 0;
		   int totalsize = 51;
		   for (int i=0; i<parts.size(); ++i){      	
			     tmp = parts[i].i()+startindex;
			     rw.disable(tmp);
			     numarray.add(tmp);
			     --totalsize;
		      }
		   rw.calcPhenotype();
		   rw.viablePhenotype = rw.phenotype;

       int tmp3;
       int count=0;
       for (int i=1; i<46; ++i) {
           tmp3=(i+startindex);
           if (rw.genotype[tmp3]==1){	
        	     rw.disable(tmp3);
					     rw.calcPhenotype();
               if (rw.isViable()){
           	      count++;
               }
               else {                  
                      estr istr=(double) (tmp3+1);
                      files.write("#"+istr+"\n");
                    }
               rw.activate(tmp3);
           }
        } 
       eintarray tmparr;
       tmparr.add(count);
       estr intstr=intarr2str2(tmparr);

       files.write(intstr+"\n");
       
		   for (int i=0; i<numarray.size(); ++i){
			     rw.activate(numarray[i]);
    		} 
     }

    counted++;
	}

	fu.close();
  files.close();
	return(0);
}
