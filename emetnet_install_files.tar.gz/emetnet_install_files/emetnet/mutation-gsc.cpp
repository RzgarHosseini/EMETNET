#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>

estr solver="esolver_clp";
int netsize=-1;
int strict=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
double gendist=0.0;
enet net;
//erandomWalk *prw=0x00;

int num1=0; //number of reactions in the parental genome
int num2=0; //number of loss of function mutations
int num3=0; //number of gain of function mutations
estr outnet="out.net";

int emain()
{ ldieif(argvc<4,"syntax: ./mutation-gsc <universe.net> <file.dat> [--outnet out.dat] --num1 --num2 --num3 <fluxbounds.flx>");  
  epregister(num1);
  epregister(num2);
  epregister(num3);
  epregister(outnet);
  eparseArgs(argvc,argv);
  //////////////////////////////////////////////////////////// Genotyping ////////////////////////////////////////////////////
  enet net;
  net.load(argv[1]);
  net.correct_malformed();
  erandomWalk rw(net,solver,strict);
  //prw=&rw; 
  rw.internal_secretion=internal_secretion;
  rw.getEnv(argvc,argv);
	rw.load(net);
  rw.calcPhenotype();
  efile fu;
	fu.open(argv[2],"r");
  estr sttr;
  estrarray parts;
  efile fw1;
  fw1.open(outnet,"a");
  estr outnet2=outnet+"_phenotype";
  efile fw2;
  fw2.open(outnet2,"a");
  double ccount=0;
	while (fu.readln(sttr)) {
        ccount=ccount+1;
        parts=sttr.explode(" ");
        eintarray gen;
        int tmp=0;
        for (int i=0;i<6588;i++){gen.add(tmp);}
        for (int i=0;i<6588;i++){gen[i]=parts[i].i();}
        cout<<intarr2str2(gen)<<endl;
        //////////////////////////// Reactions to be deleted /////////////////////////////   
        eintarray pop;
        for (int i=682; i<6588; ++i) {
            if (gen[i]==1){pop.add(i);}
        }
        int tmp1; 
        for (int i=(num1-682); i>=0; --i) {
            int r = (int)(ernd.uniform()*i);
            tmp1 = pop[r];
            pop[r] = pop[i];
            pop[i]=tmp1;
        }

        eintarray pop1;
        for (int j=0;j<num2;j++){
            int x=pop[j];
            pop1.add(x);
        }
        eintarray sorted1=sort(pop1);
        eintarray selected1;
       for (int j=0;j<num2;j++){
           int y=sorted1[j];
           selected1.add(pop1[y]);
       }
       selected1.add(0);
       /////////////////////////////////// Reactions to be added ///////////////////////////
       if (num3>0){
          eintarray popp;
          for (int i=682; i<6588; ++i) {
               if (gen[i]==0){popp.add(i);}
          }
 
          for (int i=(6588-num1); i>=0; --i) {
              int r = (int)(ernd.uniform()*i);
              tmp1 = popp[r];
              popp[r] = popp[i];
              popp[i]=tmp1;
          }
       
          eintarray pop2;
          for (int j=0;j<num3;j++){
              int x=popp[j];
              pop2.add(x);
          }
          eintarray sorted2=sort(pop2);
          eintarray selected2;
          for (int j=0;j<num3;j++){
              int y=sorted2[j];
              selected2.add(pop2[y]);
          }
          
          selected2.add(0);

          int count1=0;
          int count2=0;
          for (int i=0;i<6588;i++){
              if (gen[i]==1){ 
                  if (selected1[count1]==i){gen[i]=0;count1++;}
                  else {}
              }
              else if (gen[i]==0) {
                   if (selected2[count2]==i){gen[i]=1;count2++;}
                   else {}
              }
              else {}
          }
       }
       else {
          int count1=0;
          for (int i=0;i<6588;i++){
              if (gen[i]==1){ 
                  if (selected1[count1]==i){gen[i]=0;count1++;}
                  else {}
              }
              else {}
          }
       }

       /////////////////////////////////////// Mutation /////////////////////////////////
       cout<<intarr2str2(gen)<<endl;
       estr intstr1=intarr2str2(gen);
       fw1.write(intstr1+"\n");

       /////////////////////////////// Phenotyping //////////////////////////////////
       for (int i=0;i<6588;i++){if (gen[i]==0){rw.disable(i);}}
       rw.calcPhenotype();
       eintarray phen = rw.phenotype;
       estr intstr2 = intarr2str2(phen);
       fw2.write(intstr2+"\n");
       for (int i=0;i<6588;i++){if (gen[i]==0){rw.activate(i);}}
  }
  fw1.close();
  fw2.close();
  return(0);
}
  


  




