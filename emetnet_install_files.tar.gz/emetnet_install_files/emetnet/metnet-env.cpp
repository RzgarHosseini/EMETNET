
#include "enet.h"
#include "esolver.h"
//#include "esolver_clp.h"
//#include "esolver_cplex.h"

#include <eutils/emain.h>
#include <eutils/estrarray.h>

#include <fstream>
#include <iomanip>

#include "erandomwalk.h"

enet net;
//esolver_cplex solver_cplex;
//esolver_clp   solver_clp;


int emain()
{
  ldieif (argvc<2,"syntax: ./metnet-opt [-solver <clp|cplex>] <metabolic.net> <environment.flx> <metabolite.lst>");  

  estrarray metabolites;
 
  estr solver="cplex";
  epregister(solver);

  net.load(argv[1]);
  net.correct_malformed();

  cout << "# Using solver: "<<solver<<endl;
  erandomWalk rw(net,solver,1);

  int i,transport_count;
  transport_count=0;
  for (i=0; i<net.links.size(); ++i){
    if (net.links[i].transport)
      ++transport_count;
  }
  cout << " Total reactions: "<<net.links.size()-1<<endl;
  cout << " Transport reactions: "<<transport_count<<endl;

  rw.addEnv(argv[2]);

  metabolites.load(argv[3]);
  

  rw.calcPhenotype();

  for (i=0; i<metabolites.size(); ++i){
    if (net.nodes.findkey(metabolites[i])!=-1){
      rw.solvers.at(0).setybounds( net.nodes[metabolites[i]].i ,-10.0,0.0);
      rw.calcPhenotype();
      cout << metabolites[i]<<": "<< rw.growthRate[0] << endl;
      rw.solvers.at(0).setybounds(net.nodes[metabolites[i]].i,0.0,10.0);
    }
    else
      cout << metabolites[i]<<": not found in network!" << endl;
  }

//  for (i=0; i<rw.phenotype.size(); ++i){
//    cout << i<<": "<< rw.growthRate[i] << endl;
//  }

  return(0);
}
