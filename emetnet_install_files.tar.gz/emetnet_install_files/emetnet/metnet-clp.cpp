
#include "enet.h"
#include "esolver.h"

#include <eutils/emain.h>
#include <eutils/eregexp.h>

#include <fstream>
#include <iomanip>
#include "erandomwalk.h"

enet net;

estr getFilename(const estr& str)
{
  estr tmpstr;
  eregexp re("[^/.]+\\.[^.]+$");
  tmpstr=re_match(str,re);
  eregexp re2("^[^/.]+");
  tmpstr=re_match(tmpstr,re2);
  return(tmpstr);
}

int emain()
{
  ldieif (argvc<2,"syntax: ./metnet-clp [-solver <clp|cplex>] <metabolic.net> <environment.flx>");  
  
  estr fluxnet;
  estr solver="esolver_clp";
  int internal_secretion=0;

  epregister(solver);
  epregister(fluxnet);
  epregister(internal_secretion);
  eparseArgs(argvc,argv);

  net.load(argv[1]);
  net.correct_malformed();

//  cout << "# solver: "<<solver<<endl;
//  cout << "# internal_secretion: "<<internal_secretion<<endl;
  erandomWalk rw(net,solver,0);

  rw.internal_secretion=internal_secretion;

  int i,transport_count;
  transport_count=0;
  for (i=0; i<net.links.size(); ++i){
    if (net.links[i].transport)
      ++transport_count;
  }

  rw.getEnv(argvc,argv);
  rw.calcPhenotype();

  cout << "# network: "<<argv[1]<<endl;
  cout << "# total reactions: "<<net.links.size()-1<<endl;
  cout << "# transport reactions: "<<transport_count<<endl;

  bool phetarget=false;
  if (net.info.findkey("phetarget")!=-1){
    phetarget=true;
    str2intarr(net.info["phetarget"].substr(4),rw.viablePhenotype);
//    cout << "# using phetarget from initial network file!"<<endl;
  }

  for (i=0; i<rw.phenotype.size(); ++i){
    cout << efile(rw.solvers.keys(i)).basename() <<": "<< rw.growthRate[i] << " " << (phetarget && rw.viablePhenotype[i]==1 ? "*" : "") << endl;
  }


  int j;
  for (i=0; i<rw.solvers.size(); ++i){
    if (fabs(rw.growthRate[i])<=1.0e-3) continue;
    for (j=0; j<net.links.size(); ++j){
        if (fabs(rw.solvers.at(i).x[j])>1.0e-5){
        net.links[j].info.add(getFilename(rw.solvers.keys(i)),rw.solvers.at(i).x[j]);
      }
    }
  }

//  cout << "# checking that all internal metabolites used can be produced by the metabolic network:" << endl; 
//  if (rw.checkIntViability(0)) cout << "yes" << endl; else cout << "no" << endl;

  if (fluxnet.len())
    net.saveactive(fluxnet);

  return(0);
}
