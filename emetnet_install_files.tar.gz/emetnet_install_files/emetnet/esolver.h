#ifndef ESOLVER_H
#define ESOLVER_H

#include "enet.h"
#include <eutils/ematrix.h>
#include <eutils/evar.h>

#define MAXFLUX 1.0e20

class esolver
{
 public:
  enet* net;

  double   *x;
  double   *y;


  bool internal_secretion;

  earrayof<evector2,estr> fluxbounds;

  esolver();
  virtual ~esolver();

  double MMAXFLUX;

  virtual bool isAvailable();


  bool fluxVar(int ind,double& min,double& max);


  void load_fluxbounds(const estr& file="fluxbounds.flx");
  
  virtual void setobjective(int i,double value=1.0)=0;
  virtual void setobjective(evector& obj)=0;

  virtual void setxbounds(int i,double min,double max)=0;
  virtual void setybounds(int i,double min,double max)=0;

  void resetNodeBounds(const estr& node);
  void setNodeBounds(const estr& node,float lbound,float ubound);

  void setReactionBounds(const estr& reaction,float lbound,float ubound);

  virtual void parse(ematrix& m,evector& lower,evector& upper,evector& xlower,evector& xupper,evector& objective)=0;
  virtual void parse(enet& net)=0;
  virtual double solve()=0;

  virtual void activate(int i)=0;
  virtual void disable(int i)=0;

  virtual void setActive(const eintarray& arr)=0;
};

/*
#include <eutils/estrarrayof.h>

template <class S,class T>
S *newObject(){ return(new T); }

template <class T>
class eregisterClasses
{
 public:
  estrarrayof< T*(*)() > classes;
  eregisterClasses(void (*)(eregisterClasses<T>&));

  void registerClass(const estr& name,T *(*func_newClass)());
  T *newClass(const estr& name);
};

template <class T>
eregisterClasses<T>::eregisterClasses(void (*func_register)(eregisterClasses<T>&)){ func_register(*this); }

template <class T>
void eregisterClasses<T>::registerClass(const estr& name,T *(*func_newClass)())
{
  classes.add(name,func_newClass);
}

template <class T>
T *eregisterClasses<T>::newClass(const estr& name)
{
  if (classes.findkey(name)!=-1)
    return(classes[name]());

  lwarn("class not found: "+name);
  return(0x00);
}

extern eregisterClasses<esolver> solverClasses;
*/

esolver *getSolver(const estr& solvername);

#endif

