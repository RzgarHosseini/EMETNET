#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>

estr solver="esolver_clp";

int strict=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
enet net;
erandomWalk *prw=0x00;

int num1=0; //number of reactions in the parental networks
double num2=0.0; //genotypic distance between parental genotypes
double num3=0.0; //number of exchanged reactions
estr outnet="out.net";


int emain()
{ ldieif(argvc<4,"syntax: ./sampling_phenotypedist <universe.net> <file.dat> --outnet --num1 --num2 --num3 <fluxbounds.flx>");  
  epregister(num1);
  epregister(num2);
  epregister(num3);

  epregister(outnet);
  eparseArgs(argvc,argv);
  epregister(solver);
  epregister(strict);
  epregister(periphery_only);
  epregister(mutate_transport);
  epregister(internal_secretion);
  epregister(only_viable);
  int netsize=num1-1;  

  //////////////////////////////////////////////////////////// Genotyping ////////////////////////////////////////////////////
  //////////////////////
  cout<<"alaki1"<<endl;
  //////////////////////
  enet net;
  net.load(argv[1]);
  net.correct_malformed();
  erandomWalk rw(net,solver,strict);
  prw=&rw; 
  rw.periphery_only=periphery_only;
  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;
  rw.only_viable=only_viable;
  rw.getEnv(argvc,argv);
  rw.load(net);  
  net.correct_malformed();
  rw.calcPhenotype();
  efile fu;
  fu.open(argv[2],"r");
  efile fw;
  fw.open(outnet,"a");
  estr sttr;
  estr outnet2=outnet+"_phen";
  efile fw2;
  fw2.open(outnet2,"a");
  //////////////////////
  cout<<"alaki2"<<endl;
  //////////////////////
  while (fu.readln(sttr)) {
        //////////////////////
        cout<<"alaki3"<<endl;
        //////////////////////
	estrarray parts;
        parts=sttr.explode(" ");
        eintarray gen1;
        eintarray gen2;
        int tmp=0;
        for (int i=0;i<6588;i++){gen1.add(tmp);}
        for (int i=0;i<6588;i++){gen1[i]=parts[i].i();}
	enet net2=net;
	rw.load(net2);
        for (int i=0;i<6588;i++){if (gen1[i]==0){rw.disable(i);}}
        rw.periphery_only=periphery_only;
        rw.mutate_transport=mutate_transport;
        rw.internal_secretion=internal_secretion;
        rw.only_viable=only_viable;
        rw.setRSize(netsize);
        rw.calcPhenotype(); 
        eintarray phen1=rw.phenotype;
        eintarray temparr;
        for (int i=0;i<50;i++){temparr.add(tmp);}
        //////////////////////
        cout<<"alaki4"<<endl;
        //////////////////////
        rw.viablePhenotype=temparr;
        if (net2.info.findkey("phetarget")!=-1){
            net.info.add("phetarget",net2.info["phetarget"]);
            str2intarr(net2.info["phetarget"],rw.viablePhenotype);
            cout << "# using phetarget from initial network file!"<<endl;
        }
        //////////////////////
        cout<<"alaki5"<<endl;
        //////////////////////
        int id=0;
        eintarray tempofen;
        eintarray phen2;
        for (int mm=0;mm<100;mm++) {
            cout<<"alaki11"<<endl;
            for (int i=0;i<6588;i++){if (gen1[i]==0){rw.disable(i);}}
            cout<<"alaki12"<<endl;
            rw.run_dist3(net2,(num2*2),num3);
            cout<<"alaki13"<<endl;
            rw.calcPhenotype();
            cout<<"alaki14"<<endl;
            tempofen=rw.phenotype;
            cout<<"alaki15"<<endl;
            int phenodist=gendistance2(phen1,tempofen,&rw);
            cout<<"alaki16"<<endl;
            if (phenodist==num3){id=1;gen2=rw.genotype;phen2=rw.phenotype;break;}
            cout<<"alaki17"<<endl;
            for (int i=0;i<6588;i++){rw.activate(i);}
            cout<<"alaki18"<<endl;
        }

        //////////////////////
        cout<<"alaki6"<<endl;
        //////////////////////
        
        if (id==1) {
           fw2.write(intarr2str2(phen1)+"\n");
           fw2.write(intarr2str2(phen2)+"\n");
           fw.write(intarr2str2(gen2)+"\n");
        }
        else {
           fw2.write("#NNN#\n");
           fw.write("#NNN#\n");        
        }
    }
       //////////////////////

       //////////////////////
       fw.close();
       fw2.close();
       return(0);
}


