#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>
#include <math.h>
///////////////////////////////////////////////////////////////
estr solver="esolver_clp";
int netsize=-1;
int strict=0;
int force_away=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
int niter=100;
enet net;
enet net1;
enet net2;
double final_dist=0.0;
////////////////////////////////////////////////////////////////
erandomWalk *prw=0x00;
////////////////////////////////////////////////////////////////
int emain()
{ ldieif(argvc<5,"syntax: ./metropolis2  <kegg.net> <genotype1.net> <genotype2.net> <outnet.dat> --final_dist  <fluxbounds.flx>");

  epregister(final_dist);
  epregister(solver);
  epregister(netsize);
  epregister(strict);
  epregister(force_away);
  epregister(periphery_only);
  epregister(mutate_transport);
  epregister(internal_secretion);
  epregister(only_viable);
  epregister(niter);
  eparseArgs(argvc,argv);

  net.load(argv[1]); 
  net1.load(argv[2]); 
  net2.load(argv[3]); 

  erandomWalk rw(net,solver,strict);
  prw=&rw; 

  rw.periphery_only=periphery_only;
  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;
  rw.only_viable=only_viable;
  rw.setRSize(netsize);
  rw.getEnv(argvc,argv);

  rw.load(net1);
  rw.calcPhenotype();
  rw.viablePhenotype=rw.phenotype;
  rw.run(net1,niter);
  
  int i=0; 

  eintarray gen1=rw.genotype;
  eintarray GEN1=gen1; 

  net.load(argv[1]);
  rw.load(net2);
  rw.calcPhenotype();
  rw.run(net2,niter);

  eintarray gen2=rw.genotype;
  eintarray GEN2=gen2; 


  double gendist=gendistance2(gen1,gen2,&rw);
  estr sgendist=gendist;
  cout<<"###############################################################"<<endl;
  cout<<"Initial distance: "<<sgendist<<endl;
  cout<<"###############################################################"<<endl;

  double dist_new=10000.0;
  double dist_old=0.0;

  int present1_size=0;
  int present2_size=0;
  int absent1_size=0;
  int absent2_size=0;

  int gen1_present[6588];for (int i=0;i<6588;i++){gen1_present[i]=0;}
  int gen2_present[6588];for (int i=0;i<6588;i++){gen2_present[i]=0;}
  int gen1_absent[6588]; for (int i=0;i<6588;i++){gen1_absent[i]=0;}
  int gen2_absent[6588]; for (int i=0;i<6588;i++){gen2_absent[i]=0;}

  int d1=0;
  int d2=0;

  int to_delete1=0;
  int to_add1=0;
  int to_delete2=0;
  int to_add2=0;
  int terminator=0;
    
  net.load(argv[1]);
  rw.load(net);

  while (terminator==0) {

        present1_size=0;
        present2_size=0;
        absent1_size=0;
        absent2_size=0;

        for (i=0;i<6588;i++){
             //if (gen1[i]==1&&gen2[i]==0){gen1_present[present1_size]=i;present1_size++;}
             //if (gen1[i]==0&&gen2[i]==1){gen2_present[present2_size]=i;present2_size++;}

             if (gen1[i]==1){gen1_present[present1_size]=i;present1_size++;}
             if (gen2[i]==1){gen2_present[present2_size]=i;present2_size++;}

             if (gen1[i]==0){gen1_absent[absent1_size]=i;absent1_size++;} //
             if (gen2[i]==0){gen2_absent[absent2_size]=i;absent2_size++;} //
        }

        cout<<"###############################################################"<<endl;
        cout<<(double) present1_size <<endl;
        cout<<"###############################################################"<<endl;
        cout<<"###############################################################"<<endl;
        cout<<(double) present2_size <<endl;
        cout<<"###############################################################"<<endl;
        cout<<"###############################################################"<<endl;
        cout<<(double) absent1_size <<endl;
        cout<<"###############################################################"<<endl;
        cout<<"###############################################################"<<endl;
        cout<<(double) absent2_size <<endl;
        cout<<"###############################################################"<<endl;
        cout<<"###############################################################"<<endl;
        cout<<(double) gen1.size() <<endl;
        cout<<"###############################################################"<<endl;
        cout<<"###############################################################"<<endl;
        cout<<(double) gen2.size() <<endl;
        cout<<"###############################################################"<<endl;

        dist_old=gendistance2(gen1,gen2,&rw);
        cout<<"###############################################################"<<endl;
        cout<<"Old: "<<dist_old<<endl;
        cout<<"###############################################################"<<endl;
        d1=0;
        to_delete1=0;
        to_add1=0;
        to_delete2=0;
        to_add2=0;

        GEN1=gen1;
        GEN2=gen2;

        while (d1==0){
              cout<<"***********************"<<endl;
              //for (i=0;i<6588;i++){
                   //if (gen1[i]==1&&gen2[i]==0){gen1_present[present1_size]=i;present1_size++;}
                   //if (gen1[i]==0&&gen2[i]==1){gen2_present[present2_size]=i;present2_size++;}
                   //if (gen1[i]==1){gen1_present[present1_size]=i;present1_size++;}
                   //if (gen2[i]==1){gen2_present[present2_size]=i;present2_size++;}
                   //if (gen1[i]==0){gen1_absent[absent1_size]=i;absent1_size++;} //
                   //if (gen2[i]==0){gen2_absent[absent2_size]=i;absent2_size++;} //
              //}
               int dd1=0;
               to_delete1=(int)(ernd.uniform()*present1_size);
               to_add1=(int)(ernd.uniform()*absent1_size); //
               gen1[(gen1_present[to_delete1])]=0;
               gen1[(gen1_absent[to_add1])]=1; //
               ///////////////////////////////////////////////////////
               dist_new=gendistance2(gen1,gen2,&rw);
               ///////////////////////////////////////////////////////
               if (dist_new>final_dist) {
                   if (dist_new>dist_old){
                       double expected=(exp(-(dist_new-final_dist)));
                       double observed=ernd.uniform();
                       if (observed>expected){gen1=GEN1;}
                       else {dd1=1;}
                   }
                   else {dd1=1;}
               }
               else if (dist_new<final_dist){
                        if (dist_new<dist_old){gen1=GEN1;}
                        else {dd1=1;}
               }
               else if (dist_new==final_dist){dd1=1;}
               else {}
               ////////////////////////////////////////////////////////
               if (dd1==1){
                   for (i=0;i<6588;i++){if (gen1[i]==0){rw.disable(i);}}
                   rw.calcPhenotype();
                   eintarray phen1=rw.phenotype;
                   if (rw.isViable()){d1=1;}
                   else {gen1=GEN1;}
                   for (i=0;i<6588;i++){rw.activate(i);}
               }
         }
         ///////////////////////////////////////////////////////
         dist_new=gendistance2(gen1,gen2,&rw);
         ///////////////////////////////////////////////////////
         cout<<"###############################################################"<<endl;
         cout<<"New: "<<dist_new<<endl;
         cout<<"###############################################################"<<endl;
         if (dist_new==final_dist){terminator=1;break;}
         d2=0;      
         while (d2==0){
              cout<<"++++++++++++++++++++++++++++++++++"<<endl;
               //for (i=0;i<6588;i++){
                    //if (gen1[i]==1&&gen2[i]==0){gen1_present[present1_size]=i;present1_size++;}
                    //if (gen1[i]==0&&gen2[i]==1){gen2_present[present2_size]=i;present2_size++;}

                    //if (gen1[i]==1){gen1_present[present1_size]=i;present1_size++;}
                    //if (gen2[i]==1){gen2_present[present2_size]=i;present2_size++;}

                    //if (gen1[i]==0){gen1_absent[absent1_size]=i;absent1_size++;} //
                    //if (gen2[i]==0){gen2_absent[absent2_size]=i;absent2_size++;} //
              // }
               int dd2=0;
               to_delete2=(int)(ernd.uniform()*present2_size);
               to_add2=(int)(ernd.uniform()*absent2_size); //
               gen2[(gen2_present[to_delete2])]=0;
               gen2[(gen2_absent[to_add2])]=1; //               
               ///////////////////////////////////////////////////////
               dist_new=gendistance2(gen1,gen2,&rw);
               ///////////////////////////////////////////////////////
               if (dist_new>final_dist) {
                   if (dist_new>dist_old){
                       double expected=(exp(-(dist_new-final_dist)));
                       double observed=ernd.uniform();
                       if (observed>expected){gen2=GEN2;}
                       else {dd2=1;}
                   }
                   else {dd2=1;}
               }
               else if (dist_new<final_dist){
                        if (dist_new<dist_old){gen2=GEN2;}
                        else {dd2=1;}
               }
               else if (dist_new==final_dist){dd2=1;}
               else {}
               ////////////////////////////////////////////////////////
               if (dd2==1){
                   for (i=0;i<6588;i++){if (gen2[i]==0){rw.disable(i);}}
                   rw.calcPhenotype();
                   eintarray phen2=rw.phenotype;
                   if (rw.isViable()){d2=1;}
                   else {gen2=GEN2;}
                   for (i=0;i<6588;i++){rw.activate(i);}
               }
         }
         if (dist_new==final_dist){terminator=1;break;}
         ///////////////////////////////////////////////////////
         dist_new=gendistance2(gen1,gen2,&rw);
         ///////////////////////////////////////////////////////
         cout<<"###############################################################"<<endl;
         cout<<"New: "<<dist_new<<endl;
         cout<<"###############################################################"<<endl;
         int modali =(int) dist_new;
         if (modali%2!=0){
                          cout<<"###############################################################"<<endl;
                          cout<<intarr2str2(gen1)<<endl;
                          cout<<"###############################################################"<<endl;
                          cout<<intarr2str2(gen2)<<endl;
                          cout<<"###############################################################"<<endl;
                         }
         }

  estr outnet=argv[4];
  estr outnet1=outnet+"_1";
  estr outnet2=outnet+"_2";
  cout<<outnet1<<endl;
  cout<<outnet2<<endl;

  efile fw1;
  efile fw2;

  fw1.open(outnet1,"w");
  fw2.open(outnet2,"w");

  fw1.write(intarr2str2(gen1)+"\n");
  fw2.write(intarr2str2(gen2)+"\n");
  
  fw1.close();
  fw2.close();

  return(0);
}
