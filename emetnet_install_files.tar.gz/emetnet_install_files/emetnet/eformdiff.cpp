#include "eformula.h"

#include <eutils/ecsv.h>
#include <eutils/emain.h>



int main()
{
  etable res;
  ecsv csv;

  csv.load("translation_formulas.csv");

  estrarray stra;
  eformula f1,f2;
  int i;
  res.setfields("entry,name,balanced,formula,molecular_formula,diff");
  for (i=0; i<csv.size(); ++i){
    stra.clear();
    f1=csv[i]["formula"];
    f2=csv[i]["molecular_formula"];
    stra=csv[i];
    stra["diff"] = (f1-f2).str();
    if (f1==f2) stra["balanced"] = "yes";
    res.addrow(stra);
  }

  cout << res << endl;
  

}
