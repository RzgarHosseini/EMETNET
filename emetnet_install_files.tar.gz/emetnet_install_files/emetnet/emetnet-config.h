#ifndef _EMETNET_CONFIG_H
#define _EMETNET_CONFIG_H 1
 
/* emetnet-config.h. Generated automatically at end of configure. */
/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.in by autoheader.  */

/* Define to 1 if you have the `Clp -lCoinUtils' library (-lClp -lCoinUtils).
   */
#ifndef EMETNET_HAVE_LIBCLP__LCOINUTILS 
#define EMETNET_HAVE_LIBCLP__LCOINUTILS  1 
#endif

/* Define to 1 if you have the `eutils' library (-leutils). */
#ifndef EMETNET_HAVE_LIBEUTILS 
#define EMETNET_HAVE_LIBEUTILS  1 
#endif

/* Define to 1 if you have the `pthread' library (-lpthread). */
#ifndef EMETNET_HAVE_LIBPTHREAD 
#define EMETNET_HAVE_LIBPTHREAD  1 
#endif

/* Define to 1 if you have the `z' library (-lz). */
#ifndef EMETNET_HAVE_LIBZ 
#define EMETNET_HAVE_LIBZ  1 
#endif

/* Name of package */
#ifndef EMETNET_PACKAGE 
#define EMETNET_PACKAGE  "emetnet" 
#endif

/* Define to the address where bug reports for this package should be sent. */
#ifndef EMETNET_PACKAGE_BUGREPORT 
#define EMETNET_PACKAGE_BUGREPORT  "" 
#endif

/* Define to the full name of this package. */
#ifndef EMETNET_PACKAGE_NAME 
#define EMETNET_PACKAGE_NAME  "" 
#endif

/* Define to the full name and version of this package. */
#ifndef EMETNET_PACKAGE_STRING 
#define EMETNET_PACKAGE_STRING  "" 
#endif

/* Define to the one symbol short name of this package. */
#ifndef EMETNET_PACKAGE_TARNAME 
#define EMETNET_PACKAGE_TARNAME  "" 
#endif

/* Define to the home page for this package. */
#ifndef EMETNET_PACKAGE_URL 
#define EMETNET_PACKAGE_URL  "" 
#endif

/* Define to the version of this package. */
#ifndef EMETNET_PACKAGE_VERSION 
#define EMETNET_PACKAGE_VERSION  "" 
#endif

/* Version number of package */
#ifndef EMETNET_VERSION 
#define EMETNET_VERSION  "0.1" 
#endif
 
/* once: _EMETNET_CONFIG_H */
#endif
