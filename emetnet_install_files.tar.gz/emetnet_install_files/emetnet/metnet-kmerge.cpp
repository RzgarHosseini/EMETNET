#include "enet.h"
#include <eutils/emain.h>


#define MAX(a,b) (a>b?a:b)

void compareReactions(elink& ri,elink& rj)
{
  int matched,matched2;
  int k,l;

  matched=0;

  for (k=0; k<ri.src.size(); ++k){
    for (l=0; l<rj.src.size(); ++l){
      if (ri.src[k].node->id == rj.src[l].node->id)
        { ++matched; break; }
    }
  }
  for (k=0; k<ri.dst.size(); ++k){
    for (l=0; l<rj.dst.size(); ++l){
      if (ri.dst[k].node->id == rj.dst[l].node->id)
        { ++matched; break; }
    }
  }

  matched2=0;

  for (k=0; k<ri.src.size(); ++k){
    for (l=0; l<rj.dst.size(); ++l){
      if (ri.src[k].node->id == rj.dst[l].node->id)
        { ++matched2; break; }
    }
  }
  for (k=0; k<ri.dst.size(); ++k){
    for (l=0; l<rj.src.size(); ++l){
      if (ri.dst[k].node->id == rj.src[l].node->id)
        { ++matched2; break; }
    }
  }

  if (!rj.irreversible) return;

  ri.irreversible=true;
  earray<elinkelem> tmpa;
  if (matched2 > matched){
    tmpa=ri.src;
    ri.src = ri.dst;
    ri.dst = tmpa;
  }
}

int main()
{
  ldieif (argvc<3,"syntax: ./emetnet <file.net> <file2.net>");  

  enet net1;
  net1.load(argv[1]); 
  cout << "finished loading file: "<<argv[1] << endl;

  enet net2;
  net2.load(argv[2]);
  cout << "finished loading file: "<<argv[2] << endl;

  int i,j;


  for (i=0; i<net1.links.size(); ++i){
    for (j=0; j<net2.links.size(); ++j){
      if (!net1.links[i].info.size() || !net2.links[j].info.size())
        cout << "i: " +estr(i)+" ,j: "+estr(j)<<endl;
      if (net1.links[i].info[0] == net2.links[j].info[0]){
        compareReactions(net1.links[i],net2.links[j]);
        break;
      }
    }
  } 

  cout << net1 << endl;

  return(0);
}
