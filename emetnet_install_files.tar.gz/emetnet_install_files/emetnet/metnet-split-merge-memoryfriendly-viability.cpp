#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <stdio.h>
#include <stdlib.h>
/////////////////////////////////////////////////////////////////////////////////////////////////
estr solver="esolver_clp";
int netsize=-1;
int strict=0;
int force_away=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
int s1=0;//The index of the viable genotype in inputfile1
enet net;
/////////////////////////////////////////////////////////////////////////////////////////////////
erandomWalk *prw=0x00;
/////////////////////////////////////////////////////////////////////////////////////////////////
int emain() {

  ldieif(argvc<7,"syntax: metnet-split-merge-memoryfriendly-viability universe.net <inputfilename1.dat> <inputfilename2.dat> <outfilename> <env.flx> --s1 [>1] ");	
  epregister(solver);
  epregister(s1);
  eparseArgs(argvc,argv);

  net.load(argv[1]);//Loading the reaction universe (universe.net)
  efile file1;//The file containing the viable genotypes of a single block (inputfilename1.dat)
  efile file2;//The file containing the viable genotypes of a 4 merged block (inputfilename2.dat)
  efile fileout;//The outfile storing the viable genotypes after merging the block in inputfile1 and the merged blocks in inputfile2 

  file1.open(argv[2],"r");
  file2.open(argv[3],"r");
  fileout.open(argv[4],"w");

 	
  net.correct_malformed();
  erandomWalk rw(net,solver,strict);
  prw=&rw;
  rw.periphery_only=periphery_only;
  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;
  rw.only_viable=only_viable;
  rw.setRSize(netsize);

  rw.getEnv(argvc,argv);//getting the environment files and read them
  rw.load(net); // load network in object "net" into the erandomwalk 
  rw.calcPhenotype(); //calculate phenotype
  rw.viablePhenotype=rw.phenotype;//checking viability


  int viable2[45];
  int viable1[45];
  int i;
  int linecounter=0;
  estr str1;
  estr str2;
  estrarray parts;
  ////////////// Reading files /////////////////////////////////////////
  while (file1.readln(str1)) {//read inputfile1 
	 linecounter++;
         if (linecounter==s1){
	     parts=str1.explode(" ");
	     for (i=0; i<45; i++) {viable1[i]=0;}
             for (i=0; i<parts.size(); ++i) {viable1[i]=parts[i].i();}//storing the deleted reactions of the viable genotype of the inputfile1
         }
  }
  file1.close();
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////// Merging step //////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  while (file2.readln(str2)) {//read inputfile2 line by line
	 parts=str2.explode(" ");
	 for (i=0; i<45; i++) {viable2[i]=0;}
         for (i=0; i<parts.size(); ++i) {viable2[i]=parts[i].i();}//storing the deleted reactions of the viable genotypes of the inputfile2

         int temparray[90];
         for (int j=0;j<90;j++){temparray[j]=0;}
         int count=0;
         for (int j=0;j<45;j++){
              if (viable2[j]>0){int tmp=(viable2[j]+26);temparray[count]=tmp;count++;}
              if (viable1[j]>0){int tmp=(viable1[j]+26);temparray[count]=tmp;count++;}
         }
         eintarray finalarray;
         eintarray sortedindex;
         eintarray tmparr;
         for (int k=0;k<count;k++){finalarray.add(0);tmparr.add(0);}
         for (int k=0;k<count;k++){finalarray[k]=temparray[k];}
         for (int k=0;k<count;k++){rw.disable(finalarray[k]);}
         rw.calcPhenotype();
         if (rw.isViable()) {
	     sortedindex = sort(finalarray);// sort returns the sorted index list
	     for (int p=0;p<sortedindex.size();p++) {tmparr[p]=finalarray[sortedindex[p]];}
	     finalarray = tmparr;
             for (int q=0;q<tmparr.size();q++) {tmparr[q] -= 26;}
             estr zeroloc = intarr2str2(tmparr);
             fileout.write(zeroloc+"\n");
             cout<<zeroloc<<endl;
         }
         for (int n=0; n<finalarray.size(); ++n) {rw.activate(finalarray[n]);}
  }
  file2.close();
  fileout.close();
  return(0);
}
