//This script calculates waste exaptation
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include "enet.h"
#include "esolver.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <eutils/eregexp.h>
#include <fstream>
#include <iomanip>
#include "erandomwalk.h"
int starting=0;
int ending=0;
double indexing=0;

enet net;
estr getFilename(const estr& str)
{
  estr tmpstr;
  eregexp re("[^/.]+\\.[^.]+$");
  tmpstr=re_match(str,re);
  eregexp re2("^[^/.]+");
  tmpstr=re_match(tmpstr,re2);
  return(tmpstr);
}

int emain()
{ ldieif (argvc<4,"syntax: ./exapt_waste2 <universe.net> <sampled_file.dat> -starting <num1> -ending <num2> -indexing <num3> <environment.flx>");  
  
  estr solver="esolver_clp";
  estr sizestr=argv[2];
  epregister(starting);
  epregister(ending);
  epregister(indexing);
  int internal_secretion=0;
  epregister(solver);
  epregister(internal_secretion);
  eparseArgs(argvc,argv);

  int num1=starting;
  int num2=ending;
  double num3=indexing;
  net.load(argv[1]);
  net.correct_malformed();
  erandomWalk rw(net,solver,0);
  rw.internal_secretion=internal_secretion;

  rw.getEnv(argvc,argv);
  rw.load(net);
  rw.calcPhenotype();
  
  estr str;
  estrarray parts;
  efile f;
  efile files; 
  estr numstr=num3;
  estr test=sizestr+"_exp_wst_"+numstr;

  int victory[27];
  for (int i=0;i<27;++i){victory[i]=0;}
  victory[10]=-1;
  victory[11]=+1;
  victory[13]=-1;
  victory[18]=-1;
  victory[19]=-1;
  victory[20]=-1;
  victory[22]=-1;
  victory[24]=+1;
  victory[26]=-1;

  int carbon[27];
  for (int i=0;i<27;++i){carbon[i]=0;}
  carbon[10]=2;
  carbon[11]=4;
  carbon[13]=5;
  carbon[18]=1;
  carbon[19]=3;
  carbon[20]=2;
  carbon[22]=5;
  carbon[24]=1;
  carbon[26]=3;
  int counter=1;

	f.open(argv[2],"r");
	while (f.readln(str)) {			// While the file isn't finished, read line by line
  if (counter>num1){
    	parts=str.explode(" ");		// cut the string based on delimiter, here a space, and assign the resulting fields into an array called "parts"
      int startindex=26;
	    eintarray numarray, writearr;
	    int tmp = 0;
      int tmpo= 0;
		  for (int i=0; i<parts.size(); ++i){
			       tmp = parts[i].i()+startindex;
			       rw.disable(tmp);
			       numarray.add(tmp);
		  }

      rw.calcPhenotype();

      int i=0;
      double counted=0;
      double carbonic=0;
      for (int j=0; j<26; ++j){
      if ((victory[j])==1){
         if ((rw.solvers.at(i).x[j])>1.0e-5){
             counted=counted+1;
             carbonic=carbonic+(carbon[j]*(rw.solvers.at(i).x[j]));
            }
      }
      else if ((victory[j])==-1){
           if ((rw.solvers.at(i).x[j])<-1.0e-5){
             counted=counted+1;
             carbonic=carbonic-(carbon[j]*(rw.solvers.at(i).x[j]));
            }
      }
      }

  	  estr intstr1=counted;
      estr intstr2=carbonic;
      files.open(test,"a");
		  files.write(intstr1+" "+intstr2+"\n");
		  files.close();


		  for (i=0; i<numarray.size(); ++i){
			    rw.activate(numarray[i]);
		  }
  }
  counter=counter+1;
  if (counter>num2){break;}
	}
	f.close();
	return(0);
}
