
#include "eqsolver_cplex.h"
#include <eutils/logger.h>


void eqsolver_cplex::positiveQ(int i)
{
  lddieif(!lp,"positive Mu "+estr(i)+" before parsing model");

//  mupositive[i]=true;

  i+=net->links.size();

  int ind[2];
  char lu[2];
  double bd[2];

  ind[0]=i;         ind[1]=i;
   lu[0]='L';        lu[1]='U';
   bd[0]=1.0e-3;     bd[1]=100.0;

  CPXchgbds(env,lp,2,ind,lu,bd);
}

void eqsolver_cplex::setxzero(int i)
{
  lddieif(!lp,"setxbounds "+estr(i)+" before parsing model");

  int ind;
  char lu;
  double bd;

  ind=i;
   lu='B';
   bd=0.0;

  CPXchgbds(env,lp,1,&ind,&lu,&bd);
}

void eqsolver_cplex::setxbounds(int i,double min,double max)
{
  lddieif(!lp,"setxbounds "+estr(i)+" before parsing model");

  int ind[2];
  char lu[2];
  double bd[2];

  ind[0]=i;         ind[1]=i;
   lu[0]='L';        lu[1]='U';
   bd[0]=min;        bd[1]=max;

  CPXchgbds(env,lp,2,ind,lu,bd);
}

void eqsolver_cplex::negativeQ(int i)
{
  lddieif(!lp,"negative Mu "+estr(i)+" before parsing model");

//  mupositive[i]=false;

  i+=net->links.size();

  int ind[2];
  char lu[2];
  double bd[2];

  ind[0]=i;         ind[1]=i;
   lu[0]='L';        lu[1]='U';
   bd[0]=-100.0;     bd[1]=-1.0e-3;


  CPXchgbds(env,lp,2,ind,lu,bd);
}

void eqsolver_cplex::activate(int i)
{
  lddieif(!lp,"activating node "+estr(i)+" before parsing model");

  net->links[i].active=true;

  int ind[2];
  char lu[2];
  double bd[2];

  ind[0]=i;         ind[1]=i;
   lu[0]='L';        lu[1]='U';
   bd[0]=-CPX_INFBOUND ;  bd[1]=CPX_INFBOUND;

  if (net->links[i].irreversible)
    bd[0]=0.0;


  CPXchgbds(env,lp,2,ind,lu,bd);
}

void eqsolver_cplex::disable(int i)
{
  lddieif(!lp,"disabling node "+estr(i)+" before parsing model");

  net->links[i].active=false;

  char lu;
  lu='B';
  double bd;
  bd=0.0;

  CPXchgbds(env,lp,1,&i,&lu,&bd);
}

void eqsolver_cplex::parse(enet& _net)
{
  net=&_net;

  int           status = 0;


  env = CPXopenCPLEX(&status);

  if ( env == NULL ) {
    char errmsg[1024];
    CPXgeterrorstring (env, status, errmsg);
    ldie("Could not open CPLEX environment: "+estr( errmsg));
  }


  status = CPXsetintparam (env, CPX_PARAM_SCRIND, CPX_ON);
  ldieif(status,"Failure to turn on screen indicator, error "+estr(status));


  status = CPXsetintparam (env, CPX_PARAM_DATACHECK, CPX_ON);
  ldieif(status,"Failure to turn on data checking, error "+estr(status));

  lp = CPXcreateprob (env, &status, "lpex1");
  ldieif(lp==NULL,"Failed to create LP.");



  int numberColumns;

  int i;
  int t_elements;

  t_elements=0;
  numberColumns=net->links.size();
  for (i=0; i<net->links.size(); ++i){
    t_elements+=net->links[i].src.size()+net->links[i].dst.size();
  }


  // load Null Space matrix (K)

  int krows;
  double *k_values;
  int k_elements;

  net->load_nullmatrix();

  krows = net->nullmatrixrows;
  k_values = net->nullmatrix;

  cout << "links: "<<net->links.size()<<endl;
  cout << "nodes: "<<net->nodes.size()<<endl;
  cout << "krows: "<<krows<<endl;

  k_elements=0;
  int j;
  for (i=0; i<krows; ++i){
    for (j=0; j<net->links.size(); ++j){
      if (k_values[i*net->links.size()+j]!=0.0)
        ++k_elements;
    }
  }

  double *range = new double[net->nodes.size()+krows];
  double *lower = new double[net->nodes.size()+krows];
  char sense[net->nodes.size()+krows];


  // Mass Balance Constraints: Conservation (=0), Source (<0) or Sink (>0)
  for (i=0;i<net->nodes.size();++i){
    if (net->fluxbounds.findkey(net->nodes[i].id) != -1)
      {lower[i]=net->fluxbounds[net->nodes[i].id].x; range[i]=net->fluxbounds[net->nodes[i].id].y - net->fluxbounds[net->nodes[i].id].x; sense[i] ='R'; }
    else if (net->nodes[i].id.find("_external") != -1 || net->nodes[i].id.find("[e]") != -1)
      {lower[i]=0.0; range[i]=CPX_INFBOUND; sense[i]='R'; } // allow output of _external metabolites
    else
      {lower[i]=0.0; range[i]=0.0; sense[i]='E'; }
  }

  // Energy Balance Constraints: =0
  for (; i<net->nodes.size()+krows; ++i)
    { lower[i]=0.0; range[i]=0.0; sense[i]='E'; }

  status = CPXnewrows(env,lp,net->nodes.size()+krows,lower,sense,range,NULL);

  ////////////////////////////////////////////////////////////////////////////////////////////////
  //
  // Constraints (Flux + dMu) and Problem Coeficients (Stochiometric + K null space matrix)
  //

  numberColumns = 2*net->links.size();  //  Flux variables + dMu coeficients = 2 * Flux variables

  t_elements += k_elements;             // Number of non-zero elements in K null space matrix

  double * objective = new double[numberColumns];
  double * lowerColumn = new double[numberColumns];
  double * upperColumn = new double[numberColumns];

  double * element = new double [t_elements];
  int * row = new int[t_elements];
  int * start = new int[numberColumns+1];
  int * length = new int[numberColumns+1];

  int k;

  ldinfo(" generating problem of " + estr(numberColumns) + " columns X " + estr((int)net->nodes.size()+krows) + " rows");

  
  ////////////////////////////////////////////////
  //
  //  Stochiometric Matrix & Flux Constraints
  //

//int ri;
  i=0;
  k=0;
//  start[numberColumns]=2*numberColumns;
  start[numberColumns]=t_elements;
  for (i=0;i<net->links.size();++i) {
//    if (!links[ri].active) continue;
    start[i]=k;
    length[i]=net->links[i].src.size() + net->links[i].dst.size();

    // for each flux, write the row which it affects
    for (j=0; j<net->links[i].src.size(); ++j){
      element[k]=-net->links[i].src[j].rate;
      row[k]=net->links[i].src[j].node->i;
      ++k;
    }
    for (j=0; j<net->links[i].dst.size(); ++j){
      element[k]=net->links[i].dst[j].rate;
      row[k]=net->links[i].dst[j].node->i;
      ++k;
    }

    // maximum/minimum reaction fluxs
    if (net->links[i].active)
      upperColumn[i]=CPX_INFBOUND;
    else
      upperColumn[i]=0.0;

    if (!net->links[i].active || net->links[i].irreversible)
      lowerColumn[i]=0.0;
    else
      lowerColumn[i]=-CPX_INFBOUND;

    // we dont want to maximize any other fluxes
    // but the first one
    objective[i]=0.0;
  }
  objective[0] = 1.0;


//  cout << " null space matrix: " << endl;

  ////////////////////////////////////////////////
  //
  //  K null space matrix & dMu Constraints
  //
  for (;i<2*net->links.size();++i){
    start[i]=k;
//    cout << "--> "<<i<<": ";

    // for each dMu, set row which it affects and corresponding value
    for (j=0; j<krows; ++j){
      if (k_values[j*net->links.size()+(i-net->links.size())] != 0.0){
        element[k]=k_values[j*net->links.size()+(i-net->links.size())];
        row[k]=net->nodes.size()+j;
//      cout << " [" << row[k] << "] "<<element[k];
        ++k;
      }
    }
    length[i]=k-start[i];

    upperColumn[i]=100.0;
    lowerColumn[i]=-100.0;
//    if (net->links[i-net->links.size()].irreversible)
//      lowerColumn[i]=1.0e-3;
    objective[i]=0.0;
//    cout << endl;
  }

  lowerColumn[net->links.size()] = 1.0e-3;


  status = CPXaddcols(env,lp,numberColumns,t_elements,objective,start,row,element,lowerColumn,upperColumn,NULL);


  ldieif(t_elements!=k,"something is wrong with t_elements! t_elements="+estr(t_elements)+" , k="+estr(k));

//  ldwarn("creating model and matrix");

			
  delete [] lower;
  delete [] range;
  delete [] objective;
  delete [] lowerColumn;
  delete [] upperColumn;
  delete [] element;
  delete [] start;
  delete [] length;
  delete [] row;


  CPXchgobjsen (env, lp, CPX_MAX);

  int numcols;
  int numrows;

  numcols = 2*net->links.size();
  numrows = net->nodes.size()+krows;

  x = new double[numcols];
  slack = new double[numrows];
  dj = new double[numcols];
  pi = new double[numrows];
}

/*

eqsolver_cplex::~eqsolver_cplex()
{
  delete x; delete slack; delete dj; delete pi;
}

*/

double eqsolver_cplex::solve()
{
  lddieif(!lp,"solve method called before model was parsed");


  int status;

  status = CPXlpopt(env,lp);
  ldieif(status,"Failed to optimize LP");

  int numrows,numcols;

  numrows = CPXgetnumrows(env,lp);
  numcols = CPXgetnumcols(env,lp);

  int      solstat;
  double   objval;

  ldieif(x==NULL || slack==NULL || dj==NULL || pi==NULL,"Could not allocate memory for solution");

//  status = CPXgetstat(env,lp);

  status = CPXsolution (env, lp, &solstat, &objval, x, pi, slack, dj);
  ldieif(status,"Failed to obtain solution");

  switch(solstat){
   case CPX_STAT_OPTIMAL:
     return(objval);
    break;
   case CPX_STAT_UNBOUNDED:
     lwarn("model is unbounded");
     return(-1.0);
    break;
   case CPX_STAT_INForUNBD:
     lwarn("model is infeasible or unbounded");
     return(-1.0);
    break;
   case CPX_STAT_INFEASIBLE:
     lwarn("model is infeasible");
     return(-1.0);
    break;
   default:
     lwarn("model was not solved, unknown return code: "+estr(solstat));
     return(-1.0);
  }

//  cout << "Solution status: "<<solstat<<endl;
//  cout << "Solution value:  "<<objval<<endl;


/*
  int i;
  for (i=0; i<numrows; ++i)
    cout <<"row " << i<<": slack="<<slack[i]<<" pi="<<pi[i]<<endl;

  for (i=0; i<numcols; ++i)
    cout <<"col " <<i<<": value="<<x[i]<<" cost="<<dj[i]<<endl;
*/


  return(objval);
}













void eqsolver_cplex2::positiveQ(int i)
{
  lddieif(!lp,"positive Mu "+estr(i)+" before parsing model");

  int ind[2];
  char lu[2];
  double bd[2];

  ind[0]=i;         ind[1]=i;
   lu[0]='L';        lu[1]='U';
   bd[0]=1.0e-3;     bd[1]=100.0;

  CPXchgbds(env,lp,2,ind,lu,bd);
}

void eqsolver_cplex2::setxzero(int i)
{
  lddieif(!lp,"setxbounds "+estr(i)+" before parsing model");

  int ind;
  char lu;
  double bd;

  ind=i;
   lu='B';
   bd=0.0;

  CPXchgbds(env,lp,1,&ind,&lu,&bd);
}

void eqsolver_cplex2::setxbounds(int i,double min,double max)
{
  lddieif(!lp,"setxbounds "+estr(i)+" before parsing model");

  int ind[2];
  char lu[2];
  double bd[2];

  ind[0]=i;         ind[1]=i;
   lu[0]='L';        lu[1]='U';
   bd[0]=min;        bd[1]=max;

  CPXchgbds(env,lp,2,ind,lu,bd);
}

void eqsolver_cplex2::negativeQ(int i)
{
  lddieif(!lp,"negative Mu "+estr(i)+" before parsing model");

  int ind[2];
  char lu[2];
  double bd[2];

  ind[0]=i;         ind[1]=i;
   lu[0]='L';        lu[1]='U';
   bd[0]=-100.0;     bd[1]=-1.0e-3;


  CPXchgbds(env,lp,2,ind,lu,bd);
}

void eqsolver_cplex2::parse(enet& _net)
{
  net=&_net;

  int status = 0;

  env = CPXopenCPLEX(&status);

  if ( env == NULL ) {
    char errmsg[1024];
    CPXgeterrorstring (env, status, errmsg);
    ldie("Could not open CPLEX environment: "+estr( errmsg));
  }

/*
  status = CPXsetintparam (env, CPX_PARAM_SCRIND, CPX_ON);
  ldieif(status,"Failure to turn on screen indicator, error "+estr(status));
*/

  status = CPXsetintparam (env, CPX_PARAM_DATACHECK, CPX_ON);
  ldieif(status,"Failure to turn on data checking, error "+estr(status));

  lp = CPXcreateprob (env, &status, "lpex1");
  ldieif(lp==NULL,"Failed to create LP.");



  int numberColumns;

  int i;
  int t_elements;

  // load Null Space matrix (K)

  int krows;
  double *k_values;
  int k_elements;

  getLogger()->level=1;

//  net->load_nullmatrix();

  krows = net->nullmatrixrows;
  k_values = net->nullmatrix;

  cout << "links: "<<net->links.size()<<endl;
  cout << "nodes: "<<net->nodes.size()<<endl;
  cout << "krows: "<<krows<<endl;

  k_elements=0;
  int j;
  for (i=0; i<krows; ++i){
    for (j=0; j<net->links.size(); ++j){
      if (k_values[i*net->links.size()+j]!=0.0)
        ++k_elements;
    }
  }

  double *range = new double[krows];
  double *lower = new double[krows];
  char sense[krows];

  // Energy Balance Constraints: =0
  for (i=0; i<krows; ++i)
    { lower[i]=0.0; range[i]=0.0; sense[i]='E'; }

  status = CPXnewrows(env,lp,krows,lower,sense,range,NULL);

  ////////////////////////////////////////////////////////////////////////////////////////////////
  //
  // Constraints (Flux + dMu) and Problem Coeficients (Stochiometric + K null space matrix)
  //

  numberColumns = net->links.size();  //  Flux variables + dMu coeficients = 2 * Flux variables
  t_elements = k_elements;             // Number of non-zero elements in K null space matrix

  double * objective = new double[numberColumns];
  double * lowerColumn = new double[numberColumns];
  double * upperColumn = new double[numberColumns];

  double * element = new double [t_elements];
  int * row = new int[t_elements];
  int * start = new int[numberColumns+1];
  int * length = new int[numberColumns+1];

  int k;

  ldinfo(" generating problem of " + estr(numberColumns) + " columns X " + estr(krows) + " rows");

  
  ////////////////////////////////////////////////
  //
  //  Stochiometric Matrix & Flux Constraints
  //

  i=0;
  k=0;
  start[numberColumns]=t_elements;

  ////////////////////////////////////////////////
  //
  //  K null space matrix & dMu Constraints
  //
  for (i=0; i<net->links.size();++i){
    start[i]=k;
    // for each dMu, set row which it affects and corresponding value
    for (j=0; j<krows; ++j){
      if (k_values[j*net->links.size()+i] != 0.0){
        element[k]=k_values[j*net->links.size()+i];
        row[k]=j;
        ++k;
      }
    }
    length[i]=k-start[i];

    upperColumn[i]=CPX_INFBOUND;
    lowerColumn[i]=-CPX_INFBOUND;
    if (net->links[i].irreversible)
      lowerColumn[i]=0.0;
    objective[i]=0.0;
  }
  lowerColumn[0] = 1.0e-3;

  ldinfo(" CPXaddcols ");

  status = CPXaddcols(env,lp,numberColumns,t_elements,objective,start,row,element,lowerColumn,upperColumn,NULL);
  ldieif(t_elements!=k,"something is wrong with t_elements! t_elements="+estr(t_elements)+" , k="+estr(k));

  delete [] lower;
  delete [] range;
  delete [] objective;
  delete [] lowerColumn;
  delete [] upperColumn;
  delete [] element;
  delete [] start;
  delete [] length;
  delete [] row;

  CPXchgobjsen (env, lp, CPX_MAX);

  int numcols;
  int numrows;

  numcols = net->links.size();
  numrows = krows;

  x = new double[numcols];
  slack = new double[numrows];
  dj = new double[numcols];
  pi = new double[numrows];

  ldieif(x==NULL || slack==NULL || dj==NULL || pi==NULL,"Could not allocate memory for solution");
}

/*

eqsolver_cplex2::~eqsolver_cplex2()
{
  delete x; delete slack; delete dj; delete pi;
}

*/

double eqsolver_cplex2::solve()
{
  lddieif(!lp,"solve method called before model was parsed");

  int status;

  status = CPXlpopt(env,lp);
  ldieif(status,"Failed to optimize LP");

  int numrows,numcols;

  numrows = CPXgetnumrows(env,lp);
  numcols = CPXgetnumcols(env,lp);

  int      solstat;
  double   objval;

  status = CPXsolution (env, lp, &solstat, &objval, x, pi, slack, dj);
  ldieif(status,"Failed to obtain solution");

  switch(solstat){
   case CPX_STAT_OPTIMAL:
//     return(objval);
     return(1.0);
    break;
   case CPX_STAT_UNBOUNDED:
     lwarn("model is unbounded");
     return(-1.0);
    break;
   case CPX_STAT_INForUNBD:
     lwarn("model is infeasible or unbounded");
     return(-1.0);
    break;
   case CPX_STAT_INFEASIBLE:
     lwarn("model is infeasible");
     return(-1.0);
    break;
   default:
     lwarn("model was not solved, unknown return code: "+estr(solstat));
     return(-1.0);
  }

  return(objval);
}

