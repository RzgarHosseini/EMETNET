#include "enet.h"

#include <eutils/emain.h>


bool in_src(enode *node,elink *link)
{
  int i;
  for (i=0; i<link->src.size(); ++i){
   if (link->src[i].node == node)
     return(true);
  }
  return(false);
}


int emain()
{
  ldieif (argvc<2,"syntax: ./emetnet-inc <file.net>");  

  enet net;
  net.load(argv[1]); 
  cout << "finished loading file: "<<argv[1] << endl;

  int i,j,type;

  for (i=0; i<net.nodes.size(); ++i){
    type=0;
    for (j=0; j<net.nodes[i].links.size(); ++j){
      if (net.nodes[i].links[j]->irreversible){
        if (in_src(&net.nodes[i],net.nodes[i].links[j]))
          type=type|0x01;
        else
          type=type|0x02;
      }else
        type=type|0x03;
    }
    switch (type){
      case 0x00: cout << net.nodes[i].id << ": has no reactions!"<<endl; break;
      case 0x01: cout << net.nodes[i].id << ": is a source metabolite!"<<endl; break;
      case 0x02: cout << net.nodes[i].id << ": is a output metabolite!"<<endl; break;
      case 0x03: cout << net.nodes[i].id << ": is an internal metabolite!"<<endl; break;
    }
  }


  return(0);
}
