
#include "enet.h"

#include <eutils/emain.h>

int main()
{
  ldieif (argvc<2,"syntax: ./emetnet <file.net>");  

  enet net;
//  net.parse_clp(argv[1]); 
  net.load(argv[1]); 

/*
  int i,j;
  for (i=0; i<net.nodes.size(); ++i){
    cout << net.nodes[i].id << ": ";
    for (j=0; j<net.nodes[i].nodes.size(); ++j){
      cout << net.nodes[ net.nodes[i].nodes[j] ].id << " ";
    }
    cout << endl;
  }
*/

  cout << net << endl;

  return(0);
}
