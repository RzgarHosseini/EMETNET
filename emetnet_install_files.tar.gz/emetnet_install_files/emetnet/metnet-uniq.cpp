#include "enet.h"
#include <eutils/emain.h>


#define MAX(a,b) (a>b?a:b)

float compareReactions(elink* ri,elink *rj)
{
  int matched,matched2;
  int k,l;

  matched=0;

  for (k=0; k<ri->src.size(); ++k){
    if (!ri->src[k].node->id.len())
      { ++matched; continue; }
    for (l=0; l<rj->src.size(); ++l){
      if (ri->src[k].node->id == rj->src[l].node->id)
        { ++matched; break; }
    }
  }
  for (k=0; k<ri->dst.size(); ++k){
    if (!ri->dst[k].node->id.len())
      { ++matched; continue; }
    for (l=0; l<rj->dst.size(); ++l){
      if (ri->dst[k].node->id == rj->dst[l].node->id)
        { ++matched; break; }
    }
  }

  matched2=0;

  if (!rj->irreversible){
  for (k=0; k<ri->src.size(); ++k){
    if (!ri->src[k].node->id.len())
      { ++matched2; continue; }
    for (l=0; l<rj->dst.size(); ++l){
      if (ri->src[k].node->id == rj->dst[l].node->id)
        { ++matched2; break; }
    }
  }
  for (k=0; k<ri->dst.size(); ++k){
    if (!ri->dst[k].node->id.len())
      { ++matched2; continue; }
    for (l=0; l<rj->src.size(); ++l){
      if (ri->dst[k].node->id == rj->src[l].node->id)
        { ++matched2; break; }
    }
  }
  }

  return((float)MAX(matched,matched2)/(float)(ri->src.size()+ri->dst.size()));
}

int compareAllReactions(enode &node)
{
  int matched;
  int ir,jr;

  matched=0;
  for (ir=0; ir<node.links.size(); ++ir){
    if (node.links[ir]->info["M"]=="1") { ++matched; continue; }
    for (jr=ir+1; jr<node.links.size(); ++jr){
      if (compareReactions(node.links[ir],node.links[jr])>=0.9)
        { node.links[jr]->info["M"]="1"; ++matched; }
    }
  }
  return(matched);
}

int main()
{
  ldieif (argvc<2,"syntax: ./emetnet <file.net>");  

  enet net1;
  net1.load(argv[1]); 
  cout << "finished loading file: "<<argv[1] << endl;

  int matched;
  int i,j;

  int c1,c80;

  for (i=0; i<net1.nodes.size(); ++i){
    if (net1.nodes[i].id=="C00001"){
      c1=i;
      net1.nodes[i].id="";
    }else if (net1.nodes[i].id=="C00080"){
      c80=i;
      net1.nodes[i].id="";
    }
  }

  for (i=0; i<net1.nodes.size(); ++i){
    matched=compareAllReactions(net1.nodes[i]);
  } 

  net1.nodes[c1].id="C00001";
  net1.nodes[c80].id="C00080";

  for (i=0; i<net1.links.size(); ++i){
    if (net1.links[i].info["M"] == "1") continue;

    for (j=0; j<net1.links[i].src.size()-1; ++j){
      if (net1.links[i].src[j].rate!=1.0)
        cout << "("<< net1.links[i].src[j].rate <<") ";
      cout << net1.links[i].src[j].node->id << " + ";
    }
    if (net1.links[i].src[j].rate!=1.0)
      cout << "("<< net1.links[i].src[j].rate <<") ";
    cout << net1.links[i].src[j].node->id;

    if (net1.links[i].irreversible)
      cout << " --> ";
    else
      cout << " <=> ";

    for (j=0; j<net1.links[i].dst.size()-1; ++j){
      if (net1.links[i].dst[j].rate!=1.0)
        cout << "("<< net1.links[i].dst[j].rate <<") ";
      cout << net1.links[i].dst[j].node->id << " + ";
    }
    if (net1.links[i].dst[j].rate!=1.0)
      cout << "("<< net1.links[i].dst[j].rate <<") ";
    cout << net1.links[i].dst[j].node->id;
    
    cout << endl;
  }


  int count;
  count=0;
  for (i=0; i<net1.links.size(); ++i){
    if (net1.links[i].info["M"]=="1")
      ++count;
  }
  cerr<<" " << count << "/"<<net1.links.size()<<" total duplicate links found"<<endl;

  return(0);
}
