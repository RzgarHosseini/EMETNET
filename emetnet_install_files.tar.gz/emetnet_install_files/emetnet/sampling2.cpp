#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <vector>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
#include <eutils/ernd.h>
using std::vector;


// array that will store pre-computed number of "on" bits in a 16bit value
char precomp_count_16bits[0x1u<<16];
// function to compute how many "on" bits exist in a 32bit (int) value
inline char count_bits(unsigned int i)
{
  int cbits=0;
  while (i){
    cbits += i&0x1u;
    i>>=1;
  }
  return(cbits);
}

// function that needs to be called at the beginning of a program (before any other code) to initialize the array with pre-computed values (bits_in_16bits)
void init_precomp_count()
{
  unsigned int i;
// iterates through all possible 16 bit values and initializes the array to the number of "on" bits in that value
  for (i=0; i<0x1u<<16; ++i)
    precomp_count_16bits[i]=count_bits(i);
}

// function to compute how many "on" bits exist in a 64bit (long int) value using the pre-computed table. Basically this takes the first the 64 bits and splits it into 16 + 16 + 16 +16. For each of those 16 bits sums the count using the table to look them up. 
int count_bits16(unsigned long i)
{
  return( precomp_count_16bits[i & 0xfffful] + precomp_count_16bits[(i>>16) & 0xfffful] +precomp_count_16bits[(i>>32) & 0xfffful] + precomp_count_16bits[(i>>48) & 0xfffful] );
}

// This function will return the hamming distance between two networks represented by 64bit values
inline int mnets_dist(unsigned long x,unsigned long y)
{
  return(count_bits16(x^y));
}

int sample_size=0;
int carbon_source=-1;
int network_size=0;
int hamming_dist=0;
int genotype_size=0;

int emain()
{
ldieif(argvc<9,"syntax: ./sampling2 <inputfile1> <inputfile2> <outputfile> -sample_size <x>  -network_size <ns>  -hamming_dist <hd> -genotype_size <yy>");
cout<<"alaki"<<endl;
epregister(sample_size);
epregister(carbon_source);
epregister(network_size);
epregister(hamming_dist);
epregister(genotype_size);
eparseArgs(argvc,argv);
cout<<"alaki2"<<endl;
int x=sample_size;
int ns=network_size;
int index=carbon_source;
int hd=hamming_dist;
int yy=genotype_size;
int zz=45-yy;
cout<<"alaki3"<<endl;
//Initialization
estr infile1=argv[1];
estr infile2=argv[2];
estr outfile=argv[3];
cout<<"alaki4"<<endl;
efile fin1;
efile fin2;
efile fout;
estr str1;
estr str2;
estrarray parts;
cout<<"alaki5"<<endl;
init_precomp_count();  // initialize the precomp_count array
unsigned long allnetworks[x]; 
unsigned long allnetworks2[ns];
unsigned long genbits=0x00ul; // start with a 64bit value representing the network with all bits set to zero
int counter1=0;
fin1.open(infile1,"r");
while (fin1.readln(str1)) {
      parts=str1.explode(" ");
      genbits=0x00ul;
      for (int i=0; i<parts.size(); ++i){
      genbits|=(0x01ul<<(parts[i].i()-1));
      }
      allnetworks[counter1]=genbits;
      counter1++;
}
fin1.close();
cout<<"alaki6"<<endl;
int mat[ns][zz];
cout<<"alaki7"<<endl;
int counter2=0;
fin2.open(infile2,"r");
while (fin2.readln(str2)) {
      parts=str2.explode(" ");
      cout<<"alaki8"<<endl;
      genbits=0x00ul;
      for (int i=0; i<parts.size(); ++i){
           genbits|=(0x01ul<<(parts[i].i()-1));
           mat[counter2][i]=parts[i].i();
      }
      cout<<"alaki9"<<endl;
      allnetworks2[counter2]=genbits;
      counter2++;
      cout<<"alaki10"<<endl;
      double hapa=(double) counter2;
      cout<<hapa<<endl;
}
fin2.close();
cout<<"alaki11"<<endl;
eintarray chosen;
eintarray uniquation;
for (int q=0;q<x;q++){chosen.add(-1);}
for (int i=0;i<x;++i){
     int numeration=0;
     eintarray candidates;
     for (int w=0;w<ns;w++){
          int distance = mnets_dist(allnetworks[i],allnetworks2[w]);
          if (distance==hd){candidates.add(w);numeration++;}
     }
     cout<<"alaki12"<<endl;
     if (numeration>0){
         int terminatione=0;
         int shomarande=0;
         while (terminatione==0){
               cout<<"terminatione: "<<(double) terminatione<<endl;
               cout<<"numeration: "<<(double) numeration<<endl;
               shomarande++;
               if (shomarande>1000){terminatione=1;uniquation.add(-1);}
               int r = (int)(ernd.uniform()*numeration);
               cout<<"r: "<<(double) r<<endl;
               int temp=candidates[r];
               cout<<"temp: "<<(double) temp<<endl;
               int uniquer=1;
               for (int ll=0;ll<i;ll++){if (temp==uniquation[ll]){uniquer=0;}}
               for (int uu=0;uu<x;uu++){int dest=mnets_dist(allnetworks[uu],allnetworks2[temp]);if (dest==0){uniquer=0;}}
               if (uniquer==1){
                   uniquation.add(temp);
                   chosen[i]=temp;
                   terminatione=1;
               }
         }
     }
     else {uniquation.add(-1);}
}

fout.open(outfile,"w");
cout<<"alaki13"<<endl;
for (int i=0;i<x;++i){
     if (chosen[i]==-1){fout.write("\n");}
     else {
           eintarray outputing;
           for (int pp=0;pp<zz;pp++){outputing.add(mat[chosen[i]][pp]);}
           fout.write(intarr2str2(outputing)+"\n");
     }
}
cout<<"alaki14"<<endl;
fout.close();
return(0);
}
