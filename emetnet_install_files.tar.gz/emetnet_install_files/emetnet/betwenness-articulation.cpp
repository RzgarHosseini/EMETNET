// This program tests the percolation of edges.  Specifically, from the genotype  list, it builds the adjacency matrix. It then switches off all the edges and then randomly switches on 20% of them. It then checks for connectivity. We reiterate this process in increments of 10% of the network. From many such runs, one can estimate the mean connectivity threshold of the fraction of edges required to be on for 95% of the nodes to be connected. 

#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
#include <vector>
#include <fstream>
#include <iomanip>
#include <igraph/igraph.h>
#include <eutils/ernd.h>

using std::vector;

// array that will store pre-computed number of "on" bits in a 16bit value
char precomp_count_16bits[0x1u<<16];
 // function to compute how many "on" bits exist in a 32bit (int) value
inline char count_bits(unsigned int i) {
  int cbits=0;
  while (i){
    cbits += i&0x1u;
    i>>=1;
  }
  return(cbits);
}

// function that needs to be called at the beginning of a program (before any other code) to initialize the array with pre-computed values (bits_in_16bits)
void init_precomp_count()
{
  unsigned int i;
  // iterates through all possible 16 bit values and initializes the array to the number of "on" bits in that value
  for (i=0; i<0x1u<<16; ++i)
    precomp_count_16bits[i]=count_bits(i);
}

// function to compute how many "on" bits exist in a 64bit (long int) value using the pre-computed table. Basically this takes the first the 64 bits and splits it into 16 + 16 + 16 + 16. For each of those 16 bits sums the count using the table to look them up. 
int count_bits16(unsigned long i)
{
  return( precomp_count_16bits[i & 0xfffful] + precomp_count_16bits[(i>>16) & 0xfffful] +precomp_count_16bits[(i>>32) & 0xfffful] + precomp_count_16bits[(i>>48) & 0xfffful] );
}

// This function will return the hamming distance between two networks represented by 64bit values
inline int mnets_dist(unsigned long x,unsigned long y)
{
  return(count_bits16(x^y));
}

int emain() {
  ldieif(argvc<5,"syntax: betweenness-ap <inputfilename.dat> <number of lines> <output1> <output2>");

  estr sizestr=argv[1];
  estr numb1=argv[2];
  estr test1=argv[3];
  estr test2=argv[4];
  epregister(sizestr);
  int depth=20;
  epregister(depth);
  eparseArgs(argvc,argv);

  /*  */
  int j1;
  estrarray parts1;
  parts1=numb1.explode(" ");
  j1=parts1[0].i();

  init_precomp_count();  // initialize the precomp_count array
  unsigned long allnetworks[j1];  // this is the array which will contain all networks (array of 64bit values). Make sure to set "netcount" to the proper number of networks you will be reading


  cout << "# Total lines " << j1 << endl;

  // Reading the files and filling the arrays
  estr str;
  estrarray parts;
  efile f;
  int j,k,m,n,i;
  int intcount;
  eintarray n1, n2;
  unsigned long genbits=0x00ul; // start with a 64bit value representing the network with all bits set to zero
  intcount=0;
  f.open(argv[1],"r");
  while (f.readln(str)) {
        parts=str.explode(" ");
        genbits=0x00ul; 
        for (int m=0; m<parts.size(); ++m){
        genbits|=(0x01ul<<(parts[m].i()-1));}
        allnetworks[intcount]=genbits;
        intcount++;
  }
  f.close();
  int dist=0;
  int numedges=0;
  eintarray switch_flag;
  igraph_vector_t edges;
  eintarray edgetmp;


  for (i=0; i<j1-1; ++i) {
//    numneighbours=0;

    for(k=(i+1); k<j1; ++k) {
      dist = mnets_dist(allnetworks[i],allnetworks[k]); // Compute distance
      if (dist==2) {
        ++numedges;
//        n1.add(i);
//        n2.add(k);
        edgetmp.add(i);
        edgetmp.add(k);
//        switch_flag.add(1);
//        cout << i+1 << " " << k+1<< endl;
      }
    }
  } 
  
  igraph_vector_init(&edges, numedges*2);

  for (i=0; i<numedges*2; ++i) {
      VECTOR(edges)[i]=edgetmp[i];
  }
  
  cout << "# Total number of edges: " << switch_flag.size() << endl;

  /* Edges saved. Build graph and assess comp size etc. */

//  igraph_integer_t g1;
//	igraph_integer_t g2;
	igraph_integer_t N = j1;               /* Number of nodes*/
	igraph_t graphgen;                    /* graph of the  network  */
	igraph_bool_t if_directed=0;           /* genotype network is undirected */ 
	igraph_empty(&graphgen, N, if_directed); 	/* Initialized empty graph */
  
//  igraph_vector_t csize_real;
//  igraph_vector_init(&csize_real, 1);
//  igraph_vector_t membership;
//  igraph_vector_init(&membership, 1);

//  igraph_integer_t ncomponents;

  cout <<"# Building edges and graph ... " << endl;
  igraph_add_edges(&graphgen, &edges, 0); // graph building by edges done!

  /* Checking components
  igraph_clusters(&graphgen, &membership, &csize_real, &ncomponents, IGRAPH_STRONG);
  igraph_clusters(&graphgen, NULL, &csize_real, &ncomponents, IGRAPH_STRONG);

  cout <<"# No of clusters in genotype space: " <<  ncomponents << endl;
  int maxcompsize=0;
  
  for (i=0; i<ncomponents; ++i) {
    if (VECTOR(csize_real)[i]> maxcompsize) {maxcompsize = VECTOR(csize_real)[i];}
  }
  
  double maxfrac = double (maxcompsize)/double (j1);
  cout << "# Fraction of nodes on GCC (real): " << maxfrac << endl; 
  
  
  */
    
/*  igraph_real_t density;
  igraph_bool_t loops=FALSE;
  igraph_density(&graphgen, &density, loops);
  cout << "# Density of the graph: " << density << endl;
*/

// Clustering coefficient
/*  igraph_real_t cc;
  igraph_transitivity_undirected(&graphgen, &cc, IGRAPH_TRANSITIVITY_ZERO);
  cout << "# Clustering Coeff of the graph: " << cc << endl;*/
  
  // Average path length
/*  igraph_real_t avgpathl;
  igraph_average_path_length(&graphgen, &avgpathl, 0, TRUE);
  cout << "# Avg path length of the graph: " << avgpathl << endl; */
  efile files1;
   
  files1.open(test1,"a");

  igraph_vector_t articulation_nodes; // name vector
  igraph_vector_init(&articulation_nodes, 1); // initialize it to length 1
  igraph_articulation_points(&graphgen, &articulation_nodes); // finds points and store ith genotype
  int lengthv = igraph_vector_size(&articulation_nodes);

  eintarray tmparr1;
  tmparr1.add(lengthv);
  estr intstr1=intarr2str2(tmparr1);
  files1.write("# Number of articulation points: " + intstr1+"\n");

  //cout << "# Number of articulation points: " << lengthv << endl;
  for (i=0; i < lengthv; ++i) {
  eintarray tmparr2;
  tmparr2.add(VECTOR(articulation_nodes)[i]);
  estr intstr2=intarr2str2(tmparr2);
  //cout << "# articulation nodes: " << VECTOR(articulation_nodes)[i] << endl;
  files1.write("# articulation nodes: " + intstr2+"\n");
  }

  files1.close();
  
  igraph_vector_t bc;
  igraph_vector_init(&bc, j1);  
  igraph_betweenness(&graphgen, &bc, igraph_vss_all(), 0, NULL, 1);

  efile files2;
  files2.open(test2,"a");

  for (i=0; i<j1; ++i) {
       eintarray tmparr3;
       tmparr3.add(VECTOR(bc)[i]);
       estr intstr3=intarr2str2(tmparr3);
       files2.write(intstr3+"\n");
  //cout << VECTOR(bc)[i] << endl;
  }
  files2.close();

  
  igraph_destroy(&graphgen);
 
  
}





