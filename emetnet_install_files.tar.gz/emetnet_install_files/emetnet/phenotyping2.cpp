#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>

estr solver="esolver_clp";
int netsize=-1;
int strict=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
double gendist=0.0;
enet net;
erandomWalk *prw=0x00;


int emain()
{ ldieif(argvc<4,"syntax: ./phenotyping2  <file.net> <file.dat> <fluxbounds.flx>");  
  eparseArgs(argvc,argv);
////////////////////////////////////////////////////////////// Genotyping /////////////////////////////////////////////////////////////////
  net.load(argv[1]); 
  net.correct_malformed();
  erandomWalk rw(net,solver,strict);
  prw=&rw; 
  rw.periphery_only=periphery_only;
  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;
  rw.only_viable=only_viable;
  rw.setRSize(netsize);
  rw.getEnv(argvc,argv);
  rw.load(net);
  efile file1;
  file1.open(argv[2],"r");
  estr str;
  eintarray tmparr;
  estrarray parts;
  int tmp=0;
  while (file1.readln(str)) {	
  	 parts=str.explode(" ");		// cut the string based on delimiter, here a space, and assign the resulting fields into an array called "parts"
	 for (int j=0; j<parts.size(); ++j) {		// for each index j in array called parts, parts.size = length(parts)
	      tmp = parts[j].i();						// convert index j in parts to integer and assign to integer called tmp 					
	      tmparr.add(tmp);			// add the integer tmp to the next index in int array tmparr
         }
  }
  for (int i=0;i<6588;i++) {if (tmparr[i]==0){rw.disable(i);}}		
  rw.calcPhenotype(); 
  eintarray phen = rw.phenotype;
  for (int i=0;i<6588;i++) {rw.activate(i);}

  estr filein=argv[2];
  estr fileout=filein+"_phenotype";
 

  estr intstr = intarr2str2(phen);
  efile fout;
  fout.open(fileout,"w");
  fout.write(intstr+"\n"); 
  fout.close();
  return(0);
}

