//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
#include <vector>
using std::vector;
int emain() {
ldieif(argvc<2,"syntax: ./connected_comp2.cpp <inputfilename1.dat>");
estr sizestr=argv[1];
epregister(sizestr);
estr str;
estr intstr;
estr test=sizestr+"_parents";
estrarray parts;
efile f;
efile files;
int tmp;
f.open(argv[1],"r");
while (f.readln(str)) {
      parts=str.explode(" "); 
      for (int m=0; m<parts.size(); ++m){ 
          eintarray tmparr;		              			// initialize eintarray
          for (int n=0; n<parts.size(); ++n) {		// for each index j in array called parts, parts.size = length(parts)
          if(m!=n)
            { tmp = parts[n].i();						// convert index j in parts to integer and assign to integer called tmp 					
			      tmparr.add(tmp);}		// add the integer tmp to the next index in int array tmparr
		      }
          intstr = intarr2str2(tmparr);
          files.open(test,"a");
		      files.write(intstr+"\n");
		      files.close();
      }
}
f.close();
}

