#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
#include <vector>
using std::vector;

// array that will store pre-computed number of "on" bits in a 16bit value
char precomp_count_16bits[0x1u<<16];
// function to compute how many "on" bits exist in a 32bit (int) value
inline char count_bits(unsigned int i)
{
  int cbits=0;
  while (i){
    cbits += i&0x1u;
    i>>=1;
  }
  return(cbits);
}

// function that needs to be called at the beginning of a program (before any other code) to initialize the array with pre-computed values (bits_in_16bits)
void init_precomp_count()
{
  unsigned int i;
// iterates through all possible 16 bit values and initializes the array to the number of "on" bits in that value
  for (i=0; i<0x1u<<16; ++i)
    precomp_count_16bits[i]=count_bits(i);
}

// function to compute how many "on" bits exist in a 64bit (long int) value using the pre-computed table. Basically this takes the first the 64 bits and splits it into 16 + 16 + 16 +16. For each of those 16 bits sums the count using the table to look them up. 
int count_bits16(unsigned long i)
{
  return( precomp_count_16bits[i & 0xfffful] + precomp_count_16bits[(i>>16) & 0xfffful] +precomp_count_16bits[(i>>32) & 0xfffful] + precomp_count_16bits[(i>>48) & 0xfffful] );
}

// This function will return the hamming distance between two networks represented by 64bit values
inline int mnets_dist(unsigned long x,unsigned long y)
{
  return(count_bits16(x^y));
}


int emain() {
ldieif(argvc<3,"syntax: ./fitness__landscape.cpp <inputfilename1(dataset).dat> <number of lines> <inputfilename2(robustness).dat> <inputfilename3(growth_rate).dat>");
// Arguments
estr sizestr=argv[1];
estr sizestr1=sizestr+"_degree";
estr sizestr2=argv[3];
estr sizestr3=argv[4];
estr numb1=argv[2];
int j1;
estrarray joje1;
joje1=numb1.explode(" ");
j1=joje1[0].i();
epregister(sizestr);
epregister(sizestr2);
epregister(sizestr3);

init_precomp_count();  // initialize the precomp_count array
unsigned long allnetworks[j1];  

// Reading the files and filling the arrays
estr str;
estrarray parts;
efile f;
int intcount=0;
unsigned long genbits=0x00ul; 
f.open(argv[1],"r");
while (f.readln(str)) {
      parts=str.explode(" ");
      genbits=0x00ul; 
      for (int m=0; m<parts.size(); ++m){
      genbits|=(0x01ul<<(parts[m].i()-1));}
      allnetworks[intcount]=genbits;
      intcount++;
}
f.close();

// Finding the largest degree
estr str1;
estrarray parts1;
efile f1;
int max_deg=0;
int max_ind=0;
int count=0;
int temp=0;

f1.open(sizestr1,"r");
while (f1.readln(str1)) {
      parts1=str1.explode(" ");
      temp=parts1[0].i();
      if (temp>max_deg){
          max_ind=count;
          max_deg=temp;}
      count++;
}
f1.close();

//average robustness in different radius of the largest degree
float r[45];
for (int i=0;i<45;++i){
r[i]=0;
}

int n[45];
for (int i=0;i<45;++i){
n[i]=0;
}
estr str2;
estrarray parts2;
efile f2;

int count2=0;
int dist=0;

f2.open(sizestr2,"r");
while (f2.readln(str2)) {
      parts2=str2.explode(" ");
      float temp2=parts2[0].f();
      dist=0;
      dist=mnets_dist(allnetworks[count2],allnetworks[max_ind]);
      r[dist]=r[dist]+temp2;
      n[dist]=n[dist]+1;
      count2++;
}
f2.close();

float rr[45];
for (int i=0;i<45;++i){
rr[i]=0;
}
for (int i=0;i<45;++i){
rr[i]=r[i]/n[i];
}
//average growth rate in different radius of the largest degree
float g[45];
for (int i=0;i<45;++i){
g[i]=0;
}

estr str3;
estrarray parts3;
efile f3;

int count3=0;
f3.open(sizestr3,"r");
while (f3.readln(str3)) {
      parts3=str3.explode(" ");
      float temp3=parts3[0].f();
      dist=0;
      dist=mnets_dist(allnetworks[count3],allnetworks[max_ind]);
      g[dist]=g[dist]+temp3;
      count3++;
}
f3.close();

float gg[45];
for (int i=0;i<45;++i){
gg[i]=0;
}
for (int i=0;i<45;++i){
gg[i]=g[i]/n[i];
}
///////////////////////////////////////
estr test2=sizestr2+"_fitness_lanscape";
efile files2;
for (int i=0;i<45;++i){
estr intstr2=rr[i];
files2.open(test2,"a");
files2.write(intstr2+"\n");
files2.close();
}

estr test3=sizestr3+"_fitness_lanscape";
efile files3;
for (int i=0;i<45;++i){
estr intstr3=gg[i];
files3.open(test3,"a");
files3.write(intstr3+"\n");
files3.close();
}

} 

