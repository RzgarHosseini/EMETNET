#ifndef EMETNETDB_H
#define EMETNETDB_H

#include <eutils/estr.h>
#include <eutils/earray.h>
#include <eutils/emysql.h>

class ereactionelem
{
 public:
  int mid;
  float coefficient;
  estr compartment;
  ereactionelem(int mid,float coefficient,const estr& compartment);
};

ostream& operator<<(ostream& stream,const ereactionelem& relem);

class ereaction
{
 public:
  int rid;
  estr id;
  estr name;
  estr abbrv;
  estr ecnumber;
  estr equation;

  bool reversible;
  int type;

  earray<ereactionelem> substs;
  earray<ereactionelem> prods;
};

ostream& operator<<(ostream& stream,const ereaction& reaction);

class emetabolite
{
 public:
  int mid;
  estr id;
  estr name;
  estr compartment;
  estr formula;
  int charge;
};

ostream& operator<<(ostream& stream,const emetabolite& metabolite);
 
class emetnetdb
{
 public:
  earray<estrarray> refs;
  earray<emetabolite> metabolites;
  earray<ereaction> reactions;

  int getMetabolite(emetabolite& metabolite);
  int getReaction(ereaction& reaction);

  estr sqlReactions(emysql& mysql);
  estr sqlReactData(emysql& mysql,int refid);
  estr sqlReactMet(emysql& mysql,int refid);

  estr sqlMetabolites(emysql& mysql);
  estr sqlMetData(emysql& mysql,int refid);
};


class esbmlmodel
{
 public:
  earray<estrarray> refs;
  estrarrayof<emetabolite> metabolites;
  earray<ereaction> reactions;

  int getMetabolite(const estr& metid);
//  int getReaction(ereaction& reaction);
};

class ekeggmodel
{
 public:
  earray<estrarray> refs;
  estrarrayof<emetabolite> metabolites;
  earray<ereaction> reactions;

  int getMetabolite(const estr& metid);
};


#endif

