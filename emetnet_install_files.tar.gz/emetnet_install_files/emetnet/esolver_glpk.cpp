
#include "esolver_glpk.h"

//#define MAXFLUX COIN_DBL_MAX

esolver_glpk::esolver_glpk(): model(0x00)
{
  MMAXFLUX=1.0e20;
}

esolver_glpk::~esolver_glpk()
{
  if (model) { glp_delete_prob(model); delete x; delete y; }
}

void esolver_glpk::setobjective2(int i,double value)
{
  glp_set_obj_coef(model,i+1,value);
}

void esolver_glpk::setobjective(int i,double value)
{
  glp_set_obj_coef(model,iobjective+1,0.0);
  glp_set_obj_coef(model,i+1,value);
  iobjective=i;
}

void esolver_glpk::setobjective(evector& objective)
{
  int i;

  for (i=0; i<objective.w; ++i)
    glp_set_obj_coef(model,i+1,objective[i]);
}


void esolver_glpk::setybounds(int i,double min,double max)
{
//  model->setRowBounds(i,min,max);
  setxbounds(i+net->links.size(),min,max);
}

void esolver_glpk::setxbounds(int i,double fmin,double fmax)
{
  if (fmin==fmax)
    glp_set_col_bnds(model,i+1,GLP_FX,fmin,fmax);
  else if (fmin==-1.0e20 && fmax==1.0e20)
    glp_set_col_bnds(model,i+1,GLP_FR,fmin,fmax);
  else if (fmin==-1.0e20)
    glp_set_col_bnds(model,i+1,GLP_UP,fmin,fmax);
  else if (fmax==1.0e20)
    glp_set_col_bnds(model,i+1,GLP_LO,fmin,fmax);
  else
    glp_set_col_bnds(model,i+1,GLP_DB,fmin,fmax);

/*
  if (fmin==fmax)
    glp_set_col_bnds(model,i+1,GLP_FX,fmin,fmax);
  else
    glp_set_col_bnds(model,i+1,GLP_DB,fmin,fmax);
*/
}

void esolver_glpk::setActive(const eintarray& arr)
{
  lerrorifr(arr.size() != net->links.size(),"setActive: active array mismatch",);
   
  int i;
  for (i=1; i<arr.size(); ++i){
    if (arr[i]!=0)
      activate(i);
    else
      disable(i);
  }
}

void esolver_glpk::activate(int i)
{
  lddieif(!model,"activating node "+estr(i)+" before parsing model");
  double lower,upper;
  upper=1.0e20;
  lower=-1.0e20;
  if (net->links[i].irreversible)
    lower=0;

  net->links[i].active=true;
  setxbounds(i,lower,upper);
}

void esolver_glpk::disable(int i)
{
  lddieif(!model,"disabling node "+estr(i)+" before parsing model");

  net->links[i].active=false;
  setxbounds(i,0.0,0.0);
}

void esolver_glpk::parse(ematrix& m,evector& lower,evector& upper,evector& xlower,evector& xupper,evector& objective)
{
  ldie("routine not finished");

  int i,j;
  int t_elements;

  t_elements=0;
  for (i=0; i<m.w; ++i){
    for (j=0; j<m.h; ++j){
      if (m(j,i)!=0.0)
        ++t_elements;
    }
  }

  double * element = new double [t_elements];
  int * row = new int[t_elements];
  int * start = new int[m.w+1];
  int * length = new int[m.w+1];

  int k;

  // m.w ---> number of columns
  // m.h ---> number of rows

  ldinfo(" generating problem of " + estr(m.w) + " columns X " + estr(m.h) + " rows");

  i=0;
  k=0;
  start[m.w]=t_elements;
  for (i=0;i<m.w;++i) {
    start[i]=k;
    length[i]=0;

    // for each flux, write the row which it affects
    for (j=0; j<m.h; ++j){
      if (m(j,i)!=0.0){
        element[k]=m(j,i);
        row[k]=j;
        ++k;
        ++length[i];
      }
    }
  }
  ldieif(t_elements!=k,"something is wrong with t_elements! t_elements="+estr(t_elements)+" , k="+estr(k));

  ldinfo("creating clp model");

  if (model) glp_delete_prob(model);

  model = glp_create_prob();
//  glp_add_rows(model,m.h);
//  glp_add_cols(model,m.w);

/*
  // Create Packed Matrix
  CoinPackedMatrix matrix;
  matrix.assignMatrix(true,m.h,m.w,t_elements,element,row,start,length);
	
  ldinfo("loading model from matrix");
  // load model
  model->loadProblem( matrix, lower.vector, upper.vector, objective.vector, xlower.vector, xupper.vector );
			
//  ldwarn("finding solution");
//  model->setLogLevel(0);
  model->setPrimalTolerance(1.0E-9);
  model->setOptimizationDirection(-1);
*/

  delete [] element;
  delete [] start;
  delete [] length;
  delete [] row;
}

void esolver_glpk::parse(enet& _net)
{
  net=&_net;
  int numberColumns;

  int i;
  int t_elements;

  t_elements=0;
  numberColumns=net->links.size()+net->nodes.size();
  for (i=0; i<net->links.size(); ++i){
    t_elements+=net->links[i].src.size()+net->links[i].dst.size();
  }

  //added for metabolite in/out reactions
  t_elements+=net->nodes.size();

  double * lowerColumn = new double[numberColumns];
  double * upperColumn = new double[numberColumns];

  double * element = new double [t_elements+1]; // we need one extra element because glp_load_matrix starts its indice at 1 and not 0!!!
  int * row = new int[t_elements+1];
  int * col = new int[t_elements+1];

  int j,k;

  ldinfo(" generating problem of " + estr(numberColumns) + " columns X " + estr((int)net->nodes.size()) + " rows");


//int ri;
  i=0;
  k=1;
  for (i=0;i<net->links.size();++i) {
//    if (!links[ri].active) continue;

    // for each flux, write the row which it affects
    for (j=0; j<net->links[i].src.size(); ++j){
      row[k]=net->links[i].src[j].node->i+1;
      col[k]=i+1;
      element[k]=-net->links[i].src[j].rate;
      ++k;
    }
    for (j=0; j<net->links[i].dst.size(); ++j){
      row[k]=net->links[i].dst[j].node->i+1;
      col[k]=i+1;
      element[k]=net->links[i].dst[j].rate;
      ++k;
    }

    // maximum/minimum reaction fluxs
    if (net->links[i].active)
      upperColumn[i]=1.0e20;
    else
      upperColumn[i]=0.0;

    if (!net->links[i].active || net->links[i].irreversible)
      lowerColumn[i]=0.0;
    else
      lowerColumn[i]=-1.0e20;
  }


  int ifbounds,inode;
  for (; i<net->links.size()+net->nodes.size(); ++i){
    inode=i-net->links.size();
    row[k]=inode+1;
    col[k]=i+1;
    element[k]=-1.0;
    ++k;
    ifbounds=net->fluxbounds.findkey(net->nodes[inode].id);
    lowerColumn[i]=0.0;
    upperColumn[i]=0.0;
    if (ifbounds != -1){
      lowerColumn[i]=net->fluxbounds[ifbounds].x;
      upperColumn[i]=net->fluxbounds[ifbounds].y;
    }else if (net->nodes[inode].id.find("_external") != -1 || net->nodes[inode].id.find("[e]") != -1 || internal_secretion){
      lowerColumn[i]=0.0;
      upperColumn[i]=1.0e20;
    }
  }

  iobjective=0;

  ldieif(t_elements+1!=k,"something is wrong with t_elements! t_elements="+estr(t_elements)+" , k="+estr(k));

//  ldwarn("creating model and matrix");

  linfo("creating glpk model");

  if (model) { glp_delete_prob(model); delete x; delete y; }

  x=new double[numberColumns];
  y=new double[net->nodes.size()];
  model = glp_create_prob();

  glp_add_rows(model,net->nodes.size());
  glp_add_cols(model,numberColumns);

  for (i=0; i<numberColumns; ++i){
    glp_set_obj_coef(model,i+1,0.0);
    if (lowerColumn[i]==upperColumn[i])
      glp_set_col_bnds(model,i+1,GLP_FX,lowerColumn[i],upperColumn[i]);
    else if (lowerColumn[i]==-1.0e20 && upperColumn[i]==1.0e20)
      glp_set_col_bnds(model,i+1,GLP_FR,lowerColumn[i],upperColumn[i]);
    else if (lowerColumn[i]==-1.0e20)
      glp_set_col_bnds(model,i+1,GLP_UP,lowerColumn[i],upperColumn[i]);
    else if (upperColumn[i]==1.0e20)
      glp_set_col_bnds(model,i+1,GLP_LO,lowerColumn[i],upperColumn[i]);
    else
      glp_set_col_bnds(model,i+1,GLP_DB,lowerColumn[i],upperColumn[i]);
  }
  glp_set_obj_coef(model,1,1.0);

  for (i=0; i<net->nodes.size(); ++i)
    glp_set_row_bnds(model,i+1,GLP_FX,0.0,0.0);

  glp_load_matrix(model,t_elements,row,col,element);

/*
  delete [] lowerColumn;
  delete [] upperColumn;
  delete [] element;
  delete [] col;
  delete [] row;
*/
  glp_set_obj_dir(model,GLP_MAX);

}


double esolver_glpk::solve()
{

  lddieif(!model,"solve method called before model was parsed");

  glp_smcp parms;
  glp_init_smcp(&parms);

  parms.tol_bnd=1.0e-9;
//  parms.meth=GLP_DUAL;

  int i;
  double r;

  int status;
  status = glp_simplex(model,&parms);
//  status = glp_simplex(model,NULL);

//  ldwarn("showing solution");
  switch(status){
    case 0:
      status = glp_get_status(model);
      if (status==GLP_OPT){
        for (i=0; i<glp_get_num_cols(model); ++i)
          x[i]=glp_get_col_prim(model,i+1);

        for (i=0; i<glp_get_num_rows(model); ++i)
          y[i]=glp_get_row_prim(model,i+1);

        r=glp_get_obj_val(model);
        cout << x[0] << " " << r << endl;
        if (fabs(r)<=1.0e-8) r=0.0;
        return(r);
     }else{
       cerr << "Solution is not optimal" << endl;
       return(-1.0);
     }
     break;
    case GLP_ENOPFS:
      cerr << "Model is infeasible!" << endl;
     break;
    case GLP_ENODFS:
      cerr << "Model is dual infeasible!" << endl;
     break;
    case GLP_EITLIM:
      cerr << "Limit number of iterations reached" << endl;
     break;
    default:
     cerr << "Unknown status: " << status << endl;
  }
  return(-1.0);
}

