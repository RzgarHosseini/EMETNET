//This script calculates growth rate

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "enet.h"
#include "esolver.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <eutils/eregexp.h>
#include <fstream>
#include <iomanip>
#include "erandomwalk.h"

enet net;

estr getFilename(const estr& str)
{
  estr tmpstr;
  eregexp re("[^/.]+\\.[^.]+$");
  tmpstr=re_match(str,re);
  eregexp re2("^[^/.]+");
  tmpstr=re_match(tmpstr,re2);
  return(tmpstr);
}

int emain()
{
  ldieif (argvc<2,"syntax: ./growth-rate <universe.net>  <environment.flx>");  
  
  estr solver="esolver_clp";
  int internal_secretion=0;

  epregister(solver);
  epregister(internal_secretion);
  eparseArgs(argvc,argv);

  net.load(argv[1]);
  net.correct_malformed();

//  cout << "# solver: "<<solver<<endl;
//  cout << "# internal_secretion: "<<internal_secretion<<endl;
  erandomWalk rw(net,solver,0);

  rw.internal_secretion=internal_secretion;

  int i,transport_count;
  transport_count=0;
  for (i=0; i<net.links.size(); ++i){
    if (net.links[i].transport)
      ++transport_count;
  }

  rw.getEnv(argvc,argv);
	rw.load(net);
  rw.calcPhenotype();

  cout << "# network: "<<argv[1]<<endl;
  cout << "# total reactions: "<<net.links.size()-1<<endl;
  cout << "# transport reactions: "<<transport_count<<endl;


	rw.calcPhenotype();
	cout << rw.printGrowthRate() << endl;

	return(0);
}


