#include "enet.h"
#include "esolver_clp.h"

#include <eutils/emain.h>
#include <eutils/ernd.h>


enet net;
esolver_clp solver;


int emain()
{
  float t=1;  //tradeoff
  epregister(t);
  float b=0.8;  //biomass threshhold
  epregister(b);
  float y=1; //bufferring allowed for yield production
  epregister(y);
//  int nsample = 1;
//  epregister(nsample);
//  int reportKO=10; // Number of maximum KO's you want to print out
//  epregister(reportKO);
//  float reportfmaxt=0.25; //The fmax threshold you want to print out
//  epregister(reportfmaxt); 
  eparseArgs(argvc,argv);
  ldieif (argvc<4,"syntax: "+efile(argv[0]).basename()+" <file.net> <env.net> <compound>");  

// loading network and environment
  net.load(argv[1]);
  solver.parse(net);
  solver.load_fluxbounds(argv[2]);

// identifying chemical of interest
  int inode;
  inode=net.nodes.findkey(argv[3]);
  ldieif(inode==-1,"Metabolite not found: "+estr(argv[3]));

  solver.setNodeBounds(net.nodes.at(inode).id,0.0,1000.0); //set bounds on chemical production
// Calculating basic growth
  float growth, growththresh;
  growth=solver.solve();
	growththresh = b*growth;
  cout << "# growth: " << growth <<endl;
	cout << "# growththresh: " << growththresh << endl;

  solver.setxbounds(0,growththresh,1.0e20);

  float fmingrowth,fmaxgrowth;
  float fmin,fmax,originalfmax;

// calculating max and min production of the chemical by the complete network
  solver.setNodeBounds(net.nodes.at(inode).id,-1000.0,1000.0); //set bounds on chemical production
  solver.setobjective(net.links.size()+inode); // set the fictitious chemical tr rxn as objective and maximization
  solver.solve();
  fmax=solver.x[net.links.size()+inode];
  originalfmax=fmax;
  fmaxgrowth=solver.x[0];

  solver.setobjective(net.links.size()+inode,-1);  // set the fictitious chemical tr rxn as objective and minimization
  solver.solve();
  fmin=solver.x[net.links.size()+inode];
  fmingrowth=solver.x[0];
  cout << "# Original network stats: " << fmin << " ("<<fmingrowth<<")  max: " << fmax << " (" << fmaxgrowth << ")"<< endl;

  int esscount=0;
  int activereactions=net.links.size()-1;
  eintarray ess;
  eintarray essmaster;
  int i;
  for (i=0; i<net.links.size(); ++i)
    {essmaster.add(0); ess.add(0);}

// int k;
// for (k=0; k<nsample; k++) { 

  for (i=0; i<net.links.size(); ++i) {
     ess[i]=0;
     if (!net.links[i].active) solver.activate(i); 
  }

  activereactions=net.links.size()-1;
  esscount=0;

//setting bounds on chemical tr rxn and growth

  solver.setobjective(0);
  solver.setxbounds(0,growththresh,1.0e20);
  solver.setNodeBounds(net.nodes.at(inode).id,(originalfmax*t),1000.0);

// starting descent to minimal network
  int randr; 
  while (esscount<activereactions){
    randr=(activereactions-esscount)*ernd.uniform();
    for (i=1; i<net.links.size(); ++i) { if (ess[i]==1 || !net.links[i].active) continue; if (randr==0) break; --randr; }
    ldieif(i==net.links.size() || !net.links[i].active || ess[i]==1,"something wrong!!");
    solver.disable(i);
    float res=solver.solve();
    if (res==-1.0 || res==-1){
      ess[i]=1;
      ++esscount;
      solver.activate(i);
    } else {
      --activereactions;
    }
  }

//Checking if theminimal network is alright
float growth_minnet = solver.solve();
	if (growth_minnet < growththresh) {
//    --k;
		cout << " Minnet has fuckedup or lower growth : " << growth_minnet <<endl;
		return(1);
//    continue;
	}


  solver.setNodeBounds(net.nodes.at(inode).id,-1000.0,1000.0);
  solver.setobjective(net.links.size()+inode);
  solver.solve();
  fmax=solver.x[net.links.size()+inode];
  fmaxgrowth=solver.x[0];

  solver.setobjective(net.links.size()+inode,-1);
  solver.solve();
  fmin=solver.x[net.links.size()+inode];
  fmingrowth=solver.x[0];

  cout << "### minimal net: " << fmin << " ("<<fmingrowth<<")  max: " << fmax << " (" << fmaxgrowth << ") "<< growth_minnet << endl;
  //cout << "# min: " << fmin << " ("<<fmingrowth<<")  max: " << fmax << " (" << fmaxgrowth << ")"<< endl;
  if (fmin <= 0)
		{
    cout << "# minimal network is fucked up minimal chemical, fmin= " << fmin << endl;
		return(1);
//    --k;
//    continue;
  }



  float mfmin=fmin;
  float fminthresh;
//  if (fmin < 0) {fminthresh=fmin/y;}
//  else {fminthresh = fmin*y;}
	fminthresh = fmin*y;
  esscount=0;
  for (i=0; i<net.links.size(); ++i)
    ess[i]=0;
	cout << " Fminthresh: " << fminthresh << endl; 
	float lastfmin=fminthresh;

//  solver.setobjective(net.links.size()+inode,-1);
  solver.setobjective(0);
	int whilecount=0;	
  while (esscount<net.links.size()-1-activereactions){
    randr=(net.links.size()-1-activereactions-esscount)*ernd.uniform();
    for (i=1; i<net.links.size(); ++i) { if (ess[i]==1 || net.links[i].active) continue; if (randr==0) break; --randr; }
    ldieif(i==net.links.size() || net.links[i].active || ess[i]==1,"something wrong!!");

//		solver.setNodeBounds(net.nodes.at(inode).id,-1000.0,1000.0);
//	  solver.setobjective(0);
    solver.activate(i);
	  solver.setobjective(0);
	  solver.setxbounds(0,growth_minnet,1.0e20);
    growth=solver.solve();

/*	
		if (growth < growththresh) {
      ess[i]=1;
      ++esscount;
      solver.disable(i);
			cout  << "# LOWERED GROWTH "<< net.links[i].info[0] << " Growth: " << growth << endl;
		} else {++activereactions;}
*/
	  solver.setxbounds(0,(growth*0.99),1.0e20);
	  solver.setobjective(net.links.size()+inode,-1);
		solver.setNodeBounds(net.nodes.at(inode).id,-1000.0,1000.0);
    fmin=solver.x[net.links.size()+inode];
	

    if (fmin<fminthresh){
      ess[i]=1;
      ++esscount;
      solver.disable(i);
      cout << "# - deleted "<< net.links[i].info[0] << " " << fminthresh << " " << fmin << " Growth: " << growth  << " Activerxns: " << activereactions << " " << esscount << " " << endl;
			solver.setobjective(0);
		} else {
			whilecount=whilecount+1;	
			if (fmin>lastfmin && whilecount==1) {fminthresh=fmin*y;}
			else if (fmin>lastfmin && lastfmin>fminthresh) {fminthresh=fmin*y;}
			//solver.setNodeBounds(net.nodes.at(inode).id,-1000.0,1000.0);
		  solver.setobjective(net.links.size()+inode);
		  solver.solve();
		  fmax=solver.x[net.links.size()+inode];
		  fmaxgrowth=solver.x[0];
      ++activereactions;
      cout << " + added " << net.links[i].info[0] << " " << fminthresh << " " << fmin << " Growth: " << growth  << " Activerxns: " << activereactions << " " << esscount << " " << endl;
			solver.setobjective(0);
			lastfmin=fmin;
    }
  }

  solver.setobjective(0);
//  solver.setxbounds(0,0.01,1.0e20);
	float endgrowth=solver.solve();
	solver.setxbounds(0,endgrowth,endgrowth);

  solver.setNodeBounds(net.nodes.at(inode).id,-1000.0,1000.0);
  solver.setobjective(net.links.size()+inode);
  solver.solve();
  fmax=solver.x[net.links.size()+inode];
  fmaxgrowth=solver.x[0];

  solver.setobjective(net.links.size()+inode,-1);
  solver.solve();
  fmin=solver.x[net.links.size()+inode];
  fmingrowth=solver.x[0];
//  cout << k << " # min: " << fmin << " ("<<fmingrowth<<")  max: " << fmax << " (" << fmaxgrowth << ") "<< esscount << endl;
  cout << " # Endresult: Growth: " << endgrowth << "  min: " << fmin << " ("<<fmingrowth<<")  max: " << fmax << " (" << fmaxgrowth << ") "<< esscount << endl;
	cout << endl;

///*
  for (i=0; i<net.links.size(); ++i) {
    if (ess[i]==1) {
//     solver.activate(i);
//      essmaster[i]++;
//      if (esscount <= reportKO && fmin >= originalfmax*reportfmaxt) {
      	cout << "    " << net.links[i] << endl;
//      }
    }
//  cout << net.links[i] << endl;
 }
  net.saveactive("min.net");

/*
  int essinstance=0;
  for (i=0; i<net.links.size(); ++i) {
    if (essmaster[i] > 0) {
      cout << "# count: " << essmaster[i] << " : " << net.links[i] << endl; 
      essinstance++;
    }
  }
  cout << "# Number of reactions with KO instance at least one: " << essinstance << endl;
*/
  return(0);
}
