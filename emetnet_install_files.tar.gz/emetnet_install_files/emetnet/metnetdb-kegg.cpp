#include <eutils/emain.h>
#include <eutils/efile.h>
#include <eutils/ehtml.h>
#include <eutils/emysql.h>
#include <eutils/eregexp.h>

#include "emetnetdb.h"


inline int nextword(const estr& str,int i=0)
{
  while (i<str.len() && str[i]==' ') ++i;
  return(i);
}

inline bool isChar(char a)
{
  return(a>='a' && a<='z' || a>='A' && a<='Z');
}

inline void getKey(const estr& line,int i,estr& key)
{
  int i2;
  i2=line.find(" ",i);
  if (i2==-1) key=line;
  else key=line.substr(i,i2-i);
}

typedef estrarrayof<evar> evarray;

inline evarray* getnode(evarray& values,const earray<estr>& keys)
{
  int i,ivar;
  evar tmp;
  evarray *tmpvarr=&values;
  for (i=0; i<keys.size(); ++i){
    ivar=tmpvarr->findkey(keys[i]);
    if (ivar==-1){
      cout << keys << endl;
      cout << "did not find key: " << keys[i] << endl;
      cout << values << endl;
      ldie("key not found");
    }
    ldieif(tmpvarr->values(ivar).getTypeid()!=typeid(evarray),"var not evarray");
    tmpvarr=&tmpvarr->values(ivar).get<evarray>();
  }
  return(tmpvarr);
}

void load_keggfile(const estr& filename,evarray& records)
{
  efile f(filename);
  estr line;


  estr key,tmpkey;
  estr value;

  int keytab;
  int dattab;
  earray<estr> keys;
  eintarray keytabs;
  eintarray dattabs;
  evarray record;
  evarray *pnode=&record;
  evar *cnode=0x00;

//  evarray records;

  

  
  int i,istr,tmpi;

  dattab=12;
  keytab=0;

  i=0;
  f.open("r");
  while (f.readln(line)){
    if (line.len()==0) continue;

    istr=nextword(line,0);
    if (istr<dattab && istr<12){
      getKey(line,istr,tmpkey);

      if (line=="///"){
        // reset key and value stack and add new element to array
        records.add(new evarray(record));
        keys.clear(); keytabs.clear(); record.clear(); keytab=0; dattab=12; pnode=&record; cnode=0x00;
        ++i;
        continue;
      }

      dattab=nextword(line,istr+tmpkey.len());
      if (dattab==istr+tmpkey.len()) dattab=12;
      value=line.substr(dattab);

      if (istr>keytab){
        // up one level
//        cout << "level up: " << key << " : " << keytab << endl;
        keys.add(key);
        keytabs.add(keytab);
        dattabs.add(dattab);
//        cout << ">";
//        for (tmpi=0; tmpi<istr-1; ++tmpi)
//          cout << " ";
//        cout << tmpkey << endl;
        
        ldieif(cnode->getTypeid()!=typeid(estr),"something wrong");

        evarray *tmparr=new evarray;
        tmparr->add(cnode->var);
        *cnode=evar(tmparr).var;
        pnode=tmparr;
        cnode=0x00;

        // change value to evararray
      }else if (istr<keytab){
        // down one or more levels
//        cout << "<";
//        for (tmpi=0; tmpi<istr-1; ++tmpi)
//          cout << " ";
//        cout << tmpkey << endl;

        while (keys.size() && keytabs.size() && istr<=keytabs[keytabs.size()-1]){
          keytabs.erase(keytabs.size()-1);
          keys.erase(keys.size()-1);
          dattabs.erase(dattabs.size()-1);
        }
//        cout << keys << endl;

        pnode=getnode(record,keys);
        if (keytabs.size()){
          keytab=keytabs[keytabs.size()-1];
          dattab=dattabs[dattabs.size()-1];
        }else{
          keytab=0; dattab=12; cnode=0x00;
        }

        // pop out the previous value in the stack
      }

      // same level
      cnode=&pnode->add(tmpkey,new estr(value));
//      cout << "entry: " << tmpkey << endl;

//      cout << "=";
//      for (tmpi=0; tmpi<istr-1; ++tmpi)
//        cout << " ";
//      cout << tmpkey << endl;

      // add a new entry in the previous array
      keytab=istr;
      key=tmpkey;
    }else if (istr>=dattab){
//      cout << "line: " << line << " istr: " << istr << " dattab: "<<dattab<<endl;
      cnode->get<estr>()+=line.substr(istr);
    }
  }
}

eregexp re_split(" +");

void parseMetabolite(evarray& arr,ekeggmodel& model)
{
  emetabolite met;
  estrarray args=re_explode(arr["ENTRY"].get<estr>(),re_split);
  met.id=args[0];
  met.name=arr["NAME"].get<estr>();
  met.formula=arr["FORMULA"].get<estr>();
  model.metabolites.add(met);
}

int emain()
{
  eparseArgs(argvc,argv);
  ldieif(argvc<1,"syntax: "+efile(argv[0]).basename()+" <kegg_dir>");

  evarray arr;
  load_keggfile(argv[1],arr);

  ldieif(arr.size()==0,"empty records");


  ekeggmodel model;

  int i;
  for (i=0; i<arr.size(); ++i)
    parseMetabolite(arr[i].get<evarray>(),model);



//  efile f(argv[1]);
//  estr str;
//  f.read(str);


/*
  emetnetdb mndb;
  ekeggmodel model;


  int j,k;
  for (i=0; i<model.metabolites.size(); ++i)
    model.metabolites[i].mid=mndb.getMetabolite(model.metabolites[i]);
  for (i=0; i<model.reactions.size(); ++i){
    for (j=0; j<model.reactions[i].substs.size(); ++j){
      k=model.reactions[i].substs[j].mid;
      model.reactions[i].substs[j].mid=model.metabolites[k].mid;
    }
    for (j=0; j<model.reactions[i].prods.size(); ++j){
      k=model.reactions[i].prods[j].mid;
      model.reactions[i].prods[j].mid=model.metabolites[k].mid;
    }
    model.reactions[i].rid=mndb.getReaction(model.reactions[i]);
  }
  cout << "# model.metabolites: " << model.metabolites.size() << endl;
  cout << "# model.reactions: " << model.reactions.size() << endl;
  cout << "# mndb.metabolites: " << mndb.metabolites.size() << endl;
  cout << "# mndb.reactions: " << mndb.reactions.size() << endl;

  emysql mysql;

  mysql.connect("localhost","fluxconcept","fseq2sh&B","fluxconcept");

  mysql.query("insert refs (refid,title) values (0,'"+mysql.escape_string(efile(argv[1]).basename())+"');");
  mysql.query("insert metabolites (mid,id,name) values "+mndb.sqlMetabolites(mysql)+";"); 
  mysql.query("insert met_ref_data (_mid,_refid,id,name,formula) values "+mndb.sqlMetData(mysql,0)+";"); 

  mysql.query("insert reactions (rid,id,name,ecnumber) values "+mndb.sqlReactions(mysql));
  mysql.query("insert react_ref_data (_rid,_refid,id,name,reversible,equation) values "+mndb.sqlReactData(mysql,0));

  mysql.query("insert react_ref_met (_rid,_refid,_mid,type,coefficient,compartment) values "+mndb.sqlReactMet(mysql,0));
*/

//  cout << "insert react_ref_met (_rid,_refid,_mid,type,coefficient,compartment) values "+mndb.sqlReactMet(mysql,0) << endl;

//  cout << mysql.tables() << endl;
//  cout << mysql.query("show tables") << endl;
  
  

//  cout << str.len() << endl;

  return(0);
}

