#include "enet.h"
#include "erandomwalk.h"

#include <eutils/emain.h>

estr intarr2str(const eintarray& arr);


bool isViable(eintarray phe,eintarray mphe)
{
  int i;
  for (i=0; i<phe.size(); ++i)
    if (mphe[i]==1 && phe[i]==0) return(false);
  return(true);
}

void phemerge(eintarray phe,earrayof<int,eintarray>& pheadd,earrayof<int,eintarray> &phedel,earrayof<int,eintarray>& phelist)
{
  int i,j;

  int ccount,tcount;
  ccount=0;
  tcount=0;

  for (j=0; j<phelist.size(); ++j){
    if (isViable(phelist.keys(j),phe)){
      i=pheadd.findkey(phelist.keys(j));
      if (i==-1)
        pheadd.add(phelist.keys(j),phelist.values(j));
      else
        pheadd.values(i)+=phelist.values(j);
    }else{
      i=phedel.findkey(phelist.keys(j));
      if (i==-1)
        phedel.add(phelist.keys(j),phelist.values(j));
      else
        phedel.values(i)+=phelist.values(j);
    }
  }
}



int emain()
{
  ldieif (argvc<4,"syntax: ./metnet-pherobust [--phenet phenet.net] <full.net> <part.net> <env.flx env2.flx ...>"); 

  int essonly=0;
  int internal_secretion=0;
  int internal_viability=0;
  int mutate_transport=0;
	estr solver="esolver_clp";

  epregister(internal_secretion);
  epregister(internal_viability);
  epregister(mutate_transport);
  epregister(essonly);
  epregister(solver);
  eparseArgs(argvc,argv);

  enet net;
  net.load(argv[1]); 
  net.correct_malformed();

  enet net2;
  net2.load(argv[2]);
  net2.correct_malformed();

  cout << "# internal secretion: " << internal_secretion << endl;
  cout << "# internal viability: " << internal_viability << endl;
  cout << "# mutate_transport: " << mutate_transport << endl;

  cout << "# loaded global metnet: "<<argv[1] << endl;
  cout << "# loaded starting metnet: "<<argv[2] << endl;
  cout << "# total reactions in global model: "<<net.links.size()<<endl;
  erandomWalk rw(net,solver,0);
  rw.internal_secretion=internal_secretion;
  rw.internal_viability=internal_viability;
  rw.mutate_transport=mutate_transport;

  rw.getEnv(argvc,argv);

  rw.load(net2);

  cout << "# total reactions in starting network: "<<rw.acount<<endl;
  rw.calcPhenotype();
  cout << "# original phenotype: "<<intarr2str(rw.phenotype)<<endl;

  eintarray pheref;
  pheref=rw.phenotype;

  if (net2.info.findkey("phetarget")!=-1){
    net.info.add("phetarget",net2.info["phetarget"]);
    str2intarr(net2.info["phetarget"].substr(4),pheref);
    cout << "# using phetarget from initial network file!"<<endl;
  }
  rw.viablePhenotype=pheref;
  cout << "# reference phenotype: "<<intarr2str(pheref)<<endl;

  ldieif(!rw.isViable(),"given network is not viable on target phenotype");

  int i;
  int transport=0;

  for (i=1; i<rw.genotype.size(); ++i){
    if (rw.net->links[i].transport && !rw.mutate_transport && rw.genotype[i]==1)
      ++transport;
  }

  earrayof<int,eintarray> phenotypes;
  earrayof<eintarray,estr> rreactions;
  estrarray dreactions;

  estr robstr;
  pheessential2(rw,phenotypes,rreactions,dreactions);

  cout << "# deleterious reactions" << endl;
  for (i=0; i<dreactions.size(); ++i)
    cout << dreactions[i] << endl;

  int delphecount=0;
  cout << "# reduced phenotypes" << endl;
  for (i=0; i<rreactions.size(); ++i){
    if (!rw.isViable(rreactions.values(i))){
      cout << rreactions.keys(i) << ": " << intarr2str(rreactions.values(i)) << endl;
      ++delphecount;
    }
  }

  if (essonly==0){
    cout << "# different deletion phenotypes" << endl;
    for (i=0; i<rreactions.size(); ++i){
      if (rw.isViable(rreactions.values(i)))
        cout << rreactions.keys(i) << ": " << intarr2str(rreactions.values(i)) << endl;
    }
   
    robstr=pherobust(rw,phenotypes,true);
  }
  earrayof<int,eintarray> addphenotypes,delphenotypes;
  phemerge(pheref,addphenotypes,delphenotypes,phenotypes);

//  for (i=0; i<delphenotypes.size(); ++i)
//    delphecount+=delphenotypes.values(i);

  if (essonly==0){
    ldie("update code for improved phenotypes");
    cout << "# 1st_neighboors_addition     mutant_phenotypes    unique_phenotypes   1st_neighboors_deletion  mutant_phenotypes  unique_phenotypes   inviable_mutants delmutants_pheref"<<endl;
//    cout << robstr << " " << essstr << " " << delphecount << endl;
  }else{
    cout << "# 1st_neighbors_deletion  mutant_phenotypes  unique_phenotypes   unviable_mutants"<<endl;
    cout << rw.acount-transport << " " << delphecount << " " << delphenotypes.size() << " " << dreactions.size() << endl;
  }

  int j;
  cout << "# list of phenotypes:"<<endl;
  for (i=0; i<phenotypes.size(); ++i){
    cout << phenotypes.values(i) << ": " << intarr2str(phenotypes.keys(i)) << endl;
  }

//  cout << "# add unique phenotypes: " << addphenotypes.size() << endl;  
//  cout << "# del unique phenotypes: " << delphenotypes.size() << endl;  

  return(0);
}
