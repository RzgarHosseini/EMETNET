
#include "edrawnode.h"
#include "edrawnet.h"

#include <eutils/ernd.h>

edrawnode::edrawnode(edrawnet* _drawnet,enode* _node): drawnet(_drawnet),node(_node),active(false),selected(false),source(false),objective(false),linkcount(0)
{
  pos = evector2(ernd.uniform(),ernd.uniform());
  pos2=pos;
  acc=evector2(0.0,0.0);

  if (node)
    drawnet->getname(node->id,name);
}

void edrawnode::draw()
{
  int color;

  color = ecWhite;
  if (active)        color = ecRed;
  else if (selected) color = ecYellow;
  else if (objective) color = ecGreen;
  else if (source)   color = ecMagenta;

  drawnet->setColor(color);

  if (node){
    evector2 d(0.02,0.02);
    drawnet->drawEllipse(pos-d*0.5-drawnet->vpoint,d);
/*
    drawnet->moveTo(pos-evector2(0.01,0)-drawnet->vpoint);
    drawnet->lineTo(pos+evector2(0.01,0)-drawnet->vpoint);
    drawnet->moveTo(pos-evector2(0,0.01)-drawnet->vpoint);
    drawnet->lineTo(pos+evector2(0,0.01)-drawnet->vpoint);
*/
    drawnet->print(pos+evector2(0.01,0.01)-drawnet->vpoint,name,70);
  }else{
    evector2 d(0.004,0.004);
    drawnet->drawEllipse(pos-d*0.5-drawnet->vpoint,d);
/*
    drawnet->moveTo(pos-evector2(0.002, 0.002)-drawnet->vpoint);
    drawnet->lineTo(pos-evector2(0.002,-0.002)-drawnet->vpoint);
    drawnet->lineTo(pos+evector2(0.002, 0.002)-drawnet->vpoint);
    drawnet->lineTo(pos+evector2(0.002,-0.002)-drawnet->vpoint);
    drawnet->lineTo(pos-evector2(0.002, 0.002)-drawnet->vpoint);
*/
  }
}


