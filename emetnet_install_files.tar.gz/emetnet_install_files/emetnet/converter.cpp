#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <vector>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
using std::vector;

int emain()
{ldieif(argvc<2,"syntax: ./converter <inputfile>");
efile fin;
efile fout;
estr str;
estr to_in=argv[1];
estr to_out=to_in+"_final";
estrarray parts;
fin.open(argv[1],"r");
fout.open(to_out,"a");
while (fin.readln(str)) {
      parts=str.explode(" ");
      int num=0;
      for (int i=0; i<parts.size(); ++i){int x=parts[i].i();num=num+pow(2,x);}
      estr final_num=(double) num;
      fout.write(final_num+"\n");
}
fin.close();
fout.close();
return(0);
}
