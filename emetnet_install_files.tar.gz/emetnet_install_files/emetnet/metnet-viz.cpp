
#include "enet.h"

#include <eutils/logger.h>
#include <eutils/vector2.h>
#include <eutils/ernd.h>

#include <edlib-2/edlib.h>


//ernd rnd;

ewinsys winsys;
ewindow win;


class edrawnode
{
 public:
  evector2 pos;
  evector2 pos2;
  evector2 acc;

  edrawnode();
  edrawnode(const evector2& pos);

  void draw(float width,float height);  
};

edrawnode::edrawnode(){}
edrawnode::edrawnode(const evector2& _pos): pos(_pos),pos2(_pos) {}

#define moveTof(a,b) moveTo((int)(a),(int)(b))
#define lineTof(a,b) lineTo((int)(a),(int)(b))

void edrawnode::draw(float width,float height)
{
  win.moveTof(pos.x*width-10,pos.y*height);
  win.lineTof(pos.x*width+10,pos.y*height);
  win.moveTof(pos.x*width,pos.y*height-10);
  win.lineTof(pos.x*width,pos.y*height+10);
}

class edrawnet
{
 public:
  earray<edrawnode> nodes;
  enet *net;
  float forcefactor;

  edrawnet(enet &net);

  void acc_reset();
  void acc_update();
  void pos_update();

  void update();
  void draw();
};

edrawnet::edrawnet(enet &_net): net(&_net)
{
  forcefactor=0.006;
  int i;
  nodes.reserve(net->nodes.size());
  for (i=0; i<net->nodes.size(); ++i)
    nodes.add(edrawnode(evector2(ernd.uniform(),ernd.uniform())));

  // after adding nodes, lets let the system run for some iterations into a more stable form
//  for (i=0; i<net->nodes.size()*100; ++i)
//    update();
}


void edrawnet::acc_reset()
{
  int i;
  for (i=0; i<nodes.size(); ++i)
    { nodes[i].acc.x = 0.0; nodes[i].acc.y = 0.0; }
}


#define MAX(a,b) (a<b)?(b):(a)

void edrawnet::acc_update()
{
  int i,j;
  evector2 dir;
  float dist;
  float idist;

  float deg;

  evector2 acc;

  for (i=0; i<nodes.size(); ++i){
    for (j=i+1; j<nodes.size(); ++j){
      dir = nodes[j].pos - nodes[i].pos;
      dist = sqrt(dir*dir);
      idist = 1.0/dist;
      dir = dir*idist;
      
      // constant attraction force between all nodes
      acc += forcefactor*dir;
      // inverse distance repulsion force between all nodes
      acc -= 0.001*idist*dir; //0.001*idist*dir;
      // if nodes are linked, then add constant linear attraction force
//      cout << net->nodes[i].nodes.find(j) << endl;
      if (i<net->nodes.size()){
        if( net->nodes[i].nodes.size()){
           if ( net->nodes[i].nodes.find(&net->nodes[j]) != -1){
              deg = (float)(MAX(net->nodes[i].nodes.size(),net->nodes[j].nodes.size()));
              acc += (forcefactor*0.5/deg)*dir; //forcefactor*0.5
           }
        }
      }


      nodes[i].acc += acc;
      nodes[j].acc -= acc;
    }
  }
}

void edrawnet::pos_update()
{
  int i;
  float in2;
  in2 = 1.0/(nodes.size()*nodes.size());
  evector2 tpos;
  for (i=0; i<nodes.size(); ++i){
    // drag factor of 0.9,  time factor of 0.1
    tpos = nodes[i].pos;
    nodes[i].pos += 0.001*in2*(nodes[i].pos - nodes[i].pos2) + 0.01*in2*nodes[i].acc;
//    nodes[i].pos += 1.0E-5*evector2(0.5-ernd.uniform(),0.5-ernd.uniform());
    nodes[i].pos2 = tpos;
  }
}

void edrawnet::update()
{
  acc_reset();

  acc_update();
  pos_update();
}

void edrawnet::draw()
{
  int i,j,k;
  for (i=0 ; i< 10; ++i)
    update();

  float width,height;
  
  width=1280; height=768;


  k=0;

  win.setColor(ecGray);

//  cout << nodes.size() << " --- " << net->nodes.size() << endl;
  for (i=0; i<net->nodes.size(); ++i){
    for (j=0; j<net->nodes[i].nodes.size(); ++j){
//      cout << i << " " << j << endl;
      if (net->nodes[i].nodes[j]->i > i){
        k = net->nodes[i].nodes[j]->i;

        if (i<nodes.size()){
          win.moveTof( width*nodes[i].pos.x, height*nodes[i].pos.y);
          if (k<net->nodes.size())
            win.lineTof( width*nodes[k].pos.x, height*nodes[k].pos.y);
        }
      }
    }
  }

  win.setColor(ecWhite);
  for (i=0; i<nodes.size(); ++i){
    nodes[i].draw(1280,768);
  }
}
 



int main(int argvc,char *argv[])
{
  ldieif(argvc<2,"syntax: metnet-viz <file.net>");

  win.create(1280,768);

  enet net;

  net.load(argv[1]);

  edrawnet drawnet(net);


/*
  int i;
  for (i=0; i<drawnet.nodes.size(); ++i){
    cout << drawnet.nodes[i].pos << endl;
  }
*/
  

  while(!winsys.processMessages()){
    win.clear(ecBlack);

    drawnet.draw();
    
    win.flip();

    if (win.isPressed(VK_DOWN))
      drawnet.forcefactor = drawnet.forcefactor*0.999;
    if (win.isPressed(VK_UP))
      drawnet.forcefactor = drawnet.forcefactor/0.999;
  }

  return(0);
}
