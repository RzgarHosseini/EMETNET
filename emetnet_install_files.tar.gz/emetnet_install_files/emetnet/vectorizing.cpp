#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>
estr solver="esolver_clp";
int netsize=-1;
int strict=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
double gendist=0.0;
enet net;
enet net2;
erandomWalk *prw=0x00;


int emain()
{ ldieif(argvc<3,"syntax: ./vectorizing <universe.net> <file.net> ");
  eparseArgs(argvc,argv);
  enet net1;
  enet net2;
  net1.load(argv[1]);
  erandomWalk rw(net1,solver,strict);
  prw=&rw; 

  net2.load(argv[2]);
  rw.load(net2);
  eintarray gen = rw.genotype;
  //eintarray final_gen=sort(gen);
  estr str=argv[2]; 
	estr test = str+"_vec";		// concatanate string "sizestr", int length and .dat and assign to estr test
	estr intstr = intarr2str2(gen);						// convert int array tmparr to a string called intstr
  estrarray intstr2=intstr.explode(" ");
  estr printed;
  efile files;
  files.open(test,"a");
  for (int j=0; j<intstr2.size(); ++j) {
      int intprinted=intstr2[j].i();
      printed=intarr2str2(intprinted);
	    files.write(printed+"\n");
  }
	files.close();

  return(0);
}


