#ifndef ESOLVER_GLPK_H
#define ESOLVER_GLPK_H

#include "esolver.h"

#include <glpk.h>


class esolver_glpk: public esolver
{
 public:
  glp_prob *model;
  
 
  esolver_glpk();
  ~esolver_glpk();

  void parse(ematrix& m,evector& lower,evector& upper,evector& xlower,evector& xupper,evector& objective);
  void parse(enet& net);
  double solve();

  int iobjective;
  void setobjective(int i,double value=1.0);
  void setobjective2(int i,double value=1.0);
  void setobjective(evector& obj);

  void setxbounds(int i,double min,double max);
  void setybounds(int i,double min,double max);

  void setActive(const eintarray& arr);
  void activate(int i);
  void disable(int i);
};

#endif

