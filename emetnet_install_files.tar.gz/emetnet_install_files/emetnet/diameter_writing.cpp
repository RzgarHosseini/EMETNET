#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>

int strict=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
enet net;
erandomWalk *prw=0x00;
estr outstr="";
//int num=0;
int flg=0; 

int emain()
{ ldieif(argvc<4,"syntax: ./diameter_writing  <file.dat> <file2.dat> --outstr  --flg");  

  //epregister(num);
  epregister(flg);
  epregister(outstr);
  eparseArgs(argvc,argv);

  estr sizstr=argv[1]; //the file containing the indexes
  estr filename=argv[2]; //the file containing the networks

  efile sfile;
  efile filein;
  
  sfile.open(sizstr,"r");
  filein.open(filename,"r");

  estr sttr;
  eintarray intarr,intarr1,intarr2;

  while (sfile.readln(sttr)) {
	 estrarray parts;
         parts=sttr.explode(" ");
         if (flg==0){
            int tmp=parts[0].i()+1;
            intarr.add(tmp);
         }
         else {
            int tmp1=parts[0].i();
            int tmp2=parts[1].i();
            intarr1.add(tmp1);
            intarr2.add(tmp2);
         }
  }

  if (flg==0){
      int count=0;
      int counter=0;
      efile outfile;
      outfile.open(outstr,"a");
      while (filein.readln(sttr)) {
             count++;
             if (count==intarr[counter]){counter++;outfile.write(sttr+"\n");}
      } 
      outfile.close();
      filein.close();
  }

  else {

/////// Writing to the first file ///////
      int count=0;
      int counter1=0;
      estr outstr1=outstr+"_final";
      efile outfile1;
      outfile1.open(outstr1,"a");
      while (filein.readln(sttr)) {
             count++;
             if (count==intarr1[counter1]){counter1++;outfile1.write(sttr+"\n");}                  
      }
      outfile1.close();
      filein.close();


/////// Writing to the second file ///////
      int count2=0;
      int counter2=0;
      estr outstr2=outstr+"_sorted";
      efile outfile2;
      outfile2.open(outstr2,"a");
      eintarray sorted=sort(intarr2);
      eintarray selected;
      for (int j=0;j<count;j++){
           int y=sorted[j];
           selected.add(intarr2[y]);
      }
      while (filein.readln(sttr)) {
             count2++;
             if (count2==selected[counter2]){counter2++;outfile2.write(sttr+"\n");}                  
      }
      outfile2.close();  
      filein.close();

/////// Writing to the third file ///////
      //int count3=0;
      //int counter3=0;
      //estr outstr3=outstr+"_2";
      //efile outfile3;
      //outfile3.open(outstr3,"a");
      //outfile2.open(outstr2,"r");
      //while (outfile2.readln(sttr)) {
        //    if (count3==intarr2[counter2]){counter2++;outfile2.write(sttr+"\n");}  
         //   count3++;                
      //}
      //outfile2.close();  
      //filein.close();   
  }

}




