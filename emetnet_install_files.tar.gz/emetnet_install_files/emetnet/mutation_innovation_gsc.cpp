#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>

estr solver="esolver_clp";

int strict=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
int cs=0;
enet net;
erandomWalk *prw=0x00;

int num1=0; //number of reactions in the parental networks
int num2=0; //number of loss of function mutations
int num3=0; //number of gain of function mutations
estr outnet="out.net";

int emain()
{ ldieif(argvc<4,"syntax: ./mutation_innovation_gsc <universe.net> <file.dat> [--outnet out.dat] --num1 --num2 --num3 --cs <fluxbounds.flx>");  
  epregister(num1);
  epregister(num2);
  epregister(num3);
  epregister(cs);
  epregister(outnet);
  eparseArgs(argvc,argv);
  epregister(solver);
  epregister(strict);
  epregister(periphery_only);
  epregister(mutate_transport);
  epregister(internal_secretion);
  epregister(only_viable);
  int netsize=num1-1;
  ////////////////////////////////////////////////////////////   Genotyping ////////////////////////////////////////////////////
  enet net;
  net.load(argv[1]);
  net.correct_malformed();
  erandomWalk rw(net,solver,strict);
  prw=&rw; 
  rw.periphery_only=periphery_only;
  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;
  rw.only_viable=only_viable;
  rw.getEnv(argvc,argv);
  rw.load(net);  
  net.correct_malformed();
  rw.calcPhenotype();
  efile fu;
  fu.open(argv[2],"r");
  efile fw;
  fw.open(outnet,"a");
  estr outnet2=outnet+"_phen";
  efile fw2;
  fw2.open(outnet2,"a");
  estr sttr;
  cout<<"alak1"<<endl;
  while (fu.readln(sttr)) {
	estrarray parts;
        parts=sttr.explode(" ");
        eintarray gen;
        eintarray gen2;
        eintarray phen1;
        eintarray phen2;
        int tmp=0;
        for (int i=0;i<6588;i++){gen.add(tmp);}
        for (int i=0;i<6588;i++){gen2.add(tmp);}
        for (int i=0;i<6588;i++){gen[i]=parts[i].i();}
	enet net2=net;
	rw.load(net2);
        for (int i=0;i<6588;i++){if (gen[i]==0){rw.disable(i);}}
        rw.periphery_only=periphery_only;
        rw.mutate_transport=mutate_transport;
        rw.internal_secretion=internal_secretion;
        rw.only_viable=only_viable;
        rw.setRSize(netsize);
        rw.calcPhenotype(); 
        phen1=rw.phenotype;
        fw2.write(intarr2str2(phen1)+"\n");
        for (int i=0;i<6588;i++){rw.activate(i);}
        double countering=1;
        cout<<"alak2"<<endl;
        for (int countering=0;countering<500;countering++){
        cout<<"alak3"<<endl;
        for (int i=0;i<6588;i++){gen2[i]=gen[i];}
        cout<<"alak4"<<endl;
        ////////////////////////////////////////////////////// Mutation ///////////////////////////////////////////////////////////////
        //////////////////////////// To be deleted /////////////////////////////   
        eintarray pop;
        for (int i=682; i<6588; ++i) {
             if (gen2[i]==1){pop.add(i);}
        }
        int tmp1; 
        for (int i=(num1-682); i>=0; --i) {
             int r = (int)(ernd.uniform()*i);
             tmp1 = pop[r];
             pop[r] = pop[i];
             pop[i]=tmp1;
        }

        eintarray pop1;
        for (int j=0;j<num2;j++){
             int x=pop[j];
             pop1.add(x);
        }
        eintarray sorted1=sort(pop1);
        eintarray selected1;
        for (int j=0;j<num2;j++){
             int y=sorted1[j];
             selected1.add(pop1[y]);
        }
        //////////////////////// To be added /////////////////////////
        eintarray popp;
        for (int i=682; i<6588; ++i) {
            if (gen2[i]==0){popp.add(i);}
        }
 
        for (int i=(6588-num1); i>=0; --i) {
             int r = (int)(ernd.uniform()*i);
             tmp1 = popp[r];
             popp[r] = popp[i];
             popp[i]=tmp1;
        }

        eintarray pop2;
        for (int j=0;j<num3;j++){
             int x=popp[j];
             pop2.add(x);
        }
        eintarray sorted2=sort(pop2);
        eintarray selected2;
        for (int j=0;j<num3;j++){
             int y=sorted2[j];
             selected2.add(pop2[y]);
        }
        selected1.add(0);
        selected2.add(0);
        ///////////////////
        cout<<"selected 1:"<<intarr2str2(selected1)<<endl;
        cout<<"selected 2:"<<intarr2str2(selected2)<<endl;
        /////////////////////////////////////////////////////////////// Mutation and outputing ////////////////////////////////////////////////////
        int count1=0;
        int count2=0;
        for (int i=0;i<6588;i++){
            if (gen2[i]==1){
               if (selected1[count1]==i){gen2[i]=0;count1++;}
            }
            else if (gen2[i]==0){
                 if (selected2[count2]==i){gen2[i]=1;count2++;}
            }
            else {}
        }
        for (int i=0;i<6588;i++){if (gen2[i]==0){rw.disable(i);}}
        rw.calcPhenotype();
        phen2 = rw.phenotype; 
        fw2.write(intarr2str2(phen2)+"\n");
        for (int i=0;i<6588;i++){rw.activate(i);}
        double gain=0;
        double loss=0;
        for (int k=0;k<50;k++){
            if (phen1[k]==1){
                if (phen2[k]==0){
                    loss=loss+1;
                }
            }
            else if (phen1[k]==0){
                 if (phen2[k]==1){
                     gain=gain+1;
                 }
            }
        }
        estr g=gain;
        estr l=loss;
        estr intstr=g+" "+l;
        fw.write(intstr+"\n");
        }    

  }
  fw.close();
  fw2.close();
  fu.close();
  return(0);
}
