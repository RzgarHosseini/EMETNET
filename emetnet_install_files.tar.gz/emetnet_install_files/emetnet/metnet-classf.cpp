#include "enet.h"
//#include "esolver_cplex.h"
#include "esolver_clp.h"

#include <eutils/ernd.h>
#include <eutils/earrayof.h>

enet net;
esolver_clp solver;
estrarray gibbsenergies;

typedef earrayof<evector2,estr> evecarr;

evecarr str2vecarr(const estr& str)
{
  earrayof<evector2,estr> varr;
  int i;
  estrarray arr(str);
  estrarray arr2;
  for (i=0; i<arr.size(); ++i){
    arr2=arr.values(i).explode(":");
    varr.add(arr.keys(i),evector2(arr2[0].d(),arr2[1].d()));
  }
  return(varr);
}

evecarr concentrations=str2vecarr("o2=1.0e-4:1.0e-6,co2=0.05:0.001,pi=0.05:0.001");

void reactions_maxmin(evector& ge_lowerb,evector& ge_upperb)
{
  int i,j,tmp;
//  double R=1.987; // universal gas constant (cal.K^-1.mol^-1)
  double R=8.314510e-3; // universal gas constant (kJ.K^-1.mol^-1)
  double T=298;   // temperature (K)

  double ladjust,radjust;
  double over;

  estr metabolite;


  for (i=net.nodes.size(); i<net.nodes.size()+net.links.size()-1; ++i){
    ladjust=1.0;
    radjust=1.0;
    over=0.0;
    for (j=0; j<net.links[i-net.nodes.size()+1].src.size(); ++j){
      metabolite = net.links[i-net.nodes.size()+1].src[j].node->id;
      if (metabolite != "h2o" && metabolite != "h2o[e]" && metabolite != "h" && metabolite != "h[e]"){
        tmp=concentrations.findkey(metabolite);
        if (tmp==-1 && metabolite.len() > 3){
          metabolite.del(-3);
          tmp=concentrations.findkey(metabolite);
        }
        if (tmp==-1){
          ladjust = ladjust/pow(0.000001,net.links[i-net.nodes.size()+1].src[j].rate);
          radjust = radjust/pow(0.01,net.links[i-net.nodes.size()+1].src[j].rate);
//          ladjust-=R*T*net.links[i-net.nodes.size()+1].src[j].rate*log(0.000001);
//          radjust-=R*T*net.links[i-net.nodes.size()+1].src[j].rate*log(0.01);
        }else{
          ladjust = ladjust/pow((double)concentrations[metabolite].y,net.links[i-net.nodes.size()+1].src[j].rate);
          radjust = radjust/pow((double)concentrations[metabolite].x,net.links[i-net.nodes.size()+1].src[j].rate);
//          ladjust-=R*T*net.links[i-net.nodes.size()+1].src[j].rate*log(concentrations[metabolite].y);
//          radjust-=R*T*net.links[i-net.nodes.size()+1].src[j].rate*log(concentrations[metabolite].x);
        }
      }else{
//        cout << metabolite <<" ("<<gibbsenergies[ metabolite ].d()<<") ";
//        over-=gibbsenergies[ metabolite ].d()*net.links[i-net.nodes.size()+1].src[j].rate; 
      }
    }


    for (j=0; j<net.links[i-net.nodes.size()+1].dst.size(); ++j){
      metabolite = net.links[i-net.nodes.size()+1].dst[j].node->id;
      if (metabolite != "h2o" && metabolite != "h2o[e]" && metabolite != "h" && metabolite != "h[e]"){
        tmp=concentrations.findkey(metabolite);
        if (tmp==-1 && metabolite.len() > 3){
          metabolite.del(-3);
          tmp=concentrations.findkey(metabolite);
        }
        if (tmp==-1){
          ladjust = ladjust*pow(0.01,net.links[i-net.nodes.size()+1].dst[j].rate);
          radjust = radjust*pow(0.000001,net.links[i-net.nodes.size()+1].dst[j].rate);
//          ladjust+=R*T*net.links[i-net.nodes.size()+1].dst[j].rate*log(0.01); 
//          radjust+=R*T*net.links[i-net.nodes.size()+1].dst[j].rate*log(0.000001);
        }else{
          ladjust = ladjust*pow((double)concentrations[metabolite].x,net.links[i-net.nodes.size()+1].dst[j].rate);
          radjust = radjust*pow((double)concentrations[metabolite].y,net.links[i-net.nodes.size()+1].dst[j].rate);
//          ladjust+=R*T*net.links[i-net.nodes.size()+1].dst[j].rate*log(concentrations[metabolite].x);
//          radjust+=R*T*net.links[i-net.nodes.size()+1].dst[j].rate*log(concentrations[metabolite].y);
        }
      }else{
        // removed energy should be the one that was optimized
//        cout << metabolite <<" ("<<gibbsenergies[ metabolite ].d()<<") ";
//        over+=gibbsenergies[metabolite].d()*net.links[i-net.nodes.size()+1].dst[j].rate; 
      }
    }
//    cout << endl;
    double min,max;

    solver.setobjective(i,-1.0);
    solver.solve();
    min=-solver.x[i];

    solver.setobjective(i);
    solver.solve();
    max=-solver.x[i];


    ladjust = R*T*log(ladjust);
    radjust = R*T*log(radjust);

//    if (net.links[i-net.nodes.size()+1].info["TFACTS"].size()) cout <<"+";

    if (net.links[i-net.nodes.size()+1].info.findkey("T")!=-1){
      if (net.links[i-net.nodes.size()+1].irreversible)
        cout << "+ --> ";
      else
        cout << "+ <=> ";
    }

    if (net.links[i-net.nodes.size()+1].info["NAME"].size()<=3 || net.links[i-net.nodes.size()+1].info["NAME"].substr(-3) != "_EC") {
      if (min==max){
         cout <<"* ";
         if (max+ladjust+over<0.0) { cout <<"> "; net.links[i-net.nodes.size()+1].irreversible=true; }
         else if (max+radjust+over>0.0) { cout <<"< "; net.links[i-net.nodes.size()+1].irreversible=true; net.links[i-net.nodes.size()+1].invert(); }
         else { cout << "<> "; net.links[i-net.nodes.size()+1].irreversible=false; }
      }else{
         if (max+radjust+over<0.0 && min+radjust+over<0.0 && max+ladjust+over>0.0 && min+ladjust+over>0.0) { cout <<"<> "; net.links[i-net.nodes.size()+1].irreversible=false; }
         else if (min+ladjust+over<0.0) { cout <<"> "; net.links[i-net.nodes.size()+1].irreversible=true; }
         else if (max+radjust+over>0.0) { cout <<"< "; net.links[i-net.nodes.size()+1].irreversible=true; net.links[i-net.nodes.size()+1].invert(); }
         else { cout << "n/a "; net.links[i-net.nodes.size()+1].irreversible=false; }
      }
    }
/*
    if (min==max && (min+radjust+over)*(max+ladjust+over)<0.0) cout << "<> ";
    if (max+ladjust+over<0.0) cout <<"> ";
    else if (min+radjust+over>0.0) cout << "< ";
*/
    cout << net.links[i-net.nodes.size()+1].info[0] <<" ";
    if (net.links[i-net.nodes.size()+1].info["TFACTS"].size())
      cout << "TF: " << net.links[i-net.nodes.size()+1].info["TFACTS"] << " ";
    


    cout << net.links[i-net.nodes.size()+1].info["NAME"] <<": radj("<<radjust<<") ladj("<<ladjust<<") over("<<over<<")  "<<min<<": "<<min+radjust+over<<"   "<< max<<": "<<max+ladjust+over<< "   " << evector2(ge_lowerb(i),ge_upperb(i))<<endl;

    ge_lowerb(i)=min+radjust+over;
    ge_upperb(i)=max+ladjust+over;
  }

  net.save("output.net");
}

void setnegobj(evector& obj)
{
  int i;
  for (i=0; i<net.nodes.size(); ++i)
    obj(i)=-1.0;
  for (; i<obj.w; ++i)
    obj(i)=0.0;
}

void setnullobj(evector& obj)
{
  int i;
  for (i=0; i<obj.w; ++i)
    obj(i)=0.0;
}

void setiobj(evector& obj,int i2,double val)
{
  setnullobj(obj);
  obj(i2)=val;
}

void metabolites_maxmin(evector& ge_lowerb,evector& ge_upperb)
{
  evector negobj;
  evector obj;
  double min,max;

  negobj.create(net.nodes.size()+net.links.size()-1);
  obj.create(net.nodes.size()+net.links.size()-1);

  setnegobj(negobj);

  int i;
  for (i=0; i<net.nodes.size(); ++i){
    if (gibbsenergies.findkey(net.nodes[i].id)!=-1) continue;
    // Maximize value for energy of metabolite (i)
    setiobj(obj,i,1.0);
    solver.setobjective(obj);
    solver.solve();

    max=solver.x[i];
    setiobj(obj,i,-1.0);
    solver.setobjective(obj);
    solver.solve();
    min=solver.x[i];

    cout << "node: "<<net.nodes[i].id<<"   "<<evector2(min,max)<<"  "<<evector2(ge_lowerb(i),ge_upperb(i))<<endl;
    solver.setxbounds(i,-10000.0,10000.0);
  }
}

void maxmin2(evector& ge_lowerb,evector& ge_upperb)
{
  evector negobj;
  evector obj;
  int cnt;
  double min,max;

  negobj.create(net.nodes.size()+net.links.size()-1);
  obj.create(net.nodes.size()+net.links.size()-1);

  setnegobj(negobj);

  int i,j;
  for (i=0; i<net.nodes.size(); ++i){
    if (gibbsenergies.findkey(net.nodes[i].id)!=-1) continue;
    // Maximize value for energy of metabolite (i)
    setiobj(obj,i,1.0);
    solver.setobjective(obj);
    solver.solve();

    max=solver.x[i];
    setiobj(obj,i,-1.0);
    solver.setobjective(obj);
    solver.solve();
    min=solver.x[i];

    // Fix the maximum value for this metabolite
    solver.setxbounds(i,max,max);

    // Now, minimize all other metabolite energies
    solver.setobjective(negobj);
    solver.solve();

    cnt=0;
    for (j=0; j<net.nodes.size(); ++j){
      if (j==i) continue;
      if (solver.x[i]<=solver.x[j])
        ++cnt;
    }
    cout << cnt <<": "<<net.nodes[i].id << " ("<<min<<"; "<<max<<"): ";
    // Check how many metabolites are greater or equal to metabolite (i)
    for (j=0; j<net.nodes.size(); ++j){
      if (j==i) continue;
      if (solver.x[i]<=solver.x[j] && gibbsenergies.findkey(solver.x[j])==-1)
        cout << net.nodes[j].id << " ("<<solver.x[j]<<")  ";
    }
    cout << endl;

    // Remove bounds for metabolite (i) and repeat procedure for metabolite (i+1)
    solver.setxbounds(i,-10000.0,10000.0);
  }
}



void makemodel(ematrix& m,ematrix& m2)
{
  int i,j;

  m.create(m2.w+m2.h,m2.h);
  for (i=0; i<m2.h; ++i){
    for (j=0; j<m2.w; ++j)
      m(i,j)=m2(i,j);
    for (j=m2.w; j<m.w; ++j)
      m(i,j)=0.0;
    m(i,i+m2.w)=1.0;
  }
}


int main(int argvc,char *argv[])
{

  ldieif(argvc<2,"syntax: "+estr(argv[0])+" <netfile>");

  net.load(argv[1]);
  net.correct_malformed();


  ematrix m,m1,m2;

  gibbsenergies.load("gibbsenergies.dat");

  net.stoichiomatrix(m);
  m1.copytranspose(m);

  makemodel(m2,m1);

  evector mu_upperb(m2.h),mu_lowerb(m2.h);
  evector ge_upperb(m2.w),ge_lowerb(m2.w);
  evector objective(m2.w);

  cout << concentrations << endl;


  // we fix the reaction variation in energy because we want to control it using the extra GE values
  int i;
  for (i=0; i<m2.h; ++i){
    mu_upperb(i)=0.0;
    mu_lowerb(i)=0.0;
  }

  estr metabolite;
  int tmp;
  for (i=0; i<m1.w; ++i){
    objective(i)=0.0;
    if (i<net.nodes.size()){
      metabolite = net.nodes[i].id;
      tmp=gibbsenergies.findkey(metabolite);
      if (tmp==-1 && metabolite.len()>3){
        metabolite.del(-3);
        tmp=gibbsenergies.findkey(metabolite);
      }

      if (tmp!=-1){
        ge_upperb(i)=gibbsenergies[metabolite].d()+10.0;
        ge_lowerb(i)=gibbsenergies[metabolite].d()-10.0;
      }else{
        ge_upperb(i)=100.0;
        ge_lowerb(i)=-5000.0;
      }
    }else{
      ge_upperb(i)=100.0;
      ge_lowerb(i)=-5000.0;
    }
  }

  // the actual reaction difference bounds
  for (i=m1.w; i<m2.w; ++i){
/*
    if (net.links[i-m1.w+1].info.findkey("T")!=-1){
      if (net.links[i-m1.w+1].irreversible){
        ge_upperb(i)=600.0;
        ge_lowerb(i)=-50.0;
      }else{
        ge_upperb(i)=100.0;
        ge_lowerb(i)=-100.0;
      }
    }else{
*/
//      ge_upperb(i)=600.0;
//      ge_lowerb(i)=-600.0;
      ge_upperb(i)=8000.0;
      ge_lowerb(i)=-8000.0;
//    }
    objective(i)=0.0;
  }


  getLogger()->level=1;

  solver.parse(m2,mu_lowerb,mu_upperb,ge_lowerb,ge_upperb,objective);

  ldieif(solver.solve()==-1,"Initial model too constrained, please relax the problem bounds");

  float drate=0.6;
  int j;
  for (i=0; i<500000; ++i){
    j=(int)(ernd.uniform()*(net.links.size()-1))+net.nodes.size();
//    j=(int)(ernd.uniform()*(net.links.size()-1+net.nodes.size()));
    if (j<net.nodes.size() && gibbsenergies.findkey(net.nodes[j].id)!=-1) continue;
    if (ernd.uniform()>0.5){
      solver.setxbounds(j,ge_lowerb(j)*drate,ge_upperb(j));
      if (solver.solve()!=-1)
        ge_lowerb(j)=ge_lowerb(j)*drate;
      else{
        solver.setxbounds(j,ge_lowerb(j),ge_upperb(j));
        cout << "! ";
      }
    }else{
      solver.setxbounds(j,ge_lowerb(j),ge_upperb(j)*drate);
      if (solver.solve()!=-1)
        ge_upperb(j)=ge_upperb(j)*drate;
      else{
        solver.setxbounds(j,ge_lowerb(j),ge_upperb(j));
        cout << "! ";
      }
    }
    if (!(i%100))
      cout << "j: "<<j<< "  bounds:  "<<ge_lowerb(j)<<" : "<<ge_upperb(j)<<endl;
  }

//  minimize(ge_lowerb,ge_upperb);

  reactions_maxmin(ge_lowerb,ge_upperb);

  metabolites_maxmin(ge_lowerb,ge_upperb);

/*
  rev=25;
  for (;rev>0; --rev){
    do{
      i=(int)(ernd.uniform()*(m2.w-m1.w))+m1.w;
    }while(fabs(ge_upperb(i)-ge_lowerb(i))<1.0e-6);
    solver.setxbounds(i,-40.0,40.0);
  }
  irr=15;
  for (;irr>0; --irr){
    do{
      i=(int)(ernd.uniform()*(m2.w-m1.w))+m1.w;
    }while(fabs(ge_upperb(i)-ge_lowerb(i))<1.0e-6);
    solver.setxbounds(i,60.0,600.0);
  }
  cout << " ----------------------------------- "<<endl<<endl;
  maxmin(ge_lowerb,ge_upperb);
*/

  return(0);
}
