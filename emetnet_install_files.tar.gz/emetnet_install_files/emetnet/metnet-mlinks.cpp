
#include "enet.h"

#include <eutils/emain.h>

int main()
{
  ldieif (argvc<2,"syntax: ./emetnet <file.net>");  

  enet net;
//  net.parse_clp(argv[1]); 
  net.load(argv[1]); 

//  cout << net << endl;


  return(0);
}
