#include "enet.h"
#include "erandomwalk.h"

#include <eutils/emain.h>
#include <eutils/ernd.h>
#include <eutils/eregexp.h>

/*
void random_phenotype(eintarray& arr,int num)
{
  lddieif(num<0 || num>solvers.size(),"random_phenotype(): num is out of bounds");

  while (arr.size() < solvers.size())
    arr.add(0);

  int i;
  while (num){
    i=(int)(ernd.uniform()*solvers.size());
    if (arr[i]==0){
      --num;
      arr[i]=1;
    }
  }
}
*/


void random_phenotype(eintarray& phe_target,eintarray& phe,int phecount_target){
  while (phe_target.size()<phe.size()) phe_target.add(0);
  int i;
  for (i=0; i<phe_target.size(); ++i)
    phe_target[i]=0;

  int phecount=countPhenotype(phe);

  int j;
  int tmp;
  for (i=0; i<phecount_target; ++i){
    tmp=ernd.uniform()*phecount;
    for (j=0; j<phe.size(); ++j){
      if (phe[j]==1 && phe_target[j]==0){
        if (tmp==0) {
          phe_target[j]=1;
          --phecount;
          break;
        }
        --tmp;
      }
    }
  }
}

int emain()
{

  int rcount=0;
  int phe=0;
  int mutate_transport=0;
  int internal_secretion=0;

  estr outnet="";
  estr solver="cplex";
  estr phetarget;

  epregister(rcount);
  epregister(phe);
  epregister(mutate_transport);
  epregister(internal_secretion);
  epregister(phetarget);

  epregister(outnet);
  epregister(solver);

  eparseArgs(argvc,argv);  

  ldieif (argvc<4,"syntax: ./metnet-findphe [-phe count] [-outnet file.net] [-solver clp|cplex] <file.net> <starter.net> <env.flx env2.flx ...>"); 

  enet net;
  net.load(argv[1]); 
  net.correct_malformed();

  enet net2;
  net2.load(argv[2]);

  epregisterClassProperty(erandomWalk,solvername);
  epregisterClassProperty(erandomWalk,mutate_transport);

  erandomWalk rw(net,solver,0);
  epregister(rw);

  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;

  cout << "# solver: "<<rw.solvername << endl;
  cout << "# mutate_transport: "<<rw.mutate_transport << endl;
  cout << "# internal_secretion: "<<rw.internal_secretion << endl;
  cout << "# global network: "<<argv[1] << endl;
  cout << "# total reactions (global): " << net.links.size() << endl;

  rw.getEnv(argvc,argv);

  ldieif(phe>rw.solvers.size(),"selected phenotype ("+estr(phe)+") count is higher than total environments given ("+estr(rw.solvers.size())+")");
  
  

  cout << "# initial network: " << argv[2] << endl;
  cout << "# total reactions (initial): " << net2.links.size() << endl;

  rw.load(net2);
  rw.calcPhenotype();

  if (rcount>0)
    rw.setRSize(rcount);
  else
    rcount=rw.count;

  cout << "# rcount: "<< rcount << endl;
  cout << "# phe: "<< phe << endl;
  cout << "# target network size: " << rcount << endl;

  int m,tmpmin;
  eintarray phe_s;
  eintarray phe_target;
  eintarray oldphe;
  phe_s=rw.phenotype;
  oldphe=rw.phenotype;

  m=countPhenotype(phe_s);
  cout << "# phenotype (initial): " << intarr2str(phe_s) <<endl;

  if (phetarget.len())
    str2intarr(phetarget,phe_target);
  else if (phe==0 && net2.info.findkey("phetarget")!=-1){
    str2intarr(net2.info["phetarget"],phe_target);
    cout << "# using phetarget from initial network file!"<<endl;
  }else{
    ldieif(phe==0,"random phenotype size not specified (use -phe parameter)");
    ldieif(phe>m,"expected network that grows on more than target number of environments");
    random_phenotype(phe_target,rw.phenotype,phe);
  }

  cout << "# target phenotype: " << intarr2str(phe_target) << endl;
  rw.viablePhenotype=phe_target;

  int i; 

  eintarray essreactions;
  for (i=0; i<rw.genotype.size(); ++i)
    essreactions.add(0);
  int esscount=0;
  int pheesscount=0;

  ldieif(rw.acount >= rcount,"rcount not bigger than starting net");

  rw.only_viable=1;

  rw.calcPhenotype();
 
  eintarray esslist;
  for (i=0; i<rw.genotype.size(); ++i)
    esslist.add(0);

  i=0;
  int tmp;

  rw.calcEssential(esslist);

  cout << "# essential count: " << countPhenotype(esslist) << endl;

  while (1){
    rw.mutate_add();
    ldieif(rw.lastAddMutation==-1,"last add mutation = -1");
 
    tmp=rw.lastAddMutation;


    rw.checkEssential(esslist);

    cout  << net.links[tmp].info[0] << " " << rw.acount << " " << countPhenotype(esslist) <<" "<< rw.printPhenotype() << endl;

    if (rw.acount==rcount) { cout << "# reached target network size: "<<rcount << endl; break; }
  }

  cout << "# found genotype with target phenotype: "<< rw.printPhenotype() << endl;
  cout << "# target phenotype: "<<intarr2str(phe_target)<<endl;

  net.info.add("phetarget",intarr2str(phe_target));

  if (outnet.len())
    net.saveactive(outnet);

  return(0);
}
