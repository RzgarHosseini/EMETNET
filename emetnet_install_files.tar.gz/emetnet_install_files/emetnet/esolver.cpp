
#include "esolver.h"

#include <eutils/estr.h>
#include <eutils/vector2.h>
#include <eutils/evar.h>
#include <eutils/efile.h>
#include <eutils/eregexp.h>
#include <eutils/eparserinterpreter.h>

#define MAXFLUX 1.0e20




bool esolver::fluxVar(int ind,double& min,double& max)
{
  setxbounds(0,1.0e-8,1000.0);
  setxbounds(ind,0.0,1000.0); // So we do not get unbounded solutions in case there are futile cycles
  setobjective(ind);
  max=solve();

  min=0.0;
  if (!net->links.values(ind).irreversible){
    setxbounds(ind,-1000.0,0.0); // So we do not get unbounded solutions in case there are futile cycles
    setobjective(ind,-1);
    min=solve();
  }

  if (max==-1.0 || min==-1.0){
    lwarn("Infeasible model");
    return(false);
  }

  setobjective(0);  
  setxbounds(0,0.0,1000.0); // reset biomass function bounds
  activate(ind); // set default values

  if (max<=1.0e-8 && min<=1.0e-8) return(false); // blocked reaction

  return(true);
}



esolver::esolver(): net(0x00),x(0x00),y(0x00),internal_secretion(false) {}
esolver::~esolver(){}

bool esolver::isAvailable()
{
  return(true);
}

void esolver::resetNodeBounds(const estr& node)
{
  int inode;
  inode=net->nodes.findkey(node);
  ldieif(inode==-1,"Node not found in net file");

  int ifbounds;
  ifbounds=fluxbounds.findkey(ifbounds);
  if (ifbounds==-1) { if (node.find("_external")!=-1 || node.find("[e]") || internal_secretion) setybounds(inode,0.0,1000.0); else setybounds(inode,0.0,0.0); }
  else setybounds(inode,fluxbounds.at(ifbounds).x,fluxbounds.at(ifbounds).y); 
}

void esolver::setNodeBounds(const estr& node,float lbound,float ubound)
{
  int i;
  i=net->nodes.findkey(node);
  ldieif(i==-1,"Node not found in net file");
  setybounds(i,lbound,ubound);
}

void esolver::setReactionBounds(const estr& reaction,float lbound,float ubound)
{
  int i;
  i=net->links.findkey(reaction);
  ldieif(i==-1,"Reaction not found in net file");
  setxbounds(i,lbound,ubound);
}

void esolver::load_fluxbounds(const estr& filename)
{
  efile file(filename);

  if (!file.exists())
    lwarn("limits file does not exist");

  estr data;

  file.read(data);

  data=re_replace(data,"#[^\n]*\n","\n");

  estr line;
  estrarray parts;
  estrarray minmax;
  earrayof<evector2,estr> tmpfluxbounds;

  while(data.len()){
    line=data.getline();
    line.remove_chars(" \t");
    if (!line.len()) continue;

    parts=line.explode("=");
    if (parts.size()<2) { lerror("missing = sign, ignoring..."); continue; }
    
    if (re_strpos(parts[1],"[\\[(]")!=-1)
      { parts[1].del(0,1); parts[1].del(-1); }

    minmax = re_explode(parts[1],"[:;,]");

    tmpfluxbounds[parts[0]] = evector2(0.0,1000);
    if (minmax.size()<2)
      tmpfluxbounds[parts[0]].x = minmax[0].d();
    else{
      if (minmax[0].len())
        tmpfluxbounds[parts[0]].x = minmax[0].d();
      if (minmax[1].len())
        tmpfluxbounds[parts[0]].y = minmax[1].d();
    }
  }

  int i;
  for (i=0; i<fluxbounds.size(); ++i){
    if (!net->nodes.exists(fluxbounds.keys(i)))
      { linfo("setting fluxbounds: "+fluxbounds.keys(i)+" metabolite does not exist"); continue; }

    if (fluxbounds.keys(i).find("_external")!=-1 || fluxbounds.keys(i).find("[e]") != -1 || internal_secretion){
      setNodeBounds(fluxbounds.keys(i),0.0,1000); //MMAXFLUX);
//      cout << i <<" "<<fluxbounds.keys(i) << ": " <<net->nodes[fluxbounds.keys(i)].i << " [e]" << endl;
    }else{
      setNodeBounds(fluxbounds.keys(i),0.0,0.0); //MMAXFLUX);
//      cout << i <<" "<<fluxbounds.keys(i) << ": " <<net->nodes[fluxbounds.keys(i)].i << " [c]"<< endl;
    }
  }

//  cout << endl;

  fluxbounds.clear();
  fluxbounds+=tmpfluxbounds;

  for (i=0; i<fluxbounds.size(); ++i){
    if (!net->nodes.exists(fluxbounds.keys(i)))
      { linfo("setting fluxbounds: "+fluxbounds.keys(i)+" metabolite does not exist"); continue; }

    setNodeBounds(fluxbounds.keys(i),fluxbounds.values(i).x,fluxbounds.values(i).y); //MMAXFLUX);
//    setybounds(net->nodes[fluxbounds.keys(i)].i,fluxbounds.values(i).x,fluxbounds.values(i).y);
  }
}

#ifdef EMETNET_HAVE_NLOPT
 #include "enlsolver_nlopt.h"
#endif
#ifdef EMETNET_HAVE_CPLEX
 #include "esolver_cplex.h"
#endif
#ifdef EMETNET_HAVE_GLPK
 #include "esolver_glpk.h"
#endif
#include "esolver_clp.h"

/*
void registerSolvers(eregisterClasses<esolver>& rs)
{
#ifdef EMETNET_HAVE_NLOPT
  rs.registerClass("nlopt",newObject<esolver,enlsolver_nlopt>);
#endif
#ifdef EMETNET_HAVE_CPLEX
  rs.registerClass("cplex",newObject<esolver,esolver_cplex>);
#endif
  rs.registerClass("clp",newObject<esolver,esolver_clp>); 
}

eregisterClasses<esolver> solverClasses(registerSolvers);
*/

class registerSolvers
{
 public:
  registerSolvers();
};

registerSolvers::registerSolvers()
{
//  epregisterClass(esolver);
#ifdef EMETNET_HAVE_NLOPT
  epregisterClass(enlsolver_nlopt);
  epregisterClassConstructor(enlsolver_nlopt,());
  epregisterClassInheritance(enlsolver_nlopt,esolver);
#endif
#ifdef EMETNET_HAVE_CPLEX
  epregisterClass(esolver_cplex);
  epregisterClassConstructor(esolver_cplex,());
  epregisterClassInheritance(esolver_cplex,esolver);
#endif
#ifdef EMETNET_HAVE_GLPK
  epregisterClass(esolver_glpk);
  epregisterClassConstructor(esolver_glpk,());
  epregisterClassInheritance(esolver_glpk,esolver);
#endif
  epregisterClass(esolver_clp);
  epregisterClassConstructor(esolver_clp,());
  epregisterClassInheritance(esolver_clp,esolver);
}

esolver *getSolver(const estr& solvername)
{
  evar var(epinterpret(solvername+"()"));
  if (var.isNull()){ lerror("unable to create solver object"); return(0x00); }
  ++var.var->pcount; // keep solver from being deleted by smart pointer
  evar var2(var.convert(typeid(esolver)));
  return(&var2.get<esolver>());
}

registerSolvers registerSolversObject;


