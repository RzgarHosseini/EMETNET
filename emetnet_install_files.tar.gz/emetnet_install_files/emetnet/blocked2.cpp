//This script calculates waste exaptation
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include "enet.h"
#include "esolver.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <eutils/eregexp.h>
#include <fstream>
#include <iomanip>
#include "erandomwalk.h"
enet net;
estr getFilename(const estr& str)
{
  estr tmpstr;
  eregexp re("[^/.]+\\.[^.]+$");
  tmpstr=re_match(str,re);
  eregexp re2("^[^/.]+");
  tmpstr=re_match(tmpstr,re2);
  return(tmpstr);
}

int emain()
{ ldieif (argvc<4,"syntax: ./blocked2 <universe.net> <sampled_file.dat> <environment.flx>");  
  
  estr solver="esolver_clp";
  estr sizestr=argv[2];
  
  int internal_secretion=0;
  epregister(solver);
  epregister(internal_secretion);
  eparseArgs(argvc,argv);

  net.load(argv[1]);
  net.correct_malformed();
  erandomWalk rw(net,solver,0);
  rw.internal_secretion=internal_secretion;

  rw.getEnv(argvc,argv);
  rw.load(net);
  rw.calcPhenotype();


  estr str;
  estrarray parts;
  efile f;
  efile files; 
  estr test=sizestr+"_blocked";

  files.open(test,"a");
  f.open(argv[2],"r");
  while (f.readln(str)) {			// While the file isn't finished, read line by line
    	parts=str.explode(" ");		// cut the string based on delimiter, here a space, and assign the resulting fields into an array called "parts"
        int startindex=26;
        double fluxmin;
        double fluxmax;
    	//estrarray ports=str.explode(" ");
        //cout<<ports<<endl;
        //cout<<parts<<endl;
        //cout<<parts1<<endl;
        //cout<<parts2<<endl;
        ////////////////////////////////////// Checking the first network //////////////////////////////////
	eintarray numarray1;
        int vec1[72];for (int i=0;i<72;i++){vec1[i]=1;}
        int blc1[72];for (int i=0;i<72;i++){blc1[i]=0;}
	int tmp = 0;
        int s=(int) parts.size();
	for (int i=0; i<s; ++i){
	     tmp = parts[i].i()+startindex;
             //estr tapa=(double) tmp;
             //cout<<tapa<<endl;
	     rw.disable(tmp);
	     numarray1.add(tmp);
             vec1[tmp]=0;
        }
        rw.calcPhenotype();
				
        for (int j=27;j<72;j++){if (vec1[j]==1){if (!rw.fluxVar(j,fluxmin,fluxmax)) {blc1[j]=1;}}}
        for (int i=0;i<numarray1.size();++i){rw.activate(numarray1[i]);}

        int p1=0; 
        for (int j=27;j<72;j++){if (blc1[j]==1){p1++;}}

        estr p1_str=(double) (p1);
        files.write(p1_str+"\n");
  }
  f.close();
  files.close();
  return(0);
}
