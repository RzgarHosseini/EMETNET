#include "enet.h"
#include "esolver_clp.h"

#include <eutils/emain.h>


enet net;
esolver_clp solver;


int main()
{
  ldieif (argvc<2,"syntax: ./metnet-clp <file.net>");  

  net.load(argv[1]);
  net.correct_malformed();

  int reactions;
  reactions=net.links.size();

  int nodes;
  nodes=net.nodes.size();

  int i;
  for (i=0; i<nodes; ++i)
    net.addlink(net.nodes.keys(i)+" --> "+net.nodes.keys(i)+"_out");

  solver.parse(net);


  earray<int> score;
  for (i=0; i<reactions; ++i)
    score.add(0);

  int j;
  for (i=reactions; i<net.links.size(); ++i){
    solver.setobjective(i,1.0);
    solver.setxbounds(i,0.0,1000.0);
    if (solver.solve() == 1000.0){
      cout << net.nodes.keys(i-reactions+nodes)<<endl;
      for (j=0; j<reactions; ++j){
        if (solver.x[j]>1.0e-3)
          ++score[j];
      }
    }
    solver.setxbounds(i,0.0,MAXFLUX);
  }

  for (i=0; i<reactions; ++i)
    cout << net.links[i].info[0] << " "<<score[i]<<endl;

  return(0);
}
