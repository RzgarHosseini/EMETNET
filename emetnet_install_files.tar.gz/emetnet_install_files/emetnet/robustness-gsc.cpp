////////////////////////////////////////////////////////////This script calculates robustness of the networks/////////////////////////////////////////////////////////////////////////////////////////
#include "enet.h"
#include "esolver.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <eutils/eregexp.h>

#include <fstream>
#include <iomanip>
#include "erandomwalk.h"

enet net;
estr num;

estr getFilename(const estr& str)
{
  estr tmpstr;
  eregexp re("[^/.]+\\.[^.]+$");
  tmpstr=re_match(str,re);
  eregexp re2("^[^/.]+");
  tmpstr=re_match(tmpstr,re2);
  return(tmpstr);
}

int emain()
{
  ldieif (argvc<4,"syntax: ./robustness-gsc <network.net> <deletings.dat> <environment.flx> -num nn");  
  
  estr solver="esolver_clp";
  int internal_secretion=0;

  epregister(solver);
  epregister(num);
  epregister(internal_secretion);
  eparseArgs(argvc,argv);

  net.load(argv[1]);
  net.correct_malformed();

  erandomWalk rw(net,solver,0);

  rw.internal_secretion=internal_secretion;

  int i;
  int startindex=681;
  rw.getEnv(argvc,argv);
	rw.load(net);
  rw.calcPhenotype();
	rw.viablePhenotype = rw.phenotype;

	estr str;
	estrarray parts;
	efile f;
	f.open(argv[2],"r");
  double count=0;

	while (f.readln(str)) {			// While the file isn't finished, read line by line
  	parts=str.explode(" ");		// cut the string based on delimiter, here a space, and assign the resulting fields into an array called "parts"
	  eintarray numarray;
	  int tmp = 0;
		for (int i=0; i<parts.size(); ++i){      	
			  tmp = parts[i].i()+startindex;
			  rw.disable(tmp);
			  numarray.add(tmp);
		}
		rw.calcPhenotype();


    if (rw.isViable()){count++;}
          
		for (int i=0; i<numarray.size(); ++i){
			  rw.activate(numarray[i]);
		}
	}
	f.close();
  estr intstr=count;
  estr nn=num;
  efile fout;
  estr hama=argv[1];
  estr outname=hama+"_rob_"+nn;
  fout.open(outname,"a");
  fout.write(intstr+"\n");
  fout.close();
	return(0);
}

