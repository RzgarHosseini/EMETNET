#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>

estr solver="esolver_clp";

int strict=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
//int cs=0;
enet net;
erandomWalk *prw=0x00;

int num1=0; //number of reactions in the parental networks
double num2=0.0; //genotypic distance between parental genotypes
int num3=0; //number of exchanged reactions
estr outnet="out.net";
//void save_state(int)
//{
//  efile f1("state.dat");
//  f1.open("w");

//  f1.write("strictViable="+estr(strict)+"\n");
//  f1.write("periphery_only="+estr(periphery_only)+"\n");
//  f1.write("mutate_transport"+estr(mutate_transport)+"\n");
//  f1.write("internal_secretion="+estr(internal_secretion)+"\n");
//  f1.write("iterations="+estr(niter)+"\n");
//  if (prw)
//  f1.write("net=eintarray("+intarr2str(prw->genotype)+")\n"); 
//  f1.close();
//  exit(0);
//}


int emain()
{ ldieif(argvc<4,"syntax: ./recombination-gsc <universe.net> <file.dat> [--outnet out.dat] --num1 --num2 --num3  <fluxbounds.flx>");  
  epregister(num1);
  epregister(num2);
  epregister(num3);
  //epregister(cs);
  epregister(outnet);
  eparseArgs(argvc,argv);
  epregister(solver);
  epregister(strict);
  epregister(periphery_only);
  epregister(mutate_transport);
  epregister(internal_secretion);
  epregister(only_viable);
  int netsize=num1-1;
  //struct sigaction sa;
  //sa.sa_handler=&save_state;
  //sigaction(SIGINT,&sa,0x00);
  //ldieif(num2==0.0,"gendist is 0.0, please define a nonzero distance");
  //cout << "# environment: "<<argv[3] << endl;

  ////////////////////////////////////////////////////////////   Genotyping ////////////////////////////////////////////////////
  enet net;
  net.load(argv[1]);
  net.correct_malformed();
  erandomWalk rw(net,solver,strict);
  prw=&rw; 
  rw.periphery_only=periphery_only;
  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;
  rw.only_viable=only_viable;
  rw.getEnv(argvc,argv);
	rw.load(net);  
  net.correct_malformed();
  rw.calcPhenotype();
  efile fu;
	fu.open(argv[2],"r");
  efile fw;
  fw.open(outnet,"w");
  estr sttr;

	while (fu.readln(sttr)) {
			  estrarray parts;
        parts=sttr.explode(" ");
        eintarray gen1;
        eintarray gen2;
        int tmp=0;
        for (int i=0;i<6588;i++){gen1.add(tmp);}
        for (int i=0;i<6588;i++){gen1[i]=parts[i].i();}
        estr strr1="--------------GEN1---------------";
        estr strr2="--------------GEN2---------------";
        estr strr3="--------------GEN3---------------";
        fw.write(strr1+"\n");
        fw.write(intarr2str2(gen1)+"\n");
				enet net2=net;
				rw.load(net2);
        for (int i=0;i<6588;i++){if (gen1[i]==0){rw.disable(i);}}
        rw.periphery_only=periphery_only;
        rw.mutate_transport=mutate_transport;
        rw.internal_secretion=internal_secretion;
        rw.only_viable=only_viable;
        rw.setRSize(netsize);
        estr strr4="--------------GEN1_after------------";
        fw.write(strr4+"\n");
        fw.write(intarr2str2(rw.genotype)+"\n");
        rw.calcPhenotype(); 
        eintarray phen1=rw.phenotype;
        rw.viablePhenotype=rw.phenotype;
        if (net2.info.findkey("phetarget")!=-1){
            net.info.add("phetarget",net2.info["phetarget"]);
            str2intarr(net2.info["phetarget"],rw.viablePhenotype);
            cout << "# using phetarget from initial network file!"<<endl;
        }
        rw.run_dist2(net2,(num2*2));
        gen2=rw.genotype;
        rw.calcPhenotype();
        eintarray phen2=rw.phenotype;
        fw.write(strr2+"\n");
        fw.write(intarr2str2(gen2)+"\n");
        for (int i=0;i<6588;i++){rw.activate(i);}
        eintarray gen3=rw.genotype;
        fw.write(strr3+"\n");
        fw.write(intarr2str2(gen3)+"\n");
        /////////////////////////////////////////////// Recombination ////////////////////////////////////////
        //////////////////////////// Donor /////////////////////////////   
        eintarray pop;
        for (int i=0; i<num2; ++i) {pop.add(i);}
        int tmp1; 
        for (int i=(num2-1); i>=0; --i) {
            int r = (int)(ernd.uniform()*i);
            tmp1 = pop[r];
            pop[r] = pop[i];
            pop[i]=tmp1;
        } 
        cout<<pop.size()<<endl;
        cout<<intarr2str2(pop)<<endl;
        cout<<"alaki1"<<endl;
        eintarray pop1;
        cout<<"alaki1.3"<<endl;
        for (int j=0;j<num3;j++){
            cout<<j<<endl;
            int x=pop[j];
            cout<<x<<endl;
            pop1.add(x);
        }
        cout<<"alaki1.2"<<endl;
        eintarray sorted1=sort(pop1);
        eintarray selected1;
        for (int j=0;j<num3;j++){
            int y=sorted1[j];
            selected1.add(pop1[y]);
        }
        cout<<"alaki2"<<endl;
        //////////////////////////// Recipient /////////////////////////
        eintarray popp;
       for (int i=682; i<6588; ++i) {
           if (gen2[i]==1){popp.add(i);}
       }
 
       for (int i=(num1-682); i>=0; --i) {
           int r = (int)(ernd.uniform()*i);
           tmp1 = popp[r];
           popp[r] = popp[i];
           popp[i]=tmp1;
       }
       cout<<"alaki3"<<endl;
       eintarray pop2;
       for (int j=0;j<num3;j++){
           int x=popp[j];
           pop2.add(x);
       }
       eintarray sorted2=sort(pop2);
       eintarray selected2;
       for (int j=0;j<num3;j++){
           int y=sorted2[j];
           selected2.add(pop2[y]);
       }
       selected1.add(0);
       selected2.add(0);
       ///////////////////
       cout<<"selected 1:"<<intarr2str2(selected1)<<endl;
       cout<<"selected 2:"<<intarr2str2(selected2)<<endl;
       ////////////////////////////final indexing//////////////////////////
       eintarray final1;
       for (int i=0;i<6588;i++){
           if (gen1[i]==1){
               if (gen2[i]==0){
                  final1.add(i);
               }
           }
       }
      cout<<intarr2str2(final1)<<endl;
      cout<<"palak"<<endl;
      ///////////////// Recombinants and outputing ////////////////////////
      int count1=0;
      int count2=0;
      for (int i=0;i<6588;i++){
        if (gen2[i]==1){  
           if (selected2[count2]==i){gen2[i]=0;count2++;}
           else {}
        }

        else if (gen2[i]==0) {
             if (final1[selected1[count1]]==i){
                 gen2[i]=1;
                 count1++;
             }
        }
        else {}
      }	
       
      cout<<"palak2"<<endl;
      estr strr5="--------------GEN2_after------------";
      fw.write(strr5+"\n");
      fw.write(intarr2str2(gen2)+"\n");
      /////////////////////////////// Phenotyping ////////////////////////
      for (int i=0;i<6588;i++){if (gen2[i]==0){rw.disable(i);}}
      cout<<"palak3"<<endl;
      rw.calcPhenotype();
      estr strr6="--------------Recombinant------------";
      fw.write(strr6+"\n");
      fw.write(intarr2str2(rw.genotype)+"\n");
      cout<<"palak4"<<endl;
      eintarray phen3 = rw.phenotype;
      cout<<"palak5"<<endl;
      for (int i=0;i<6588;i++){if (gen2[i]==0){rw.activate(i);}}
      cout<<"palak6"<<endl;
      estr strr7="--------------final universe------------";
      fw.write(strr7+"\n");
      fw.write(intarr2str2(rw.genotype)+"\n");
      estr faha1="-----------phen1----------------";
      fw.write(faha1+"\n");
      fw.write(intarr2str2(phen1)+"\n");
      estr faha2="-----------phen2----------------";
      fw.write(faha2+"\n");
      fw.write(intarr2str2(phen2)+"\n");
      estr faha3="-----------phen3----------------";
      fw.write(faha3+"\n");
      fw.write(intarr2str2(phen3)+"\n");
  }
  cout<<"palak7"<<endl;
  fw.close();
  fu.close();
  cout<<"palak8"<<endl;


  return(0);
}


