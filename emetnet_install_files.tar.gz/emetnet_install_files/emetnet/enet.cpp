
#include "enet.h"
#include "esbmlparser.h"
#include <eutils/efile.h>
#include <eutils/eregexp.h>
#include <eutils/logger.h>

#include <fstream>


#include <eutils/etable.h>


//#include <ClpSimplex.hpp>
//#include <ClpFactorization.hpp>
//#include <ClpNetworkMatrix.hpp>

const double MAXFLUX = 1E20;

void correct_malformed(elink* link)
{
  int i,j;
  for (i=0;i<link->src.size(); ++i){
    for (j=i+1; j<link->src.size(); ++j){   // found metabolite appearing twice in substrate
      if (link->src[i].node == link->src[j].node){
        link->src[i].rate += link->src[j].rate;
        link->src.erase(j);
        --j;
      }
    }
    for (j=0; j<link->dst.size(); ++j){     // found metabolite appearing in substrate and product of reaction
      if (link->src[i].node == link->dst[j].node){
        link->src[i].rate -= link->dst[j].rate;
        link->dst.erase(j);
        --j;
      }
    }
  }
  for (i=0;i<link->dst.size(); ++i){        // found metabolite appearing twice in product
    for (j=i+1; j<link->dst.size(); ++j){
      if (link->dst[i].node == link->dst[j].node){
        link->dst[i].rate += link->dst[j].rate;
        link->dst.erase(j);
        --j;
      }
    }
  }
}

bool check_malformed(elink* link)
{
  int i,j;
  for (i=0;i<link->src.size(); ++i){
    for (j=i+1; j<link->src.size(); ++j){   // found metabolite appearing twice in substrate
      if (link->src[i].node == link->src[j].node)
        return(true);
    }
    for (j=0; j<link->dst.size(); ++j){     // found metabolite appearing in substrate and product of reaction
      if (link->src[i].node == link->dst[j].node)
        return(true);
    }
  }
  for (i=0;i<link->dst.size(); ++i){        // found metabolite appearing twice in product
    for (j=i+1; j<link->dst.size(); ++j){
      if (link->dst[i].node == link->dst[j].node)
        return(true);
    }
  }
  return(false);
}


void elink::invert()
{
  int i,srcsize;
  srcsize=src.size();
  for (i=0; i<dst.size(); ++i)
    src.add(dst[i]);
  dst.clear();
  for (i=0; i<srcsize; ++i){
    dst.add(src[0]);
    src.erase(0);
  }
}


enet::enet(): transport_count(0) {}
enet::~enet(){}


void enet::correct_malformed()
{
  int i;
  for (i=0; i<links.size(); ++i){
    ::correct_malformed(&links[i]);
  }
}

void enet::remove_malformed()
{
  int i;
  for (i=0; i<links.size(); ++i){
    if (check_malformed(&links[i])){
      links.erase(i); --i;
    }
  }
}


void enet::load_nullmatrix(estr filename)
{
  FILE* f;
  f=fopen(filename._str,"r");
  ldieif(!f,"unable to open file \""+filename+"\"");

  int w,h;

  fscanf(f,"%i",&h);
  fscanf(f,"%i",&w);

  nullmatrixrows=h;

  linfo("matrix of size "+estr(h)+"x"+estr(w)+" found");

//  double *a_data;
  nullmatrix = new double[w*h];

  linfo("reading file... ");
  double val;
  int i;
  for (i=0; i<w*h && fscanf(f,"%lg",&val) != EOF; ++i)
    nullmatrix[i] = val;
}

/*
void enet::load_fluxbounds(estr filename)
{
  efile file(filename);

  if (!file.exists())
    lwarn("limits file does not exist","enet");

  estr data;

  file.read(data);

  data=re_replace(data,"#[^\n]*\n","\n");

  estr line;
  estrarray parts;
  estrarray minmax;

  while(data.len()){
    line=data.getline();
    line.remove_chars(" \t");
    if (!line.len()) continue;

    parts=line.explode("=");
    if (parts.size()<2) { lerror("missing = sign, ignoring...","enet"); continue; }
    
    if (re_strpos(parts[1],"[\\[(]")!=-1)
      { parts[1].del(0,1); parts[1].del(-1); }

    minmax = re_explode(parts[1],"[:;,]");

    fluxbounds[parts[0]] = evector2(0.0,MAXFLUX);
    if (minmax.size()<2)
      fluxbounds[parts[0]].x = minmax[0].d();
    else{
      if (minmax[0].len())
        fluxbounds[parts[0]].x = minmax[0].d();
      if (minmax[1].len())
        fluxbounds[parts[0]].y = minmax[1].d();
    }
  }

  cout << fluxbounds << endl;
}
*/

void enet::load_fast(estr &data)
{
  estr line,left;

  elink* link;
  enode* node;
  estr nodestr;

  int i;
  double rrate;
  estr rratestr;
  estrarray part;
  estrarray infoarr;

  estr info;
  total_elements=0;

  lwarn("loading fast function");
  while (data.len()){
    line = data.getline();

    if (!line.len() || line[0]=='#') continue;

    i=line.find(':');
    if (i!=-1){
      info=line.substr(0,i);
      line.del(0,i+2);
    }

    infoarr = info;
    if (infoarr.size() && infoarr[0].len())
      link = &links.add(infoarr[0],elink());
    else
      link = &links.add("REACTION"+estr(links.size()),elink());
    link->info=infoarr;

    link->active=true;
    link->transport=false;

    i=line.find("-->");
    if (i!=-1){ // irreversible right
      link->irreversible=true;
    } else {
      i=line.find("<=>");
      if (i==-1) { lerror("missing reaction direction --> or <=>"); continue; }
      link->irreversible=false;
    }

    left = line.substr(0,i-1);
    line.del(0,i+4);


    do {
      i=left.find("+");
      if (i!=-1){
        nodestr=left.substr(0,i-1);
        left.del(0,i+2);
      }else{
        nodestr=left;
        left="";
      }

      rrate = 1.0;
      i=nodestr.find("(");
      if (i!=-1){
        nodestr.del(0,i+1);
        i=nodestr.find(")");
        if (i==-1) { lerror("missing \")\" in reaction stoichiometric factor"); continue; }
        rrate=nodestr.d();
        nodestr.del(0,i+2);
      }
      if (nodestr.find("[e]")!=-1) link->transport=true;
      if (nodestr.find("[p]")!=-1) link->transport=true;
      node = getnode(nodestr);

      link->src.add(elinkelem(node,rrate));
      node->links.add(link);
      for (i=0; i<link->src.size(); ++i){
        if (node->nodes.find(link->src[i].node)==-1){
          node->nodes.add(link->src[i].node);
          link->src[i].node->nodes.add(node);
        }
      }
    } while(left.len());

    left=line;
    do {
      i=left.find("+");
      if (i!=-1){
        nodestr=left.substr(0,i-1);
        left.del(0,i+2);
      }else{
        nodestr=left;
        left="";
      }

      rrate = 1.0;
      i=nodestr.find("(");
      if (i!=-1){
        nodestr.del(0,i+1);
        i=nodestr.find(")");
        if (i==-1) { lerror("missing \")\" in reaction stoichiometric factor"); continue; }
        rrate=nodestr.d();
        nodestr.del(0,i+2);
      }
      if (nodestr.find("[e]")!=-1) link->transport=true;
      if (nodestr.find("[p]")!=-1) link->transport=true;
      node = getnode(nodestr);

      link->dst.add(elinkelem(node,rrate));
      node->links.add(link);
      for (i=0; i<link->src.size(); ++i){
        if (node->nodes.find(link->src[i].node)==-1){
          node->nodes.add(link->src[i].node);
          link->src[i].node->nodes.add(node);
        }
      }
      for (i=0; i<link->dst.size(); ++i){
        if (node->nodes.find(link->dst[i].node)==-1){
          node->nodes.add(link->dst[i].node);
          link->dst[i].node->nodes.add(node);
        }
      }
    } while(left.len());

    total_elements+=link->src.size() + link->dst.size();
  }
}

void enet::save(estr filename)
{
  ofstream file;

  file.open(filename._str);
  file << (*this);
  file.close();
}

void enet::getActive(eintarray& arr)
{
  while (arr.size() < links.size())
    arr.add(0);

  int i;
  for (i=0; i<links.size(); ++i){
    if (links[i].active)
      arr[i]=1;
    else
      arr[i]=0;
  }
}

void enet::setActive(eintarray& arr)
{
  lerrorifr(arr.size() != links.size(),"setActive: active array mismatch",);
   
  int i;
  for (i=0; i<links.size(); ++i){
    if (arr[i]!=0)
      links[i].active=true;
    else
      links[i].active=false;
  }
}



void enet::saveactive(eintarray& genotype,const estr& name)
{
  int i,j;
  ofstream file;
  file.open(name._str);
  
  for (i=0; i<info.size(); ++i)
    file << "# " << info.keys(i) << "=" << info.values(i) << endl;

  for (i=0; i<links.size(); ++i){
    if (!links[i].src.size() || !links[i].dst.size() || genotype[i]==0) continue;

    if (links[i].info.size() && links[i].info[0].len())
      file << estr(links[i].info) << ": ";
    for (j=0; j<links[i].src.size()-1; ++j){
      if (links[i].src[j].rate!=1.0)
        file << "("<< links[i].src[j].rate <<") ";
      file << links[i].src[j].node->id << " + ";
    }
    if (links[i].src.size()){
      if (links[i].src[j].rate!=1.0)
        file << "("<< links[i].src[j].rate <<") ";
      file << links[i].src[j].node->id;
    }

    if (links[i].irreversible)
      file << " --> ";
    else
      file << " <=> ";

    for (j=0; j<links[i].dst.size()-1; ++j){
      if (links[i].dst[j].rate!=1.0)
        file << "("<< links[i].dst[j].rate <<") ";
      file << links[i].dst[j].node->id << " + ";
    }
    if (links[i].dst.size()){
      if (links[i].dst[j].rate!=1.0)
        file << "("<< links[i].dst[j].rate <<") ";
      file << links[i].dst[j].node->id;
    }
    file << endl;
  }
}

void enet::saveactive(const estr& name)
{
  int i,j;
  ofstream file;
  file.open(name._str);
  
  for (i=0; i<info.size(); ++i)
    file << "# " << info.keys(i) << "=" << info.values(i) << endl;

  for (i=0; i<links.size(); ++i){
    if (!links[i].src.size() || !links[i].dst.size() || !links[i].active) continue;

    if (links[i].info.size() && links[i].info[0].len())
      file << estr(links[i].info) << ": ";
    for (j=0; j<links[i].src.size()-1; ++j){
      if (links[i].src[j].rate!=1.0)
        file << "("<< links[i].src[j].rate <<") ";
      file << links[i].src[j].node->id << " + ";
    }
    if (links[i].src.size()){
      if (links[i].src[j].rate!=1.0)
        file << "("<< links[i].src[j].rate <<") ";
      file << links[i].src[j].node->id;
    }

    if (links[i].irreversible)
      file << " --> ";
    else
      file << " <=> ";

    for (j=0; j<links[i].dst.size()-1; ++j){
      if (links[i].dst[j].rate!=1.0)
        file << "("<< links[i].dst[j].rate <<") ";
      file << links[i].dst[j].node->id << " + ";
    }
    if (links[i].dst.size()){
      if (links[i].dst[j].rate!=1.0)
        file << "("<< links[i].dst[j].rate <<") ";
      file << links[i].dst[j].node->id;
    }
    file << endl;
  }
}



void enet::load(estr filename)
{
  int predicted_no_reactions;
  estr data;
  efile file(filename);
	if (file.extension()=="sbml" || file.extension()=="xml"){
    loadSBML(filename,*this);
    return;
  }
  predicted_no_reactions = file.size()/42;    // based on some examples, the average chars per reaction is between 47 and 38, we use this to allocate the array

  links.reserve(predicted_no_reactions);
  nodes.reserve((int)(predicted_no_reactions));

  file.read(data);

  if (data.substr(0,8) == "#emetnet")
    load_fast(data);
  else
    load_robust(data);

  int i;
  transport_count=0;
  for (i=0; i<links.size(); ++i){
    links[i].i = i;
    if (links[i].transport==true) ++transport_count;
  }
}

void enet::addlink(estr line)
{
  elink* link;
  enode* node;
  estr nodestr;

  
  int i;
  double rrate;
  estr rratestr;

  estrarray part;
  eregexp re("^ *((\\([0-9]+(\\.[0-9]+)?([Ee]-?[0-9]+)?\\))? *|[0-9]+(\\.[0-9]+)?([Ee]-?[0-9]+)? +)[^+ ]+ *\\+");
  eregexp rerate("^ *(\\([0-9]+(\\.[0-9]+)?([Ee]-?[0-9]+)?\\) *|[0-9]+(\\.[0-9]+)?([Ee]-?[0-9]+)? +)");

  eregexp re_irrev_right("[^-<=](-|=)+>");
  eregexp re_irrev_left("<(-|=)+[^->=]");
  eregexp re_rev("<(-|=)+>");

  eregexp re_sepeq("(<?(-|=)+>|<(-|=)+>?)");

  eregexp re_info("^[^:]+:");

  estr info;
  estrarray infoarr;

  earray<elinkelem> *src;
  earray<elinkelem> *dst;

  line.trim();
  if (!line.len()) return;

  info = re_match(line,re_info);
  line.del(0,info.len());
  info.del(-1);

  infoarr = info;

  if (infoarr.size() && infoarr[0].len())
    link = &links.add(infoarr[0],elink());
  else
    link = &links.add("REACTION"+estr(links.size()),elink());
  link->active=true;
  link->info = info;

  src     = &link->src;
  dst     = &link->dst;
  if (re_strpos(line,re_irrev_right)!=-1) // irreversible right
    link->irreversible=true;
  else if (re_strpos(line,re_irrev_left)!=-1) // irreversible left
    { link->irreversible=true; src = &link->dst; dst=&link->src; }
  else
    link->irreversible=false;

  part = re_explode(line,re_sepeq);
  lddieif(part.size()!=2," reaction separator \"->\" not found, parsing file on line: "+estr((int)links.size()));

  line = part.values(0);
  do {
    nodestr = re_match(line,re);
    if (nodestr.len()){
      line.del(0,nodestr.len());
      nodestr.del(-1);
    }else{
      nodestr=line;
      line="";
    }
    rrate = 1.0;
    rratestr = re_match(nodestr,rerate);
    nodestr.del(0,rratestr.len());
    rratestr.trim();
    if (rratestr.len() && rratestr[0]=='(')
      { rratestr.del(0,1); rratestr.del(-1); } // remove (,)'s from (rate)
    if (rratestr.len())
      rrate=rratestr.d();

    nodestr.trim();
    if (nodestr.find("[e]")!=-1) link->transport=true;
    node = getnode(nodestr);

    src->add(elinkelem(node,rrate));
    node->links.add(link);
    for (i=0; i<src->size(); ++i){
      if (node->nodes.find(src->at(i).node)==-1){
        node->nodes.add(src->at(i).node);
        src->at(i).node->nodes.add(node);
      }
    }
    linfo("srcnode: "+nodestr);
  } while(line.len());

  line = part.values(1);
  do {
    nodestr = re_match(line,re);
    if (nodestr.len()){
      line.del(0,nodestr.len());
      nodestr.del(-1);
    }else{
      nodestr=line;
      line="";
    }

    rrate = 1.0;
    rratestr = re_match(nodestr,rerate);
    nodestr.del(0,rratestr.len());
    rratestr.trim();
    if (rratestr.len() && rratestr[0]=='(')
      { rratestr.del(0,1); rratestr.del(-1); } // remove (,)'s from (rate)
    if (rratestr.len())
      rrate=rratestr.d();

    nodestr.trim();
    if (nodestr.find("[e]")!=-1) link->transport=true;
    node = getnode(nodestr);

    dst->add(elinkelem(node,rrate));
    node->links.add(link);
    for (i=0; i<src->size(); ++i){
      if (node->nodes.find(src->at(i).node)==-1){
        node->nodes.add(src->at(i).node);
        src->at(i).node->nodes.add(node);
      }
    }
    for (i=0; i<dst->size(); ++i){
      if (node->nodes.find(dst->at(i).node)==-1){
        node->nodes.add(dst->at(i).node);
        dst->at(i).node->nodes.add(node);
      }
    }
    linfo("dstnode: "+nodestr);
  } while(line.len());
}

void enet::load_robust(estr &data)
{
  linfo("loading robust function");

  estr line;
  eregexp re_netinfo("^# [^=\n]+=[^\n]+\n");
  re_netinfo.e=0;
  info.clear();
  while(1){
    line=re_match(data,re_netinfo,re_netinfo.e);
    if (line.len()==0) break;
    info.add(line.substr(2,line.find("=")-2),line.substr(line.find("=")+1));
  }

  data=re_replace(data,"#[^\n]*\n","\n");


  elink* link;
  enode* node;
  estr nodestr;

  
  int i;
  double rrate;
  estr rratestr;

  estrarray part;

//  eregexp re("^( *\\([0-9]*\\.?[0-9]+\\))? *[^+ ]+ *\\+");
  eregexp re("^ *((\\([0-9]+(\\.[0-9]+)?([Ee]-?[0-9]+)?\\))? *|[0-9]+(\\.[0-9]+)?([Ee]-?[0-9]+)? +)[^+ ]+ *\\+");
  eregexp rerate("^ *(\\([0-9]+(\\.[0-9]+)?([Ee]-?[0-9]+)?\\) *|[0-9]+(\\.[0-9]+)?([Ee]-?[0-9]+)? +)");

  eregexp re_irrev_right("[^-<=](-|=)+>");
  eregexp re_irrev_left("<(-|=)+[^->=]");
  eregexp re_rev("<(-|=)+>");

  eregexp re_sepeq("(<?(-|=)+>|<(-|=)+>?)");

  eregexp re_info("^[^:]+:");

  estr info;
  estrarray infoarr;
  earray<elinkelem> *src;
  earray<elinkelem> *dst;


  total_elements=0;
//  lwarn("loading with robust (slower) function, if you want to have faster loading times, please convert this file with metnet-conv");
  while (data.len()){
    line = data.getline();

    line.trim();
    if (!line.len()) continue;


    info = re_match(line,re_info);
    line.del(0,info.len());
    info.del(-1);
    infoarr = info;

    if (infoarr.size() && infoarr[0].len())
      link = &links.add(infoarr[0],elink());
    else
      link = &links.add("REACTION"+estr(links.size()),elink());
//    link = &links.add(elink());
    link->active=true;
    link->info = infoarr;
    link->transport=false;

    src     = &link->src;
    dst     = &link->dst;
    if (re_strpos(line,re_irrev_right)!=-1) // irreversible right
      link->irreversible=true;
    else if (re_strpos(line,re_irrev_left)!=-1) // irreversible left
      { link->irreversible=true; src = &link->dst; dst=&link->src; }
    else
      link->irreversible=false;

    part = re_explode(line,re_sepeq);
    lddieif(part.size()!=2," reaction separator \"->\" not found, parsing file on line: "+estr((int)links.size()));

    line = part.values(0);
    do {
      nodestr = re_match(line,re);
      if (nodestr.len()){
        line.del(0,nodestr.len());
        nodestr.del(-1);
      }else{
        nodestr=line;
        line="";
      }
      rrate = 1.0;
      rratestr = re_match(nodestr,rerate);
      nodestr.del(0,rratestr.len());
      rratestr.trim();
      if (rratestr.len() && rratestr[0]=='(')
        { rratestr.del(0,1); rratestr.del(-1); } // remove (,)'s from (rate)
      if (rratestr.len())
        rrate=rratestr.d();

      nodestr.trim();
      if (nodestr.find("[e]")!=-1) link->transport=true;
      if (nodestr.find("[p]")!=-1) link->transport=true;
      node = getnode(nodestr);

      src->add(elinkelem(node,rrate));
      node->links.add(link);
      for (i=0; i<src->size(); ++i){
        if (node->nodes.find(src->at(i).node)==-1){
          node->nodes.add(src->at(i).node);
          src->at(i).node->nodes.add(node);
        }
      }
      linfo("srcnode: "+nodestr);
    } while(line.len());

    line = part.values(1);
    do {
      nodestr = re_match(line,re);
      if (nodestr.len()){
        line.del(0,nodestr.len());
        nodestr.del(-1);
      }else{
        nodestr=line;
        line="";
      }

      rrate = 1.0;
      rratestr = re_match(nodestr,rerate);
      nodestr.del(0,rratestr.len());
      rratestr.trim();
      if (rratestr.len() && rratestr[0]=='(')
        { rratestr.del(0,1); rratestr.del(-1); } // remove (,)'s from (rate)
      if (rratestr.len())
        rrate=rratestr.d();

      nodestr.trim();
      if (nodestr.find("[e]")!=-1) link->transport=true;
      if (nodestr.find("[p]")!=-1) link->transport=true;
      node = getnode(nodestr);

      dst->add(elinkelem(node,rrate));
      node->links.add(link);
      for (i=0; i<src->size(); ++i){
        if (node->nodes.find(src->at(i).node)==-1){
          node->nodes.add(src->at(i).node);
          src->at(i).node->nodes.add(node);
        }
      }
      for (i=0; i<dst->size(); ++i){
        if (node->nodes.find(dst->at(i).node)==-1){
          node->nodes.add(dst->at(i).node);
          dst->at(i).node->nodes.add(node);
        }
      }
      linfo("dstnode: "+nodestr);
    } while(line.len());
	
    bool isperiplasmic=false;
    for (i=0; i<src->size(); ++i) {
      if (src->at(i).node->id.find("[p]") ==-1) {isperiplasmic=true;}
    }
    for (i=0; i<dst->size(); ++i) {
      if (dst->at(i).node->id.find("[p]") ==-1) {isperiplasmic=true;}
    }
    if (isperiplasmic == false) {link->transport=false;}

    bool isextracellular=false;
    for (i=0; i<src->size(); ++i) {
      if (src->at(i).node->id.find("[e]") ==-1) {isextracellular=true;}
    }
    for (i=0; i<dst->size(); ++i) {
      if (dst->at(i).node->id.find("[e]") ==-1) {isextracellular=true;}
    }
    if (isextracellular == false) {link->transport=false;}
	
    if (infoarr.find("nottransport") !=-1)
    {link->transport=false;}

    total_elements+=link->src.size() + link->dst.size();
  }
}

// get node with id "nodeid", if it is not in the list, create a new node with id
enode* enet::getnode(const estr &nodeid)
{
  enode *node;
  node = &nodes[nodeid];
  if (!node->id.len()){
    node->i=nodes.size()-1;
    node->id=nodeid;
  }
  return(node);
}

void enet::addlink(const elink& newlink)
{
  elink* link;

  if (newlink.info.size() && newlink.info[0].len())
    link = &links.add(newlink.info[0],elink());
  else
    link = &links.add("REACTION"+estr(links.size()),elink());
  link->active = newlink.active;
  link->transport = newlink.transport;
  link->info   = newlink.info;
  link->irreversible=newlink.irreversible;

  enode* node;
  int i;
  for (i=0; i<newlink.src.size(); ++i){
    node = getnode(newlink.src[i].node->id);
    link->src.add(elinkelem(node,newlink.src[i].rate)); 
    node->links.add(link);
  }
  for (i=0; i<newlink.dst.size(); ++i){
    node = getnode(newlink.dst[i].node->id);
    link->dst.add(elinkelem(node,newlink.dst[i].rate)); 
    node->links.add(link);
  }
}

float getRate(elink& link, enode& node)
{
  int i;
  for (i=0; i<link.src.size(); ++i){
    if (link.src[i].node == &node)
      return(-link.src[i].rate);
  }
  for (i=0; i<link.dst.size(); ++i){
    if (link.dst[i].node == &node)
      return(link.dst[i].rate);
  }
  return(0.0);
}

void enet::stoichiomatrix(ematrix& m)
{
  int i,j;

  m.create(links.size()-1,nodes.size());
  
  for (i=0; i<nodes.size(); ++i){
    for (j=1; j<links.size(); ++j)
      m(i,j-1)=getRate(links[j],nodes[i]);
  }
}




ostream &operator<<(ostream &stream,enet &net)
{
  int i,j;

//  stream << "#emetnet" << endl;

  for (i=0; i<net.info.size(); ++i)
    stream << "#" << net.info.keys(i) << "=" << net.info.values(i) << endl;

  for (i=0; i<net.links.size(); ++i){
    if (!net.links[i].src.size() || !net.links[i].dst.size()) continue;

    if (net.links[i].info.size() && net.links[i].info[0].len())
      stream << estr(net.links[i].info) << ": ";
    for (j=0; j<net.links[i].src.size()-1; ++j){
      if (net.links[i].src[j].rate!=1.0)
        stream << "("<< net.links[i].src[j].rate <<") ";
      stream << net.links[i].src[j].node->id << " + ";
    }
    if (net.links[i].src.size()){
      if (net.links[i].src[j].rate!=1.0)
        stream << "("<< net.links[i].src[j].rate <<") ";
      stream << net.links[i].src[j].node->id;
    }

    if (net.links[i].irreversible)
      stream << " --> ";
    else
      stream << " <=> ";

    for (j=0; j<net.links[i].dst.size()-1; ++j){
      if (net.links[i].dst[j].rate!=1.0)
        stream << "("<< net.links[i].dst[j].rate <<") ";
      stream << net.links[i].dst[j].node->id << " + ";
    }
    if (net.links[i].dst.size()){
      if (net.links[i].dst[j].rate!=1.0)
        stream << "("<< net.links[i].dst[j].rate <<") ";
      stream << net.links[i].dst[j].node->id;
    }

    stream << endl;
  }
  return(stream);
}

ostream &operator<<(ostream &stream,elink &link)
{
  int j;

  if (link.info.size() && link.info[0].len())
    stream << estr(link.info) << ": ";
  for (j=0; j<link.src.size()-1; ++j){
    if (link.src[j].rate!=1.0)
      stream << "("<< link.src[j].rate <<") ";
    stream << link.src[j].node->id << " + ";
  }
  if (link.src.size()){
    if (link.src[j].rate!=1.0)
      stream << "("<< link.src[j].rate <<") ";
    stream << link.src[j].node->id;
  }

  if (link.irreversible)
    stream << " --> ";
  else
    stream << " <=> ";

  for (j=0; j<link.dst.size()-1; ++j){
    if (link.dst[j].rate!=1.0)
      stream << "("<< link.dst[j].rate <<") ";
    stream << link.dst[j].node->id << " + ";
  }
  if (link.dst.size()){
    if (link.dst[j].rate!=1.0)
      stream << "("<< link.dst[j].rate <<") ";
    stream << link.dst[j].node->id;
  }

  return(stream);
}

enode::enode(): i(-1) {}
enode::enode(const estr &_id): id(_id) {}

enode &enode::operator=(const enode &node)
{ id = node.id; return(*this); }

bool enode::operator==(const enode &node) const
{ return(id==node.id); }


elinkelem::elinkelem() {}
elinkelem::elinkelem(enode *_node,double _rate): node(_node),rate(_rate){}

