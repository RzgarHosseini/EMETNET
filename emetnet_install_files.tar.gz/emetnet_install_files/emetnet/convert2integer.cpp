#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>

int emain() {
//  ldieif(argvc<2,"syntax: ./write-viables <inputfilename.dat>");
	estr sizestr=argv[1];
	epregister(sizestr);
	estrarray parts;
	estr str, intstr;
  eparseArgs(argvc,argv);
	efile f;
	efile sizefile;
	efile files;
	f.open(argv[1],"r");
	int length;
	int j,tmp;
	int intcounter;

	while (f.readln(str)) {			// While the file isn't finished, read line by line
  	parts=str.explode(" ");		// cut the string based on delimiter, here a space, and assign the resulting fields into an array called "parts"
		eintarray tmparr;					// initialize eintarray
		for (j=0; j<parts.size(); ++j) {		// for each index j in array called parts, parts.size = length(parts)
			float floattmp = parts[j].f();
			tmp = (int) floattmp;						// convert index j in parts to integer and assign to integer called tmp 					
			tmparr.add(tmp);			// add the integer tmp to the next index in int array tmparr
		 }
		intstr = intarr2str2(tmparr);						// convert int array tmparr to a string called intstr
		estr test = sizestr+"_final";		// concatanate string "sizestr", int length and .dat and assign to estr test
		files.open(test,"a");
		files.write(intstr+"\n");
		files.close();
	}
}
