#include "enet.h"

#include <eutils/evar.h>
#include <eutils/estrhashof.h>
#include <list>
using namespace std;

bool isSrc(enode* node,elink* link)
{
  int i;
  for (i=0; i<link->src.size(); ++i){
    if (link->src[i].node == node) return(true);
  }
  return(false);
}


void calcWeight(enet& net, estrhashof<float>& arr, estrhashof<bool>& flaged, list<enode*>& nodearr)
{
  int c;
  float flux;

  int i,j; 
  c = nodearr.size();
  while (c){
    for (i=0; i<nodearr.front()->links.size(); ++i){
      flux = nodearr.front()->links[i]->info["FLUX"].f();
      if (isSrc(nodearr.front(),nodearr.front()->links[i])){
        for (j=0; j<nodearr.front()->links[i]->dst.size(); ++j){
          if (flaged[ nodearr.front()->links[i]->dst[j].node->id ]) continue;
          arr[ nodearr.front()->links[i]->dst[j].node->id ] = arr[ nodearr.front()->id ] + flux;
          flaged[ nodearr.front()->links[i]->dst[j].node->id ] = true;
          nodearr.push_back( nodearr.front()->links[i]->dst[j].node );
        }
      }else{
        for (j=0; j<nodearr.front()->links[i]->src.size(); ++j){
          if (flaged[ nodearr.front()->links[i]->src[j].node->id ]) continue;
          arr[ nodearr.front()->links[i]->src[j].node->id ] = arr[ nodearr.front()->id ] - flux;
          flaged[ nodearr.front()->links[i]->src[j].node->id ] = true;
          nodearr.push_back( nodearr.front()->links[i]->src[j].node );
        }
      }
    }
    nodearr.pop_front();
    --c;
  }
  if (nodearr.size())
    calcWeight(net,arr,flaged,nodearr);
}

void normalize(estrhashof<float>& arr)
{
  if (!arr.size()) return;

  int i;
  float max;
  float min;
  min = max = arr[0];
  for (i=1; i<arr.size(); ++i){
    if (arr[i]<min) min=arr[i];
    if (arr[i]>max) max=arr[i];
  }

  if (min==max) return;

  float iw;
  iw=1.0/(max-min);
  for (i=0; i<arr.size(); ++i)
    arr[i]=(arr[i]-min)*iw;
}


int main(int argvc,char *argv[])
{
  ldieif(argvc<2,"syntax: metnet-weights <net>");

  enet net;
  net.load(argv[1]);

  estrhashof<float> arr;
  estrhashof<bool>  flaged;
  int i;
  for (i=0; i<net.nodes.size(); ++i){
    arr.add(net.nodes[i].id,0);
    flaged.add(net.nodes[i].id,false);
  }

  list<enode*> nodearr;
  nodearr.push_back(&net.nodes[0]);

  calcWeight(net,arr,flaged,nodearr);

  normalize(arr);

  for (i=0; i<net.nodes.size(); ++i)
    cout << net.nodes[i].id << "  " << arr[ net.nodes[i].id ]<<endl;
  
  return(0);
}

