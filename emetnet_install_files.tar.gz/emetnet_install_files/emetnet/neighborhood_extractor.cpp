#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <vector>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
using std::vector;


double carbon_source=-1;
double genotype_size=0;
double hamming_distance=-1;

int emain()
{
ldieif(argvc<8,"syntax: ./neighborhood_extractor <inputfile> <outputfile> -carbon_source <index> -genotype_size <y> -hamming_distance <x>" );

epregister(carbon_source);
epregister(genotype_size);
epregister(hamming_distance);
eparseArgs(argvc,argv);
///////////////////////////////////////////////////////////
double index=carbon_source;
double y=genotype_size;
double x=hamming_distance;
efile fin;
estr str1;
estrarray parts;
fin.open(argv[1],"r");
int novel=0;
double diverse=0;
int counter1=0;
int counter2=0;
while (fin.readln(str1)) {
      parts=str1.explode(" ");
      int vec[3];for (int i=0;i<3;++i){vec[i]=0;}
      for (int i=0; i<parts.size(); ++i){vec[i]=parts[i].i();}
      cout<<"##########################################################"<<endl;
      int x=vec[0]+vec[1]+vec[2];
      int x1=vec[0]+vec[1];
      int x2=vec[0]+vec[2];
      int x3=vec[1]+vec[2];
      double div=((double) x1/(double) x);
      estr x1str=(double) x1;
      estr x2str=(double) x2;
      estr x3str=(double) x3;
      estr xstr=(double) x;
      estr divstr=div;
      cout<<xstr<<endl;
      cout<<x1str<<endl;
      cout<<x2str<<endl;
      cout<<x3str<<endl;
      cout<<divstr<<endl;
      novel=novel+x2+x3;counter1=counter1+2;
      if (x>0){diverse=diverse+div;counter2=counter2+1;} 
}
double nov_doub=(double) novel;
fin.close();

estr novel_str2=nov_doub;
estr diverse_str2=diverse;
cout<<novel_str2<<endl;
cout<<diverse_str2<<endl;
double novel_final=((double) novel/(double) counter1);
double diverse_final;
cout<<counter2<<endl;
if (counter2==0){ diverse_final=0;}
else { diverse_final=((double) diverse/(double) counter2);}
cout<<"**************************"<<endl;
estr divstr3=diverse_final;
cout<<divstr3<<endl;
cout<<"**************************"<<endl;
efile fout;
fout.open(argv[2],"a");
estr index_str=index;
estr y_str=y;
estr x_str=x;
estr novel_str=novel_final;
estr diverse_str=diverse_final;
fout.write(index_str+" "+y_str+" "+x_str+" "+novel_str+" "+diverse_str+"\n");
fout.close();
return(0);
}


