#ifndef __EDRAWLINK__
#define __EDRAWLINK__

#include "edrawnet.h"

class edrawnet;
class edrawnode;

class edrawlink
{
 public:
  edrawnet* drawnet;
  elink* link;
  int color;

  bool selected;
  bool highlite;

  edrawnode* src;
  edrawnode* dst;
  
  earray<edrawnode*> srcnodes;
  earray<edrawnode*> dstnodes;

  edrawlink(edrawnet* drawnet,elink& link,const estr& rpair,const evector2& pos);
  edrawlink(edrawnet* drawnet,elink& link,enode* rootnode,const evector2& pos);
  ~edrawlink();

  void draw();
  void update();

  bool inLink(edrawnode* node);
};

#endif

