#ifndef ENLSOLVER_NLOPT_H
#define ENLSOLVER_NLOPT_H

#include "esolver.h"
#include <nlopt.h>

class enlsolver_nlopt : public esolver
{
 public:
  nlopt_opt nlp;
  
  enlsolver_nlopt();
  ~enlsolver_nlopt();

  void setobjective(int i,double value=1.0);
  void setobjective(evector& obj);

  void setxbounds(int i,double min,double max);
  void setybounds(int i,double min,double max);

  void parse(ematrix& m,evector& lower,evector& upper,evector& xlower,evector& xupper,evector& objective);

  void parse(enet& net);
  double solve();

  void activate(int i);
  void disable(int i);

  void setActive(const eintarray& arr);
};

#endif

