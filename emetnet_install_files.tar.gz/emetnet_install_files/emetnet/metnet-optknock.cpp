#include "enet.h"
#include "esolver_clp.h"

#include <eutils/emain.h>
#include <eutils/ernd.h>


enet net;
esolver_clp solver;


int emain()
{
  float t=1;  //tradeoff
  epregister(t);
  float b=0.8;  //biomass threshhold
  epregister(b);
  float y=1; //bufferring allowed for yield production
  epregister(y);
  int nsample = 1;
  epregister(nsample);
  int reportKO=10; // Number of maximum KO's you want to print out
  epregister(reportKO);
  float reportfmaxt=0.25; //The fmax threshold you want to print out
  epregister(reportfmaxt); 
  eparseArgs(argvc,argv);
  ldieif (argvc<4,"syntax: "+efile(argv[0]).basename()+" <file.net> <env.net> <compound>");  

  net.load(argv[1]);

//  solver.internal_secretion=1;
  solver.parse(net);
  solver.load_fluxbounds(argv[2]);

  int inode;
  inode=net.nodes.findkey(argv[3]);
  ldieif(inode==-1,"Metabolite not found: "+estr(argv[3]));

  float growth;
  growth=solver.solve();
  cout << "# growth: " << growth << endl;
  solver.setxbounds(0,b*growth,1.0e20);

  float fmingrowth,fmaxgrowth;
  float fmin,fmax,originalfmax;

  solver.setNodeBounds(net.nodes.at(inode).id,-1000.0,1000.0);
  solver.setobjective(net.links.size()+inode);
  solver.solve();
  fmax=solver.x[net.links.size()+inode];
  originalfmax=fmax;
  fmaxgrowth=solver.x[0];

  solver.setobjective(net.links.size()+inode,-1);
  solver.solve();
  fmin=solver.x[net.links.size()+inode];
  fmingrowth=solver.x[0];
  cout << "# min: " << fmin << " ("<<fmingrowth<<")  max: " << fmax << " (" << fmaxgrowth << ")"<< endl;

  int esscount=0;
  int activereactions=net.links.size()-1;
  eintarray ess;
  eintarray essmaster;
  int i;
  for (i=0; i<net.links.size(); ++i)
    {essmaster.add(0); ess.add(0);}

 int k;
 for (k=0; k<nsample; k++) { 

   for (i=0; i<net.links.size(); ++i) {
     ess[i]=0;
     if (!net.links[i].active) solver.activate(i); 
   }    
  activereactions=net.links.size()-1;
  esscount=0;
  solver.setNodeBounds(net.nodes.at(inode).id,originalfmax*t,1000.0);
  solver.setobjective(0);

  int randr; 
  while (esscount<activereactions){
    randr=(activereactions-esscount)*ernd.uniform();
    for (i=1; i<net.links.size(); ++i) { if (ess[i]==1 || !net.links[i].active) continue; if (randr==0) break; --randr; }
    ldieif(i==net.links.size() || !net.links[i].active || ess[i]==1,"something wrong!!");
    solver.disable(i);
    float res=solver.solve();
    if (res==-1.0){
      ess[i]=1;
      ++esscount;
      solver.activate(i);
//      cout << "#- "<< net.links[i].info[0] << " " << activereactions << " " << esscount << endl;
    } else {
      --activereactions;
//      cout << "- " << net.links[i].info[0] << " " << activereactions << " " << esscount << endl;
    }
  }
//Checking
float growth_minnet = solver.solve();
	if (growth_minnet <= 0) {
    --k;
		cout << " Minnet has fuckedup growth : " << growth_minnet <<endl;
    continue;
	}
// Checking routing over

  solver.setNodeBounds(net.nodes.at(inode).id,-1000.0,1000.0);
  solver.setobjective(net.links.size()+inode);
  solver.solve();
  fmax=solver.x[net.links.size()+inode];
  fmaxgrowth=solver.x[0];

  solver.setobjective(net.links.size()+inode,-1);
  solver.solve();
  fmin=solver.x[net.links.size()+inode];
  fmingrowth=solver.x[0];
  //cout << "# min: " << fmin << " ("<<fmingrowth<<")  max: " << fmax << " (" << fmaxgrowth << ")"<< endl;
  if (fmin <= 0) {
//    cout << "# minimal network is fucked up, fmin= " << fmin << endl;
    --k;
    continue;
  }

  float mfmin=fmin;
  float fminthresh;
  if (fmin < 0) {fminthresh=fmin/y;}
  else {fminthresh = fmin*y;}
  esscount=0;
  for (i=0; i<net.links.size(); ++i)
    ess[i]=0;

  solver.setobjective(net.links.size()+inode,-1);
  while (esscount<net.links.size()-1-activereactions){
    randr=(net.links.size()-1-activereactions-esscount)*ernd.uniform();
    for (i=1; i<net.links.size(); ++i) { if (ess[i]==1 || net.links[i].active) continue; if (randr==0) break; --randr; }
    ldieif(i==net.links.size() || net.links[i].active || ess[i]==1,"something wrong!!");
    solver.activate(i);
    solver.solve();
    fmin=solver.x[net.links.size()+inode];
    if (fmin<fminthresh){
      ess[i]=1;
      ++esscount;
      solver.disable(i);
//      cout << "#+ "<< net.links[i].info[0] << " " << mfmin  << " " << fminthresh << " " << fmin << " " << activereactions << " " << esscount << " " << endl;
    } else {
      ++activereactions;
//      cout << "+ " << net.links[i].info[0] << " " << mfmin << " " << fminthresh << " " << fmin << " " << activereactions << " " << esscount << endl;
    }
  }

  
  solver.setNodeBounds(net.nodes.at(inode).id,-1000.0,1000.0);
  solver.setobjective(net.links.size()+inode);
  solver.solve();
  fmax=solver.x[net.links.size()+inode];

  solver.setobjective(net.links.size()+inode,-1);
  solver.solve();
  fmin=solver.x[net.links.size()+inode];
  cout << k << " # min: " << fmin << " ("<<fmingrowth<<")  max: " << fmax << " (" << fmaxgrowth << ") "<< esscount << endl;

  for (i=0; i<net.links.size(); ++i)
    if (ess[i]==1) {
//     solver.activate(i);
      essmaster[i]++;
//      if (esscount <= reportKO && fmin >= originalfmax*reportfmaxt) {	cout << "    " << net.links[i] << endl;}
      cout << "    " << net.links[i] << endl;
    }
//  cout << net.links[i] << endl;
//  net.saveactive("min.net");
  }
/*
  int essinstance=0;
  for (i=0; i<net.links.size(); ++i) {
    if (essmaster[i] > 0) {
      cout << "# count: " << essmaster[i] << " : " << net.links[i] << endl; 
      essinstance++;
    }
  }
  cout << "# Number of reactions with KO instance at least one: " << essinstance << endl;
*/
  return(0);
}
