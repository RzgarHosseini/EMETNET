#include "enet.h"
#include "erandomwalk.h"
#include <eutils/estrarrayof.h>
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <eutils/ernd.h>
#include <signal.h>
#include <math.h>

estr outnet="randomw-default";
estr solver="esolver_clp";
int netsize=-1;
int strict=0;
int force_away=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
int niter=10000;
int rsize=2078;

enet net;
enet net2;


erandomWalk *prw=0x00;

void save_state(int)
{
  efile f1("state.dat");
  f1.open("w");

  f1.write("strictViable="+estr(strict)+"\n");
  f1.write("periphery_only="+estr(periphery_only)+"\n");
  f1.write("mutate_transport"+estr(mutate_transport)+"\n");
  f1.write("internal_secretion="+estr(internal_secretion)+"\n");
  f1.write("iterations="+estr(niter)+"\n");
  if (prw)
    f1.write("net=eintarray("+intarr2str(prw->genotype)+")\n"); 
  f1.close();
  exit(0);
}


int emain()
{
	int gentries=1;
  epregister(outnet);
  epregister(solver);
  epregister(netsize);
  epregister(strict);
  epregister(force_away);
  epregister(periphery_only);
  epregister(mutate_transport);
  epregister(internal_secretion);
  epregister(only_viable);
  epregister(niter);
	epregister(rsize);
	epregister(gentries);

  eparseArgs(argvc,argv);

  ldieif(argvc<=3,"syntax: ./metnet-samplefreq [--outnet output.net] [--rsize ref_size] [--gentries 1] <kegg.net> <rfrq.dat> <fluxbounds.flx>");


//  cout << "# environment: "<<argv[3] << endl;
  net.load(argv[1]); 
//  cout << "# global network: "<<argv[1] << endl;
//  cout << "# reactions (global): " << net.links.size() << endl;
  net.correct_malformed();
//  cout << "# non-malformed reactions: " << net.links.size() << endl;

//  net2.load(argv[2]);
 // net.correct_malformed();
//  cout << "# initial network: "<<argv[2] << endl;
//  cout << "# reactions (initial): " << net2.links.size() << endl;

  estrarray rfrq;
  rfrq.load(argv[2]);

  erandomWalk rw(net,solver,strict);
  prw=&rw; 

  rw.periphery_only=periphery_only;
  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;
  rw.only_viable=only_viable;
  rw.setRSize(netsize);

  rw.getEnv(argvc,argv);

  rw.load(net);

  rw.calcPhenotype();
  rw.viablePhenotype=rw.phenotype;

	// the frequencies are integers. 
	eintarray genpool,superess,essreaction_index;
  earray<double> rfreq;
  int i,j,r_on,r_off;
	j = 0;
  for (i=0; i<rw.genotype.size(); ++i) {
    genpool.add(1);
		superess.add(0);
    rfreq.add(0.0);
	}

	// adding frequencies to an int array
  for (i=0; i<rfrq.size(); ++i){
    genpool[net.links[rfrq.keys(i)].i]=rfrq.values(i).i();
//		cout << rfrq	.values(i).i() <<endl;
  }

// Converting integers to a double and adding them to an a double array
	double tmp = 0.000;
  for (i=0; i<rfrq.size(); ++i){
		tmp = genpool[i]*0.001;
		rfreq[i]=tmp;
  }
	
	// switching off all reactions except transport and biomass reactions 	
	int transport_count = 0;
	j=0;
  for (i=0; i<net.links.size(); ++i){
    if (net.links[i].transport || rfreq[i]==1.0) {
//      ++transport_count;
  	}
		else {	
		rw.disable(i);
		++j;
		}
	}

	int quotient=0;
	int r,rsize2;
	cout << "# Reactions switched on after disabling: " << rw.acount << endl;
	j = rw.acount;

/// Choosing a random reaction and switching it on!
	while (j<=rsize) {
		r=((int)(ernd.uniform()*rw.net->links.size()-1)+1);
		if (!rw.genotype[r]) {rw.activate(r); ++j;}
	}
	cout << " # Number of randomly chosen reactions switched on: " << rw.acount << endl;
	
	r_on = r_off = j= 0;
	int k = 0;
	double p_swap=0.0;
	double p_off, p_on;

	// beginning the swapping process
	for (i=1; i<=niter; ++i){

		// choosing an off reaction
		while (1) {
			r_off=((int)(ernd.uniform()*rw.net->links.size()-1))+1;
				if (rw.genotype[r_off]==0 && !net.links[r_off].transport) { break;}
		}
		// choosing an on reaction
		while (1) {
			r_on=((int)(ernd.uniform()*rw.net->links.size()-1))+1;
			if (rw.genotype[r_on]==1 && !net.links[r_on].transport && rfreq[r_on]< 1.0) {break;}
		}
		
		// computing p_swap and swapping

//		p_off= (rfreq[r_off])*(rsize/6588);
//		p_on = (rfreq[r_on])*(rsize/6588);
//		p_off= rfreq[r_off]*rfreq[r_off]*rfreq[r_off]*rfreq[r_off]*rfreq[r_off]*rfreq[r_off]*rfreq[r_off]*rfreq[r_off]*rfreq[r_off]*rfreq[r_off];
//		p_on = rfreq[r_on]*rfreq[r_on]*rfreq[r_on]*rfreq[r_on]*rfreq[r_on]*rfreq[r_on]*rfreq[r_on]*rfreq[r_on]*rfreq[r_on]*rfreq[r_on];


		p_off = rfreq[r_off]*rfreq[r_off]*rfreq[r_off];
		p_on = rfreq[r_on]*rfreq[r_on]*rfreq[r_on];
		p_swap=((p_off*(1-p_on))/((1-p_off)*p_on)); pow(p_on,2)
		p_swap=p_swap*p_swap*p_swap;
//		p_swap=((p_off)/(p_on));
		
		if (p_swap >= 1) {
			rw.activate(r_off);
			rw.disable(r_on);
			++j;
//			cout << "+" << net.links[r_off].info[0] << " (" << p_off <<")" << " : -" << net.links[r_on].info[0] << " (" << p_on << ") "  << i <<endl;
		}
		else {
			tmp = ernd.uniform();
			if (p_swap > tmp) {
				rw.activate(r_off);
				rw.disable(r_on);
				++k;
//				cout << "+" << net.links[r_off].info[0]  << " : -" << net.links[r_on].info[0] << " : " <<  p_swap  << " : " << tmp << " "  << i << endl;
			}
//			else {cout << "### +" << net.links[r_off].info[0] << " (" << rfreq[r_off]<<")" << " : -" << net.links[r_on].info[0] << " (" << rfreq[r_on]<< ") : pswap = "  << p_swap << " : " << tmp << "   " << i <<endl;}
		}
		
	}
	
//	rw.genotype[0]=1;
	rw.calcPhenotype();
	if (rw.isViable()){
//		net.saveactive(outnet);
		net.saveactive(outnet);
		cout << " # genotype saved :: Accepted swaps " << j  << " :: Accepted metropolis swaps " << k <<  endl;
	}
	else {cout << " # genotype attempt unsuccessful :: Accepted swaps " << j << " :: Accepted metropolis swaps " << k <<  endl; }
  return(0);
}
