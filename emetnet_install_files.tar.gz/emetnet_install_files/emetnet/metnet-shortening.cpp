#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>

estr solver="esolver_clp";

int strict=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
enet net;
erandomWalk *prw=0x00;

int num=0; //number of reactions in the ultimate networks
int num2=0;//number of reactions in the initial networks
int cs=-1;
estr outnet="out.net";


int emain()
{ ldieif(argvc<4,"syntax: ./metnet-shortening <universe.net> <file.dat> --outnet  --num  --num2 --cs <fluxbounds.flx>");  
  epregister(num);
  epregister(num2);
  epregister(outnet);
  epregister(cs);
  eparseArgs(argvc,argv);
  epregister(solver);
  epregister(strict);
  epregister(periphery_only);
  epregister(mutate_transport);
  epregister(internal_secretion);
  epregister(only_viable); 
  int netsize=2078; 
  //////////////////////////////////////////////////////////// Genotyping ////////////////////////////////////////////////////
  //////////////////////
  enet net;
  net.load(argv[1]);
  net.correct_malformed();
  erandomWalk rw(net,solver,strict);
  prw=&rw; 
  rw.periphery_only=periphery_only;
  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;
  rw.only_viable=only_viable;
  rw.getEnv(argvc,argv);
  rw.load(net);  
  net.correct_malformed();
  rw.calcPhenotype();
  efile fe;
  fe.open(argv[2],"r");
  efile fw;
  fw.open(outnet,"a");
  estr sttr;
  //////////////////////
  eintarray gen;
  int tmp=0;
  while (fe.readln(sttr)) {
	estrarray parts;
        parts=sttr.explode(" ");
        for (int i=0;i<6588;i++){gen.add(tmp);}
        for (int i=0;i<6588;i++){gen[i]=parts[i].i();}
  }
  fe.close();
  
  int od=0;
  int count=num2;
  while (od==0){
        int id=0;
        while (id==0){
               int r = (int)((ernd.uniform()*(6588-682))+682);
               if (gen[r]==1){
                   gen[r]=0;
                   for (int i=0;i<6588;i++){if (gen[i]==0){rw.disable(i);}}
                   rw.periphery_only=periphery_only;
                   rw.mutate_transport=mutate_transport;
                   rw.internal_secretion=internal_secretion;
                   rw.only_viable=only_viable;
                   rw.setRSize(netsize);
                   rw.calcPhenotype(); 
                   eintarray phen=rw.phenotype;
                   if (phen[cs]==1){count--;id=1;}
                   else {gen[r]=1;}
                   for (int i=0;i<6588;i++){rw.activate(i);}
               } 
        estr tapa=(double) count;
        cout<<"********************************************"<<endl;
        cout<<tapa<<endl;  
        }
        if (count==num){od=1;}
  }
  fw.write(intarr2str2(gen)+"\n");
  fw.close();
  return(0);
}


