
#include "enet.h"
#include "esolver_clp.h"

#include <eutils/emain.h>

#include <fstream>
#include <iomanip>

enet net;
esolver_clp solver;

void print_flux(ofstream& f,enet& net)
{
  int i;
  double *primalColumns;
  
  primalColumns = solver.model->primalColumnSolution();
//  f << setprecision(4) << setw(6);
  for (i=0; i<net.links.size(); ++i){
    if (net.links[i].active && primalColumns[i]!=0.0){
      f << net.links[i].info[0] << "("<<i<<") ";
      f << primalColumns[i] << endl;
    }
  }
}

bool isSrc(enode* node,elink* link)
{
  int i;
  for (i=0; i<link->src.size();++i){
    if (link->src[i].node == node) return(true);
  }
  return(false);
}

bool isDst(enode* node,elink* link)
{
  int i;
  for (i=0; i<link->dst.size();++i){
    if (link->dst[i].node == node) return(true);
  }
  return(false);
}


void find_cycles_iter(vector<bool>& visited,list<enode*>& nlist,double *fx,int iter)
{
  enode* node;
  int i,j,k;
  int len;

  cout <<" >> "<< iter << endl;
  len = nlist.size();
  for (i=0; i<len; ++i){
    node = nlist.front();
    nlist.pop_front();
    for (j=0; j<node->links.size(); ++j){
      if (fx[ node->links[j]->i ] > 0.0 && isSrc(node,node->links[j])){
        for (k=0; k<node->links[j]->dst.size(); ++k){
          if (!visited[ node->links[j]->dst[k].node->i ]){
            nlist.push_back(node->links[j]->dst[k].node);
            visited[ node->links[j]->dst[k].node->i ]=true;
          }else{
            cout << "cycle!" << endl;
          }
        }
      } else if (fx[ node->links[j]->i ] < 0.0 && isDst(node,node->links[j])){
        for (k=0; k<node->links[j]->src.size(); ++k){
          if (!visited[ node->links[j]->src[k].node->i ]){
            nlist.push_back(node->links[j]->src[k].node);
            visited[ node->links[j]->src[k].node->i ]=true;
          }else{
            cout << "cycle!" << endl;
          }
        }
      }
    }
  }

  ++iter;
  if (nlist.size())
    find_cycles_iter(visited,nlist,fx,iter);


}

void find_cycles(enet& net,esolver_clp& solver)
{
  int i;
  double *x;
  double *fx;

  x= solver.model->primalRowSolution();
  fx= solver.model->primalColumnSolution();

  cout << solver.net->fluxbounds << endl;


  vector<bool>  visited;
  list<enode*> nlist;

  for (i=0; i<net.nodes.size(); ++i)
    visited.push_back(false);

  for (i=0; i<net.fluxbounds.size(); ++i){
    if (x[ net.nodes[ net.fluxbounds.keys(i) ].i ]<0.0){
      nlist.push_back(&net.nodes[ net.fluxbounds.keys(i) ]);
      visited[ net.nodes[ net.fluxbounds.keys(i) ].i ]=true;
    }
  }

  find_cycles_iter(visited,nlist,fx,0);
}


int main()
{
  ldieif (argvc<2,"syntax: ./metnet-clp <file.net>");  

  net.load(argv[1]);
  net.correct_malformed();


  solver.parse(net);
  if (argvc>2)
    solver.load_fluxbounds(argv[2]);
  else
    solver.load_fluxbounds();
 
  cout << "objective function result: "<< solver.solve() << endl;
  
  find_cycles(net,solver); 
  


/*
  ofstream f;
  f.open("flux_vector.dat");
  print_flux(f,net);
*/
  

//  cout << net << endl;


  return(0);
}
