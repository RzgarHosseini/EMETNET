#include "enet.h"
#include "erandomwalk.h"

#include <eutils/emain.h>
#include <eutils/ernd.h>


int emain()
{
  ldieif (argvc<4,"syntax: ./metnet-genphedist <file.net> <starter.net> <env.flx env2.flx ...>"); 

  int phe=3;

  estr file1,file2;
  enet netf1,netf2;

  estr outnet="default.net";
  epregister(phe);
  epregister(outnet);
  epregister(file1);
  epregister(file2);

  cout << "file1: " << file1 << ", file2: " << file2<<endl;


  estr solver="cplex";
  epregister(solver);

  enet net;
  net.load(argv[1]); 
  net.correct_malformed();

  enet net2;
  net2.load(argv[2]);

  enet net3;
  if (argvc>3 && estr(argv[3]).substr(-4) == ".net")
    net3.load(argv[3]);
  else
    net3.load(argv[2]);

  erandomWalk rw(net,solver,1);


  cout << "# number of total reactions: " << net.links.size() << endl;
  cout << "# finished loading file: "<<argv[1] << endl;
  cout << "# Number of total reactions in model: "<<net.links.size()<<endl;

  int i;
  for (i=3; i<argvc; ++i){
    if (estr(argv[i]).substr(-4) != ".flx") continue;
    rw.addEnv(argv[i]);
  }
  ldieif(phe>=rw.solvers.size(),"selected phenotype ("+estr(phe)+") count is higher than total phenotypes ("+estr(rw.solvers.size())+")");

  cout << "# Setting up starter network" << endl;
  rw.load(net2);
  rw.calcPhenotype();

  int m,tmpmin;
  eintarray phe_f,gen_f;
  phe_f=rw.phenotype;
  gen_f=rw.genotype;

  m=countPhenotype(phe_f);
  cout << "# Initial network phenotype grows on " << m <<" carbon sources"<<endl;

  eintarray phe_s,gen_s;
  eintarray gen_s2,phe_s2;


  if (file1.len()){
    netf1.load(file1);
    rw.load(netf1);
    rw.calcPhenotype();
    cout << "# Loading file1: " << file1 << ", phenotype: "<<rw.printPhenotype() << endl;
  }else{
    cout << "# Looking for phenotype P1 that grows on " << phe <<" carbon sources"<<endl;
 
    i=0;
    while (m!=phe){
      rw.mutate();
      rw.updatePhenotype();

      tmpmin = countPhenotype(rw.phenotype);
      if (tmpmin > m || tmpmin==0 || tmpmin < phe){ rw.revert(); continue; }
      cout << rw.printPhenotype() << endl;

      m=tmpmin;
      if (m == phe){
        cout << "# Found genotype G1 wich grows on "<<m<<" carbon sources: "<< rw.printPhenotype() << endl;
        break;
      }
      ++i;
      if (i==10000){
        cout << "# warning: genotype for this phenotype was not found in 10'000 iterations, stoping simulation"<<endl;
        exit(1);
      }
    }
  
  
    gen_s = rw.genotype;
    phe_s = rw.phenotype;
  
    rw.load(net3);
    rw.calcPhenotype();
  
    if (phe_s == rw.phenotype)
      ldie("the two networks have the same phenotype!!");

    phe_f=rw.phenotype;
    gen_f=rw.genotype;

    rw.load(gen_s);
    rw.phenotype=phe_s;  

    net.saveactive("starter1_"+outnet);

    cout << "# Starting forced random walk (1000 iterations) away from found network" << endl;
    for(i=0; i<1000; ++i){
      rw.mutate_away(gen_s);
      rw.updatePhenotype();
      if (rw.phenotype != phe_s){ rw.revert(); rw.phenotype=phe_s; continue; }
    }
    cout << "# Final distance from starter network: " <<gendistance(gen_s,rw.genotype)<<endl;
//    net.saveactive("starter1rw_"+outnet);
  }

  eintarray gen_g1;
  gen_g1=rw.genotype;


  if (file2.len()){
    netf2.load(file2);
    rw.load(netf2);
    rw.calcPhenotype();
    phe_s2=rw.phenotype;
    cout << "# Loading file2: " << file2 << ", phenotype: "<<rw.printPhenotype() << endl;
  }else{
    cout << "# Looking for phenotype P2 that grows on " << phe <<" carbon sources"<<endl;
    rw.load(gen_f);
    rw.phenotype=phe_f;

    m=countPhenotype(phe_f);
    i=0;
    while (m!=phe){
      rw.mutate();
      rw.updatePhenotype();

      tmpmin = countPhenotype(rw.phenotype);
      if (tmpmin > m || tmpmin==0 || tmpmin < phe){ rw.revert(); continue; }
      cout << rw.printPhenotype() << endl;

      m=tmpmin;
      if (m == phe){
        if (rw.phenotype == phe_s){
          cout << "# Found same phenotype as P1, looking for another phenotype!" << endl;
          i=0;
          rw.load(gen_f);
          rw.phenotype = phe_f;
          m = countPhenotype(phe_f);
        }else{
          cout << "# Found genotype G2 wich grows on "<<m<<" carbon sources: "<< rw.printPhenotype() << endl;
          break;
        }
      }
      ++i;
      if (i==10000){
        cout << "# warning: genotype for this phenotype was not found in 10'000 iterations, stoping simulation"<<endl;
        exit(1);
      }
    }

    gen_s2 = rw.genotype;
    phe_s2 = rw.phenotype;
    net.saveactive("starter2_"+outnet);

    cout << "# Starting forced random walk (1000 iterations) away from initial metnet" << endl;
    for(i=0; i<1000; ++i){
      rw.mutate_away(gen_s2);
      rw.updatePhenotype();
      if (rw.phenotype != phe_s2){ rw.revert(); rw.phenotype=phe_s2; continue; }
    }
    cout << "# Final distance from starter network: " <<gendistance(gen_s2,rw.genotype)<<endl;
//    net.saveactive("starter2rw_"+outnet);
  }

  eintarray gen_g2;
  gen_g2=rw.genotype;

  cout << "------------------------"<<endl<<endl;
  cout << "Starting G2 random walk towards G1"<<endl;

  for(i=0; i<1000; ++i){
    if (rw.mutate_toward(gen_g1)==-1) { lwarn("no more available mutations!!"); break; }
    rw.updatePhenotype();
    if (phe_s2 != rw.phenotype){ rw.revert_toward(); rw.phenotype = phe_s2; continue; }
    cout << i <<" " <<gendistance(gen_g2,rw.genotype) << " " << gendistance(gen_g1,rw.genotype) << endl;
  }
  cout << "Final distance (G2f,G1): "<<gendistance(gen_g1,rw.genotype)<< endl;
  cout << "Final distance (G2f,G2): "<<gendistance(gen_g2,rw.genotype)<< endl;

  net.saveactive(outnet);
  
  return(0);
}
