#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>

estr solver="esolver_clp";
int netsize=-1;
int strict=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
double gendist=0.0;
enet net;
erandomWalk *prw=0x00;


int emain()
{ ldieif(argvc<4,"syntax: ./phenotyping_ccm  <file.net> <file.dat> <fluxbounds.flx>");  
  eparseArgs(argvc,argv);
////////////////////////////////////////////////////////////// Genotyping /////////////////////////////////////////////////////////////////
  net.load(argv[1]); 
  net.correct_malformed();
  erandomWalk rw(net,solver,strict);
  prw=&rw; 
  rw.periphery_only=periphery_only;
  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;
  rw.only_viable=only_viable;
  rw.setRSize(netsize);
  rw.getEnv(argvc,argv);
  rw.load(net);
  efile file1;
  efile fout;
  file1.open(argv[2],"r");
  estr filein=argv[2];
  estr fileout=filein+"_phenotype";
  fout.open(fileout,"w");
  cout<<"gova1"<<endl;
  estr str;
  estrarray parts;
  while (file1.readln(str)) {	
  	 parts=str.explode(" ");		// cut the string based on delimiter, here a space, and assign the resulting fields into an array called "parts"
	 for (int j=0; j<parts.size(); ++j) {int temp=parts[j].i(); rw.disable(temp);} 
         cout<<"gova2"<<endl;
         rw.calcPhenotype(); 
         eintarray phen = rw.phenotype;
         estr intstr = intarr2str2(phen);
         cout<<intstr<<endl;
         fout.write(intstr+"\n"); 
         cout<<"gova3"<<endl;
	 for (int j=0; j<72; ++j) {rw.activate(j);} 
         cout<<"gova4"<<endl; 
  }
 
  fout.close();
  return(0);
}
