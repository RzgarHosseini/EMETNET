#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <vector>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
using std::vector;

// array that will store pre-computed number of "on" bits in a 16bit value
char precomp_count_16bits[0x1u<<16];
// function to compute how many "on" bits exist in a 32bit (int) value
inline char count_bits(unsigned int i)
{
  int cbits=0;
  while (i){
    cbits += i&0x1u;
    i>>=1;
  }
  return(cbits);
}

// function that needs to be called at the beginning of a program (before any other code) to initialize the array with pre-computed values (bits_in_16bits)
void init_precomp_count()
{
  unsigned int i;
// iterates through all possible 16 bit values and initializes the array to the number of "on" bits in that value
  for (i=0; i<0x1u<<16; ++i)
    precomp_count_16bits[i]=count_bits(i);
}

// function to compute how many "on" bits exist in a 64bit (long int) value using the pre-computed table. Basically this takes the first the 64 bits and splits it into 16 + 16 + 16 +16. For each of those 16 bits sums the count using the table to look them up. 
int count_bits16(unsigned long i)
{
  return( precomp_count_16bits[i & 0xfffful] + precomp_count_16bits[(i>>16) & 0xfffful] +precomp_count_16bits[(i>>32) & 0xfffful] + precomp_count_16bits[(i>>48) & 0xfffful] );
}

// This function will return the hamming distance between two networks represented by 64bit values
inline int mnets_dist(unsigned long x,unsigned long y)
{
  return(count_bits16(x^y));
}

//Initialization stuff
estr solver="esolver_clp";
int netsize=-1;
int strict=0;
int force_away=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
enet net;
erandomWalk *prw=0x00;
int genotype_size=0;

int emain()
{
ldieif(argvc<6,"syntax: ./assortativity_clustering_coefficient2 <universe.net> <inputfile1> <inputfile2> -genotype_size <y>  <fluxbounds.flx>");
epregister(solver);
epregister(genotype_size);
eparseArgs(argvc,argv);
//Must be done rw stuff
net.load(argv[1]); 
net.correct_malformed();
erandomWalk rw(net,solver,strict);
prw=&rw; 
rw.periphery_only=periphery_only;
rw.mutate_transport=mutate_transport;
rw.internal_secretion=internal_secretion;
rw.only_viable=only_viable;
rw.setRSize(netsize);
rw.getEnv(argvc,argv);
rw.load(net);
rw.calcPhenotype();
rw.viablePhenotype=rw.phenotype;

//Initialization
estr string=argv[2];
estr string2=argv[3];
estr outfile1=string+"_clust_coeff";
estr outfile2=string+"_assortativity";
int x=1000;
int y=genotype_size;
int z=45-y;
efile fin;
efile fin2;
efile fout1;
efile fout2;
estr str;
estr str2;
estrarray parts;
estrarray parts2;
int i;
int j;
int counter=0;
int tmp;

init_precomp_count();  // initialize the precomp_count array
unsigned long allnetworks[x];  
unsigned long genbits=0x00ul; // start with a 64bit value representing the network with all bits set to zero

int absent[x][z];
for (i=0; i<x; ++i){
    for (j=0; j<z; ++j){
        absent[i][j]=0;
    }
}

int present[x][y];
for (i=0; i<x; ++i){
    for (j=0; j<y; ++j){
        present[i][j]=0;
    }
}

//Reading input files and saving in the corresponding arrays
int ori[10];for (int jj=0;jj<10;++jj){ori[jj]=0;}
fin2.open(argv[3],"r");
while (fin2.readln(str2)) {
      parts2=str2.explode(" ");
      for (int j=0; j<parts2.size(); ++j) {
           int tapa=parts2[j].i();
           ori[tapa]=1;
      }
}
fin2.close();


fin.open(argv[2],"r");
while (fin.readln(str)) {
      parts=str.explode(" ");
      genbits=0x00ul;
      for (i=0; i<parts.size(); ++i){
      genbits|=(0x01ul<<(parts[i].i()-1));
			tmp =parts[i].i();
      absent[counter][i]=tmp;
      }
      allnetworks[counter]=genbits;
      counter=counter++;
}
fin.close();


int temp_vec[x][45];
for (i=0;i<x;++i){
    for (j=0; j<45; ++j){
        temp_vec[i][j]=1;
    }
}

for (i=0; i<x; ++i){
    for (j=0;j<z;++j){
        temp_vec[i][(absent[i][j])]=0;
    }
}

for (i=0; i<x; ++i){
    int counted=0;
    for (j=0;j<45;++j){
        if (temp_vec[i][j]==1){
           present[i][counted]=j;
           counted=counted++;
        }
    }
}     

////////////////////////////////////////   Clustering Coefficient //////////////////////////////////////////
int k;
int l;
int m;


for (i=0;i<x;++i){
    //Initialization
    int semi_final[z];for (m=0;m<z;++m){semi_final[m]=0;}
    for (m=0;m<z;++m){semi_final[m]=absent[i][m];} 
    int countiag=0;
    //processing the neighborhood of the genotypes
    for (k=0;k<z;++k){
        for (l=0;l<y;++l) {
            int final[z]; for (m=0;m<z;++m){final[m]=0;}
            for (m=0;m<z;++m){final[m]=semi_final[m];}
            final[k]=present[i][l];
            for (m=0;m<z;++m){int tmp=final[m]+26;rw.disable(tmp);}
            rw.calcPhenotype();
            eintarray f_temp=rw.phenotype;
            for (m=0;m<z;++m){int tmp=final[m]+26;rw.activate(tmp);}

            int zana=1;
            for (int kh=0;kh<10;kh++){if (f_temp[kh]==1){if (ori[kh]==0){zana=0;}} }
            if (zana==1){countiag=countiag+1;}
        }
    }

    int absent2[countiag][z];
    for (int mamo=0; mamo<countiag; ++mamo){
        for (int kako=0; kako<z; ++kako){
            absent2[mamo][kako]=0;
        }
    }

    int present2[countiag][y];
    for (int mamo=0; mamo<countiag; ++mamo){
        for (int kako=0; kako<y; ++kako){
            present2[mamo][kako]=0;
        }
    }

    int deg1=countiag;
    unsigned long allneighbors[countiag]; 
    unsigned long genbits2=0x00ul;
    int countiag2=0; 
    for (k=0;k<z;++k){
        for (l=0;l<y;++l) {
            int final[z]; for (m=0;m<z;++m){final[m]=0;}
            for (m=0;m<z;++m){final[m]=semi_final[m];}
            final[k]=present[i][l];
            for (m=0;m<z;++m){int tmp=final[m]+26;rw.disable(tmp);}
            rw.calcPhenotype();
            eintarray f_temp=rw.phenotype;
            for (m=0;m<z;++m){int tmp=final[m]+26;rw.activate(tmp);}
            int zana=1;
            for (int kh=0;kh<10;kh++){if (f_temp[kh]==1){if (ori[kh]==0){zana=0;}} }
            if (zana==1){
                genbits2=0x00ul;
                for (m=0;m<z;++m){genbits2|=(0x01ul<<(final[m]-1));absent2[countiag2][m]=final[m];}
                allneighbors[countiag2]=genbits2;
                countiag2=countiag2+1;}
        }
    }

    int temp_vec2[countiag][45];
    for (int mamo=0;mamo<countiag;++mamo){
        for (int kako=0; kako<45; ++kako){
            temp_vec2[mamo][kako]=1;
        }
    }

    for (int mamo=0; mamo<countiag; ++mamo){
        for (int kako=0;kako<z;++kako){
             temp_vec2[mamo][(absent2[mamo][kako])]=0;
        }
    }

    for (int mamo=0; mamo<countiag; ++mamo){
        int counted=0;
        for (int kako=0;kako<45;++kako){
            if (temp_vec2[mamo][kako]==1){
               present2[mamo][counted]=kako;
               counted=counted++;
            }
        }
    }     


    int total=0;
    for (int h=0;h<(countiag-1);++h){
        for (int g=(h+1);g<countiag;++g){
            int distance=0;
            distance=mnets_dist(allneighbors[h],allneighbors[g]);
            if (distance==2){total=total+1;}
        }
    }
    
   double denom= (double) countiag;
   double alak=2;
   double totaliter= denom * (denom-1) / alak;
   double coefficient=denom/totaliter;
   estr intster=coefficient;
   //double finalize=(double) total / (double) totaliter;
   //estr intster1=totalit;
   //double denom= (double) countiag;
   //estr intster2=denom;
   //estr intster=intster1+" "+intster2+"\n";
   
   fout1.open(outfile1,"a");
   fout1.write(intster+"\n");
   fout1.close();
///////////////////////////////////////////////////////  Assortativity   /////////////////////////////////////////////////////
  
  srand(time(NULL));
  int chosen=(rand() % countiag);
  //int chosen=1;
  int deg2=0;

  int semi_final2[z];for (m=0;m<z;++m){semi_final2[m]=0;}
  for (m=0;m<z;++m){semi_final2[m]=absent2[chosen][m];} 

  //processing the neighborhood of the genotypes
  for (k=0;k<z;++k){
      for (l=0;l<y;++l) {
            int final2[z]; for (m=0;m<z;++m){final2[m]=0;}
            for (m=0;m<z;++m){final2[m]=semi_final2[m];}
            final2[k]=present2[chosen][l];
            for (m=0;m<z;++m){int tmp=final2[m]+26;rw.disable(tmp);}
            rw.calcPhenotype();
            eintarray f_tempan=rw.phenotype;
            for (m=0;m<z;++m){int tmp=final2[m]+26;rw.activate(tmp);}
            //binary conversion
            int zana=1;
            for (int kh=0;kh<10;kh++){if (f_tempan[kh]==1){if (ori[kh]==0){zana=0;}} }
            if (zana==1){deg2=deg2+1;}
     }
  }
   
  double dga1=(double) deg1;
  double dga2=(double) deg2;
  estr intstr1=dga1;
  estr intstr2=dga2;
  estr final2=intstr1+" "+intstr2+"\n";
  fout2.open(outfile2,"a");
  fout2.write(final2); 
  fout2.close(); 
}
return(0);   
}

