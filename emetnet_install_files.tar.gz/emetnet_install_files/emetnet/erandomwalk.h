#ifndef ERANDOMWALK_H
#define ERANDOMWALK_H

#include "enet.h"
#include "esolver.h"
#include <eutils/estrarrayof.h>
#include <eutils/earray.h>
#include <eutils/evar.h>

class erandomWalk
{
 public:
  enet *net;
  int acount;
  double icount;
  int count;
  int lastRemoveMutation;
  int lastAddMutation;
  bool lastMutationType;

  int strictViable;
  int periphery_only;
  int mutate_transport;
  int internal_secretion;
  int internal_viability;
  int only_viable;
  int print_rejected;

  earray<eintarray> mingenotype;
  eintarray         mincount;
  eintarray superess;
  int secount;

  eintarray genotype;
  eintarray phenotype;
  eintarray viablePhenotype;
//  esolver * (*func_newSolver)();
  estr solvername;
//  estr solverClass;

  earray<double> growthRate;
  estrarrayof<esolver> solvers;

  erandomWalk& operator=(const erandomWalk&);
  erandomWalk(const erandomWalk&);
  erandomWalk(enet& net,int strictViable);
//  erandomWalk(enet& net, esolver *(*func_newSolver)(),int strictViable);
  erandomWalk(enet& net, const estr& solvername,int strictViable);
  ~erandomWalk();

  void init();

  void addEnv(const estr& name);
  void getEnv(int argvc,char **argv);

  void setobjective(int i);
  void activate(int i);
  void disable(int i);
  bool is_connected(elink &link);

  void setRSize(int count);

  void calcSuperess();

  void calcEssential(eintarray& esslist);
  void checkEssential(eintarray& esslist);


  void enableMetaboliteReactions(int i,const eintarray& ogen);
  void disableMetaboliteReactions(int i);
  bool checkMetaboliteProd(int ienv,int i);
  bool checkIntViability(int ienv);
  
  bool fluxVar(int ind,double& min,double& max);

  void findmin();
  void findmin_noflux();
  void findmin_similar();
  void findminKeep(eintarray& keepgen);
  bool findminWith(int ind);
  bool findminWith2(int ind);


  int mutate_add();
  int mutate_remove();

  int mutate_remove_ess(int esscount,eintarray& ess);
  int mutate_remove_ess_mincount(int esscount,eintarray& ess);
  int mutate_remove_ess_mincount_similar(int esscount,eintarray& ess);
  int mutate_remove_univ(int univ);

  int mutate_add_univ(int univ);
  int mutate_add_genpool(eintarray& genpool,int genpoolcount,float exthgt);
  int mutate_add_genpool_univ(eintarray& genpool,int genpoolcount,float exthgt,int univ);
  int mutate_add_away(eintarray& gref);
  int mutate_add_toward(eintarray& gref);
  int mutate_remove_toward(eintarray& gref);

  void mutate_genpool(eintarray& genpool,int genpoolcount,float exthgt);
  void mutate_genpool_univ(eintarray& genpool,int genpoolcount,float exthgt,int univ);

  void mutate();
  void mutate_univ(int univ);
  int mutate_away(eintarray& genotype);
  int mutate_away2(eintarray& genotype,double T);
  int mutate_toward(eintarray& genotype);
  void revert();
  void revert_univ();
  void revert_toward();

  bool isViable();
  bool isViable2();
  bool isViable3(int num, int cs);
////////////////////////////
  bool isViable_strict();
///////////////////////////
  bool isViable(const eintarray& phenotype);
  void updatePhenotypeAddition(const eintarray& phenotype_mask);
  void updatePhenotypeAddition();
  void updatePhenotypeRemoval();
  void updatePhenotype();
  void updatePhenotype_univ();
  void calcPhenotype();

  estr printPhenotype();
  estr printGrowthRate();

  void load(const enet& net);
  void load(const eintarray& genotype);

  void runmin(const enet& net,int niter);

  void run(const enet& net,int niter);
  void run2(const enet& net,int niter,int num, int cs);
////////////////////////////////
  void run_strict(const enet& net2,int niter,eintarray& phe_target);
///////////////////////////////
  void run_univ(const enet& net,int niter,int univ);
  void run_genpool(const enet& net,int niter,eintarray& genpool,int genpoolcount,float exthgt);
  void run_genpool_univ(const enet& net,int niter,eintarray& genpool,int genpoolcount,float exthgt,int univ);
  void run_away(const enet& net,int niter);
  void run_away2(const enet& net,int niter);
  void run_toward(enet& net2,enet& net3,int niter);

  void run_dist(const enet& net2,double gendist);
  void run_dist2(const enet& net2,double gendist);
  void run_dist3(const enet& net2,double gendist, double phendist);
};

double gendistance(eintarray& arr,eintarray& arr2,erandomWalk *rw=0x00);
double gendistance2(eintarray& arr,eintarray& arr2,erandomWalk *rw=0x00);
double gendistance3(eintarray& arr,eintarray& arr2);
int countPhenotype(eintarray& arr);
bool is_connected(elink &link);

void str2intarr(estr str,eintarray &arr);
estr intarr2str(const eintarray&);
estr intarr2str2(const eintarray& arr);
void sumintarr(eintarray &arr);

void phemerge(earrayof<int,eintarray>& phelist1,earrayof<int,eintarray>& phelist2);

estr pheessential(erandomWalk& rw,earray<eintarray>& phenotypes,bool show=false);
estr pherobust(erandomWalk& rw,earray<eintarray>& phenotypes,bool show=false);

estr pheessential(erandomWalk& rw,earrayof<int,eintarray>& phenotypes,bool show=false);
estr pherobust(erandomWalk& rw,earrayof<int,eintarray>& phenotypes,bool show=false);

void pheessential2(erandomWalk& rw,earrayof<int,eintarray>& cphenotypes,earrayof<eintarray,estr>& rreactions,estrarray& dreactions);
void idess(erandomWalk& rw, eintarray& essnet, int& numess);
void idess2(erandomWalk& rw, const eintarray& bluni, eintarray& essnet, int& numess);

#endif

