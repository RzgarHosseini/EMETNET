#ifndef __ESOLVER_CLP__
#define __ESOLVER_CLP__

#include "esolver.h"

#include <ipopt/IpStdCInterface.h>

class enlsolver_ipopt : public esolver
{
 public:
  IpoptProblem nlp;
  
  enlsolver_ipopt();
  ~enlsolver_ipopt();

  void parse(enet& net);
  double solve();

  void activate(int i);
  void disable(int i);
};

#endif

