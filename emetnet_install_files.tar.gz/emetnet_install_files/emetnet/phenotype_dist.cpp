#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>
#include <math.h>
///////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////
erandomWalk *prw=0x00;

int emain()
{ ldieif(argvc<4,"syntax: ./phenotype_dist  <universe.net> <filein.dat> ");
 
  enet net;
  net.load(argv[1]);
  estr solver="esolver_clp";
  int strict=0;
  erandomWalk rw(net,solver,strict);
  prw=&rw;

  efile filein;

  efile fileout1;
  efile fileout2;
  efile fileout3;
  efile fileout4;
  efile fileout5;
  
  estr outname=argv[2];
  estr str1=outname+"_0";
  estr str2=outname+"_5";
  estr str3=outname+"_10";
  estr str4=outname+"_15";
  estr str5=outname+"_20";

  int master[9989][50];for (int i=0;i<9989;i++){for (int j=0;j<50;j++){master[i][j]=0;}}
  estr sttr;
  int count=0;
  filein.open(argv[2],"r");
  while (filein.readln(sttr)) {
         estrarray parts;
         parts=sttr.explode(" ");
         for (int i=0;i<50;i++){master[count][i]=parts[i].i();}
         count++;
         double hama=(double) count;
         estr kapa=hama;
         cout<<"lele:"<<kapa<<endl;
  }

  filein.close();
  
  fileout1.open(str1,"w");
  fileout2.open(str2,"w");
  fileout3.open(str3,"w");
  fileout4.open(str4,"w");
  fileout5.open(str5,"w");

  double zer=0;
  double fiv=0;
  double ten=0;
  double fif=0;
  double twn=0;

  for (int i=0;i<9988;i++){
      eintarray gen1;
      cout<<intarr2str2(gen1)<<endl;
      int tmp=0;
      for (int k=0;k<50;k++){gen1.add(tmp);}
      for (int k=0;k<50;k++){gen1[k]=master[i][k];}
      for (int j=(i+1);j<9989;j++){
          eintarray gen2;
          for (int k=0;k<50;k++){gen2.add(tmp);}
          for (int k=0;k<50;k++){gen2[k]=master[j][k];}
          cout<<intarr2str2(gen2)<<endl;
          double gendist=gendistance3(gen1,gen2);
          int intdist=(int) gendist;

          estr count1=(double) (i+1);
          estr count2=(double) (j+1);
          estr distan=(double) intdist;
          cout<<"alaki: "<<distan<<endl;

          if (intdist==0){estr string1=count1;estr string2=count2;fileout1.write(string1+" "+string2+"\n");zer=zer+1;cout<<string1<<" : "<<string2<<endl;}
          if (intdist==5){estr string1=count1;estr string2=count2;fileout2.write(string1+" "+string2+"\n");fiv=fiv+1;cout<<string1<<" : "<<string2<<endl;}
          if (intdist==10){estr string1=count1;estr string2=count2;fileout3.write(string1+" "+string2+"\n");ten=ten+1;cout<<string1<<" : "<<string2<<endl;}
          if (intdist==15){estr string1=count1;estr string2=count2;fileout4.write(string1+" "+string2+"\n");fif=fif+1;cout<<string1<<" : "<<string2<<endl;}
          if (intdist==20){estr string1=count1;estr string2=count2;fileout5.write(string1+" "+string2+"\n");twn+twn+1;cout<<string1<<" : "<<string2<<endl;} 
          estr szer=(double) zer;cout<<szer<<endl;
          estr sfiv=(double) fiv;cout<<sfiv<<endl;
          estr sten=(double) ten;cout<<sten<<endl;
          estr sfif=(double) fif;cout<<sfif<<endl;
          estr stwn=(double) twn;cout<<stwn<<endl;   
      }

  }

   fileout1.close();
   fileout2.close();
   fileout3.close();
   fileout4.close();
   fileout5.close();
}
