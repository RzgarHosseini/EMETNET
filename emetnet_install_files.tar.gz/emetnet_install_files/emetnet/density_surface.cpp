#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <vector>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
using std::vector;

// array that will store pre-computed number of "on" bits in a 16bit value
char precomp_count_16bits[0x1u<<16];
// function to compute how many "on" bits exist in a 32bit (int) value
inline char count_bits(unsigned int i)
{
  int cbits=0;
  while (i){
    cbits += i&0x1u;
    i>>=1;
  }
  return(cbits);
}

// function that needs to be called at the beginning of a program (before any other code) to initialize the array with pre-computed values (bits_in_16bits)
void init_precomp_count()
{
  unsigned int i;
// iterates through all possible 16 bit values and initializes the array to the number of "on" bits in that value
  for (i=0; i<0x1u<<16; ++i)
    precomp_count_16bits[i]=count_bits(i);
}

// function to compute how many "on" bits exist in a 64bit (long int) value using the pre-computed table. Basically this takes the first the 64 bits and splits it into 16 + 16 + 16 +16. For each of those 16 bits sums the count using the table to look them up. 
int count_bits16(unsigned long i)
{
  return( precomp_count_16bits[i & 0xfffful] + precomp_count_16bits[(i>>16) & 0xfffful] +precomp_count_16bits[(i>>32) & 0xfffful] + precomp_count_16bits[(i>>48) & 0xfffful] );
}

// This function will return the hamming distance between two networks represented by 64bit values
inline int mnets_dist(unsigned long x,unsigned long y)
{
  return(count_bits16(x^y));
}
double num=0;

int emain()
{ldieif(argvc<5,"syntax: ./density_surface   <inputfile1> <inputfile2>  -num <x> ");
epregister(num);
eparseArgs(argvc,argv);

//Initialization
init_precomp_count();  // initialize the precomp_count array

//unsigned long allnetworks1[x];  
unsigned long genbits1=0x00ul; // start with a 64bit value representing the network with all bits set to zero
unsigned long genbits2=0x00ul;

//Reading input files and saving in the corresponding arrays
efile fin1;
efile fin2;
efile fout;

estr str;

estr filename1=argv[1];
estr filename2=argv[2];
estr numx=num;
estr filename_out=filename2+"_genotype_"+numx;

estrarray parts1;
estrarray parts2;

int counter1=1;

fin1.open(filename1,"r");
while (fin1.readln(str)) {
      parts1=str.explode(" ");
      if (counter1==num){
         genbits1=0x00ul;
         for (int i=0; i<parts1.size(); ++i){
             genbits1|=(0x01ul<<(parts1[i].i()));
             }
         break;
      }
      counter1=counter1++;
}
fin1.close();

fout.open(filename_out,"a");
fin2.open(filename2,"r");

while (fin2.readln(str)) {
      parts2=str.explode(" ");
      genbits2=0x00ul;
      for (int i=0; i<parts2.size(); ++i){
      genbits2|=(0x01ul<<(parts2[i].i()));
      }
      double distance=0; 
      distance = mnets_dist(genbits1,genbits2); //distance is defined
      estr intstr=distance;
      fout.write(intstr+"\n");
}

fin2.close();
fout.close();

}  
