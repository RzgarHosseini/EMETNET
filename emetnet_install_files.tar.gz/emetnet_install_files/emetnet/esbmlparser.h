#ifndef ESBMLMODEL_H
#define ESBMLMODEL_H

class estr;
class esbmlmodel;
class enet;
class esrcreaction;

void loadSBML(const estr& file,enet& net);

#endif

