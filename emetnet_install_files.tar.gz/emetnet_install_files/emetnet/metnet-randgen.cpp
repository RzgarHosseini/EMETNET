#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>
estr solver="esolver_clp";
eintarray gen1;
estr outnet="out.net";
int num=0;

int emain()
{ ldieif(argvc<4,"syntax: ./metnet-randgen  <file.dat> --num --outnet");  
  epregister(outnet);
  epregister(num);
  eparseArgs(argvc,argv);
  //////////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////  
  efile fe;
  fe.open(argv[1],"r");
  efile fw;
  fw.open(outnet,"a");
  estr sttr;
  while (fe.readln(sttr)) {
	estrarray parts;
        parts=sttr.explode(" ");
        int tmp=0;
        for (int i=0;i<6588;i++){gen1.add(tmp);}
        for (int i=0;i<6588;i++){gen1[i]=parts[i].i();}
  }
  int nump=num-2079;
  eintarray popp;
  for (int i=0; i<6588; ++i) {if (gen1[i]==0){popp.add(i);}}
  for (int i=(4508); i>=0; --i) {
       int r = (int)(ernd.uniform()*i);
       int tmp1 = popp[r];
       popp[r] = popp[i];
       popp[i]=tmp1;
  }
  
  for (int j=0;j<nump;j++){
       int x=popp[j];
       gen1[x]=1;
  }
  

  fw.write(intarr2str2(gen1)+"\n");

  fe.close();
  fw.close();
  return(0);
}



