
#include "enet.h"
#include "esolver_cplex.h"
#include "eqsolver_cplex.h"

#include <eutils/emain.h>

#include <fstream>
#include <iomanip>

enet net;
esolver_cplex solver;
eqsolver_cplex2 solver2;

/*
void print_flux(ofstream& f,enet& net)
{
  int i;
  double *primalColumns;
  
  primalColumns = solver.model->primalColumnSolution();
//  f << setprecision(4) << setw(6);
  for (i=0; i<net.links.size(); ++i){
    if (net.links[i].active && primalColumns[i]!=0.0){
      f << net.links[i].info[0] << "("<<i<<") ";
      f << setw(6) << primalColumns[i] << endl;
    }
  }
}
*/


void adjust_cpbounds()
{
  double res;
  int i;

  res=solver2.solve();

  i=0;
  do {
/*
    if (solver.x[i]==0.0 && solver2.x[i]!=0.0){
      solver2.setxzero(i);
      cout << "i: "<<i<<"  x: "<<solver.x[i]<<"  dMu: "<<solver2.x[i]<<"  x*dMu: "<<solver.x[i]*solver2.x[i]<<endl;
    } else 
*/
    if (solver.x[i]!=0.0 && solver2.x[i] == 0.0){ 
      if (solver.x[i] < 0.0)
        solver2.setxbounds(i,-100.0,-1.0e-3);
      else
        solver2.setxbounds(i,1.0e-3,100.0);
      cout << "i: "<<i<<"  x: "<<solver.x[i]<<"  dMu: "<<solver2.x[i]<<"  x*dMu: "<<solver.x[i]*solver2.x[i]<<endl;
    } else if (solver.x[i]*solver2.x[i] < 0.0){ 
      cout << "i: "<<i<<"  x: "<<solver.x[i]<<"  dMu: "<<solver2.x[i]<<"  x*dMu: "<<solver.x[i]*solver2.x[i]<<endl;
      if (solver.x[i] < 0.0) solver2.setxbounds(i,-100.0,-1.0e-3); else solver2.setxbounds(i,1.0e-3,100.0);
    }

    res=solver2.solve();
//    cout << "objective function result: "<< res << endl;

    if (res==-1.0)
      solver2.setxbounds(i,-100.0,100.0);

    ++i;
  } while (i < net.links.size());


  cout << "objective function result: "<< res << endl;


}

int count_infeasible()
{
  int oldi;
  int i;
  cout << " ------------------------------------------------- " << endl << endl;

  int reversible;

  oldi=0;
  reversible=0;
  for (i=0; i<net.links.size(); ++i){
/*    if (solver.x[i]==0.0 && solver2.x[i]!=0.0){
      if (!net.links[i].irreversible)
        ++reversible;
      ++oldi;
      cout << "i: "<<i<<"  x: "<<solver.x[i]<<"  dMu: "<<solver2.x[i]<<"  x*dMu: "<<solver.x[i]*solver2.x[i]<<endl;
    } else if ( .... 
*/
    if (solver.x[i]!=0.0 && solver2.x[i] == 0.0){ 
      if (!net.links[i].irreversible)
        ++reversible;
      ++oldi;
      cout << "i: "<<i<<"  x: "<<solver.x[i]<<"  dMu: "<<solver2.x[i]<<"  x*dMu: "<<solver.x[i]*solver2.x[i]<<endl;
    } else if (solver.x[i]*solver2.x[i] < 0.0){ 
      if (!net.links[i].irreversible)
        ++reversible;
      ++oldi;
      cout << "i: "<<i<<"  x: "<<solver.x[i]<<"  dMu: "<<solver2.x[i]<<"  x*dMu: "<<solver.x[i]*solver2.x[i]<<endl;
    }
  }

  cout << " total "<<oldi<<" infeasible corrections , with "<<reversible<<" reversible reactions"<<endl;

  return(oldi);
}

void correct_flux()
{
  double res;
  int i;

  for (i=0; i<net.links.size(); ++i){
    if (solver.x[i]!=0.0 && solver2.x[i] == 0.0){ 
      solver.disable(i);
      cout << "i: "<<i<<"  x: "<<solver.x[i]<<"  dMu: "<<solver2.x[i]<<"  x*dMu: "<<solver.x[i]*solver2.x[i]<<endl;
    } else if (solver.x[i]*solver2.x[i] < 0.0){ 
      if (net.links[i].irreversible)
        solver.disable(i);
      else{
        if (solver.x[i] < 0.0)
          solver.setxbounds(i,0.0,MAXFLUX);
        else
          solver.setxbounds(i,-MAXFLUX,0.0);
      }
      cout << "i: "<<i<<"  x: "<<solver.x[i]<<"  dMu: "<<solver2.x[i]<<"  x*dMu: "<<solver.x[i]*solver2.x[i]<<endl;
    } else continue;

    res=solver.solve();
    cout << " Trying with new flux bounds: " << res << endl;
    if (res < 1.0e-10)
      solver.activate(i);
    return;
  }
}

void set_signs()
{
  int i;

  for (i=0; i<net.links.size(); ++i){
    if (solver.x[i] > 0.0)
      solver2.setxbounds(i,1.0e-3,MAXFLUX);
    else if (solver.x[i] < 0.0)
      solver2.setxbounds(i,-MAXFLUX,-1.0e-3);
  }
}

void try_set_signs()
{
  int i;

  for (i=0; i<net.links.size(); ++i){
    if (solver.x[i] > 0.0)
      solver2.setxbounds(i,1.0e-3,MAXFLUX);
    else if (solver.x[i] < 0.0)
      solver2.setxbounds(i,-MAXFLUX,-1.0e-3);

    if (solver2.solve() == -1.0){
      solver2.setxbounds(i,-MAXFLUX,0.0);
      if (solver2.solve() == -1.0){
        cout << "double problem: "<<i << endl;
        
      }

    }
  }
}

void set_fluxzeros()
{
  int i;
  for (i=0; i<net.links.size(); ++i){
    if (solver2.x[i]==0.0 && solver.x[i]!=0.0){
      solver.disable(i);
      cout << " dMu("<<i<<") == 0.0, disabling reaction"<<endl;
    }
  }
}

void set_zeros()
{
  int i;

  for (i=0; i<net.links.size(); ++i){
    if (solver.x[i] == 0.0)
      solver2.setxzero(i);
  }
}

void check_feasibility()
{
  int i,j;

  bool sign;
  bool signchange;
  for (i=0; i<net.nullmatrixrows; ++i){
    signchange=false;
    for (j=0; j<net.links.size(); ++j){
      if (solver.x[j] != 0.0 && net.nullmatrix[i*net.links.size() + j] != 0.0){
        if (solver.x[j]>0.0 && net.nullmatrix[i*net.links.size() + j]>0.0 || solver.x[j]<0.0 && net.nullmatrix[i*net.links.size() + j]<0.0)
          sign=true;
        else
          sign=false;
        break;
      }
    }
/*    if (sign)
      cout << " + ";
    else
      cout << " - "; */
    for (; j<net.links.size(); ++j){
      if (solver.x[j] != 0.0 && net.nullmatrix[i*net.links.size() + j] != 0.0){
        if (solver.x[j]>0.0 && net.nullmatrix[i*net.links.size() + j]>0.0 || solver.x[j]<0.0 && net.nullmatrix[i*net.links.size() + j]<0.0){
//          cout << " + ";
          if (!sign)
            { signchange=true; break; }
        }else{
//          cout << " - ";
          if (sign)
            { signchange=true; break; }
        }
      }
    }
//    cout << endl;
    if (!signchange){
      cout << "cycle: "<<i<<" is infeasible" << endl;
    }
  }
}


int main()
{
  ldieif (argvc<2,"syntax: ./metnet-clp <file.net>");  

  net.load(argv[1]);
  net.correct_malformed();
  if (argvc>3)
    net.load_nullmatrix(argv[3]);
  else
    net.load_nullmatrix();
 
  solver.parse(net);
  solver2.parse(net);
  if (argvc>2)
    solver.load_fluxbounds(argv[2]);
  else
    solver.load_fluxbounds();



  double res;
  res=solver.solve();
  cout << "objective function result: "<< res << endl;

/*
  int n;
  do {
    adjust_cpbounds();
    n=count_infeasible();
    correct_flux();
  } while (n>0);
  res=solver.solve();
  cout << "objective function result: "<< res << endl;
*/
//  set_zeros();
//  set_signs();
//  check_feasibility();

  res=solver2.solve();
  cout << "objective function result: "<< res << endl;

  try_set_signs();
  res=solver2.solve();
  cout << "objective function result: "<< res << endl;

//  set_fluxzeros();

//  res=solver2.solve();
//  cout << "objective function result: "<< res << endl;

  res=solver.solve();
  cout << "objective function result: "<< res << endl;

  return(0);
}
