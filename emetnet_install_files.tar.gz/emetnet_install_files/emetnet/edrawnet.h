#ifndef EDRAWNET_H
#define EDRAWNET_H

#include <eutils/etable.h>

#include <edlib-2/edlib.h>
/*
#include <edlib-2/ewinpopup.h>
#include <edlib-2/ewinarray.h>
*/

#include "enet.h"


#include "edrawnode.h"
#include "edrawlink.h"

#undef check


class edrawnode;
class edrawlink;

class edrawnet : public ewindow
{
 public:
  enet *net;
  estrhashof<edrawnode> nodes;
  estrhashof<edrawlink> links;

  edrawnode* rootnode;
  edrawnode* infonode;
  edrawnode* dragnode;
  edrawlink* infolink;

  estrarray infoarr;

  evector2 vpoint;
  evector2 startVPoint;
  bool mouseDrag;

  float iw;
  float ih;

  float forcefactor;

  float ffactorMLink;
  float ffactorTLink;
  float ffactorSDRepulsion;

  float frangeRepulsion;
  float ffactorRepulsion;

  float frangeAttraction;
  float ffactorAttraction;

  bool infopopupnode;
//  ewinpopup infopopup;
//  ewinarray infopopuparr;

  etable nodeinfo;
  etable reactioninfo;
  estrarray colorinfo;

  void reset();
  void draw();
  void updateNeighboors();

  void update();

  void updateinfo(const evector2& mousePos);
  void updatelinkinfo(const evector2& mousePos);

  void doCreate();

  void doMouseScroll(int vdelta,int hdelta);
  void doMouseScrollUp();
  void doMouseScrollDown();
  void doMouseMove(const evector2& mousePos,int mouseButton);
  void doMouseBeginDrag(const evector2& mousePos,int mouseButton);
  void doMouseDrag(const evector2& mouseStart,const evector2& mousePos,int mouseButton);
  void doMouseEndDrag(const evector2& mouseStart,const evector2& mousePos,int mouseButton);
  virtual void doMouseClick(const evector2& mousePos, int mouseButton);

  void addPathway(const estr& pathway);
  void check(edrawnode* node=0x00,int n=0);
  void addAll(const eintarray& arr);
  void highlite(const eintarray& arr);
  void showOnly(const eintarray& arr);

  void getname(const estr& name,estr& res);

  void clickdel(evector2 pos);
  void click(evector2 pos);

  edrawnet(enet& net);

  void delnode(int i);
  edrawnode* getnode(enode* node,const evector2& node);
  bool linkExists(elink& link);
  bool areLinked(edrawnode* node1,edrawnode* node2);
};

int table_find(etable& table,const estr& field,const estr& needle);

#endif

