
#include "enet.h"
#include <eutils/eudl.h>

#include <eutils/logger.h>
#include <eutils/vector2.h>
#include <eutils/ernd.h>
#include <eutils/emain.h>
#include <eutils/esystem.h>
#include <eutils/efilesys.h>

#include <edlib-2/edlib.h>

/*
#include <edlib-2/ewinarray.h>
#include <edlib-2/ewinscrollbar.h>
#include <edlib-2/ecolor.h>
#include <edlib-2/ewinpopup.h>
*/

#include "erandomwalk.h"
#include "edrawnet.h"


etable reactions;
etable kegg;
etable ijr904;

//estrarray colorinfo;

//ewinarray winarray;

enet net;
earray<enet> nets;
int netindex=0;
erandomWalk *rw;
edrawnet *drawnet;

void doClear()
{
  drawnet->showOnly(rw->genotype);
}

void doKeyPress(int key)
{
  switch (key){
    case VK_LEFT: --netindex; if (netindex<0) netindex=0; break;
    case VK_RIGHT: ++netindex; if (netindex==nets.size()) netindex=nets.size()-1; break;
    case VK_ESCAPE: doClear(); break;
  }
  drawnet->setTitle(estr(netindex)+"/"+estr(nets.size())+" reactions: "+estr(drawnet->links.size())+" metabolites: "+estr(drawnet->nodes.size()));
  rw->load(nets[netindex]);
  drawnet->addAll(rw->genotype);
  drawnet->highlite(rw->genotype);
}



int emain()
{
  estrarray pathways;

  epregister(pathways);
  eparseArgs(argvc,argv);

  ldieif(argvc<2,"syntax: metnet-viz <file.net>");

  kegg=udl_load(env()["HOME"]+"/work/libdev/emetnet/data/ijr904-kegg-compounds.csv");
  reactions=udl_load(env()["HOME"]+"/work/libdev/emetnet/data/ijr904-kegg-reactions.csv");

//  colorinfo.load(argv[2]);
  
  net.load(env()["HOME"]+"/work/libdev/emetnet/data/evosulfnet/sulfur-ijr904-kegg.net");

  int i,j,k;
  for (i=1; i<net.links.size(); ++i){
    j=table_find(reactions,"id",net.links[i].info[0]);
    if (j!=-1) {
      for (k=0; k<reactions.cols.size(); ++k){
        net.links[i].info.add(reactions.cols.keys(k),reactions.cols.at(k).at(j).get<estr>());
      }
    }
  }

  rw=new erandomWalk(net,"clp",0);
  rw->getEnv(argvc,argv);

  for (i=1; i<argvc; ++i){
    if (efile(argv[i]).extension()=="net"){
      enet *tmpnet=new enet;
      tmpnet->load(argv[i]);
      nets.addref(tmpnet);
    }
  }

  ldieif(nets.size()==0,"no networks found!");

  rw->load(nets[0]);
  rw->calcPhenotype();
  for (j=0; j<rw->solvers.size(); ++j){
    if (rw->solvers.at(j).x[0] > 1.0e-3){
      for (k=0; k<net.links.size(); ++k)
        net.links[k].info["FLUX"]=rw->solvers.at(j).x[k];
    }
  }

  drawnet=new edrawnet(net);

  drawnet->nodeinfo = kegg;
  drawnet->reactioninfo = reactions;
//  drawnet.colorinfo = colorinfo;

  if (pathways.size())
    for (i=0; i<pathways.size(); ++i)
      drawnet->addPathway(pathways[i]);
  else
    drawnet->addAll(rw->genotype);

  drawnet->create(40,40,1024,786);
//  drawnet->scale = evector2(1024.0,786.0);
//  drawnet->onKeyPress=doKeyPress;
  drawnet->setTitle(estr(netindex)+"/"+estr(nets.size()));

/*
  ewindow winsettings;
  winsettings.create(400,400);

  earray<escrollbar> sliders;
  sliders.addref(new escrollbar("forcefactor",drawnet.forcefactor,0.0,5.0));
  sliders.addref(new escrollbar("Repulsion force",drawnet.ffactorRepulsion,0.0,5.0));
  sliders.addref(new escrollbar("Repulsion range",drawnet.frangeRepulsion,0.0,1.0));
  sliders.addref(new escrollbar("Attraction force",drawnet.ffactorAttraction,0.0,5.0));
  sliders.addref(new escrollbar("Attraction range",drawnet.frangeAttraction,0.0,1.0));
  sliders.addref(new escrollbar("Middle Link force",drawnet.ffactorMLink,0.0,5.0));
  sliders.addref(new escrollbar("End Link force",drawnet.ffactorTLink,0.0,5.0));
  sliders.addref(new escrollbar("SrcDst Repulsion force",drawnet.ffactorSDRepulsion,0.0,5.0));
  for (i=0; i<sliders.size(); ++i)
    sliders[i].create(winsettings,10,20+20*i,380,15);
*/

/*
  ewindow netlist;
  netlist.create(800,20,200,420);
  elistbox envlistbox;
  envlistbox.table.setfields("environments,growth");
  j=0;
  for (i=1; i<argvc; ++i)
    if (efile(argv[i]).extension()=="flx"){
      envlistbox.table.add("environments",efile(argv[i]).basename());
      envlistbox.table.add("growth",rw.solvers.at(j).x[0]);
      ++j;
    }
  envlistbox.create(netlist,0,0,200,210);
  elistbox netlistbox;
  netlistbox.table.setfields("networks");
  for (i=1; i<argvc; ++i)
    if (efile(argv[i]).extension()=="net")
      netlistbox.table.add("networks",efile(argv[i]).basename());
  netlistbox.create(netlist,0,210,200,210);
  netlist.move(800,20);
*/

  while(1){
    drawnet->clear(ecBlack);
    drawnet->draw();
    drawnet->update();

    drawnet->flip();
    getSystem()->process();
  }

  return(0);
}
