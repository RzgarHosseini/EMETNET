#ifndef EVARARRAY_H
#define EVARARRAY_H

#include "eutils.h"

#include "earray_dec.h"
//#include "evar.h"

class evar;

typedef earray<evar> evararray;

/*
class evararray : public earray<evar>
{
};
*/

#endif

