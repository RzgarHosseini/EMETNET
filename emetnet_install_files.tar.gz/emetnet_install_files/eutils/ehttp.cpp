#include "ehttp.h"

#include "esystem.h"





void ehttp::clear()
{
  data.clear();
  headers.clear();
  retcode=0;
}

void ehttp::doClose()
{

}

void ehttp::doRecv()
{
  int i;
  const char *tmpstr;
  estr tmpdata;
  estrarray tmparr;

//  cout << "ehttp::doRecv: ";
//  cout << "Received from socket: " << socket.recv(tmpdata) << endl;
  socket.recv(tmpdata);
  data+=tmpdata;

  if (protstate==0){
    tmpstr = data.getline();
    if (!tmpstr)
      return;
//    cout << "0 - tmpstr: "<<tmpstr<<endl;
    tmparr = estr(tmpstr).explode(" ");
    retversion = tmparr[0];
    retcode = tmparr[1].i();
    retstrcode = tmparr[2];
    ++protstate;
  }

  while (protstate==1){
    tmpstr = data.getline();
    if (!tmpstr)
      return;

    if (strlen(tmpstr)==0)
      { ++protstate; break; }

    tmpdata = tmpstr;
    i = tmpdata.find(":");
    if (i==-1)
      { lerror("missing header separator"); continue; }

    headers.add(tmpdata.substr(0,i),tmpdata.substr(i+1));
  }
}

bool ehttp::get(estr url)
{
  clear();
  protstate=0;

  url.del(0,7);
  int i;
  i=url.find("/");
  if (i==-1) return(false);
  cout << " connecting to: "<< url.substr(0,i)<<endl;
  if (!socket.connect(url.substr(0,i),80)) return(false);

  sendHeaders["Host"]=url.substr(0,i);

  socket.onReceive = efunc(*this,&ehttp::doRecv);
  cout << " getting page: "<< url.substr(i)<<endl;

  estr headerstr;
  headerstr=sendHeaders.join("\r\n",": ");

//  cout << "GET "+url.substr(i)+" HTTP/1.0\r\n"+headerstr+"\r\n"<<endl;
  socket.send("GET "+url.substr(i)+" HTTP/1.0\r\n"+headerstr+"\r\n\r\n");
//  socket.send("GET "+url.substr(i)+" HTTP/1.0\r\n\r\n");
  
  

  do {
//  socket.wait();
    getSystem()->wait();
  } while(socket.fhsock);

  return(true);
}


