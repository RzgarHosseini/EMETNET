#ifndef _ERND_
#define _ERND_

#include "eutils.h"

class cernd
{
 public:
  cernd();
  ~cernd();

  double uniform();
#ifdef EUTILS_HAVE_LIBGSL
  double gaussian(double sigma);
  double exponential(double rate);
  unsigned int geometric(double mean);
#endif
};

extern cernd ernd;

#endif

