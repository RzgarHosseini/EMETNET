#include "etime.h"

estr date()
{
  time_t tloc;
  time(&tloc);

  char tmpsz[26];
  ctime_r(&tloc,tmpsz);
  tmpsz[25]=0x00;
  return(tmpsz);
}

int unixtime()
{
  time_t tloc;
  time(&tloc);
  return((int)tloc);
}
