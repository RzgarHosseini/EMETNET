#include "efilesys.h"

#include "logger.h"

#include <sys/types.h>

#ifndef _MSC_VER
 #include <unistd.h>
#else
 #include <direct.h>
#endif

#ifndef _WIN32
 #include <dirent.h>
#endif

#include "estrarray.h"

#ifndef _WIN32
extern char **environ;
#endif

#include "evar.h"

ostream& operator<<(ostream& stream,const ediritem& diritem)
{
  stream << diritem.name;
  if (diritem.isDir())
    stream << "/";
  return(stream);
}

ostream& operator<<(ostream& stream,const edir& dir)
{
  int i;
  for (i=0; i<dir.size(); ++i)
    stream << dir[i] << endl;
  return(stream);
}

ediritem::ediritem() {}
ediritem::ediritem(const ediritem& diritem): name(diritem.name), type(diritem.type) {}
#ifdef _WIN32
ediritem::ediritem(WIN32_FIND_DATA& ditem): name(ditem.cFileName),type(ditem.dwFileAttributes)
{}
#else
ediritem::ediritem(struct dirent* ditem): name(ditem->d_name),type(ditem->d_type){ }
#endif

bool ediritem::isDir() const
{
#ifdef _WIN32
  if (type&FILE_ATTRIBUTE_DIRECTORY) return(true);
#else
  if (type==DT_DIR) return(true);
#endif
  return(false);
}

bool ediritem::isArchive() const
{
#ifdef _WIN32
  if (!(type&FILE_ATTRIBUTE_DIRECTORY) && (type&FILE_ATTRIBUTE_ARCHIVE) || (type&&FILE_ATTRIBUTE_NORMAL)) return(true);
#else
  if (type==DT_REG) return(true);
#endif
  return(false);
}



edir::edir() {}
edir::edir(const estr& dirname)
{
  open(dirname);
}

void edir::open(const estr& dirname)
{
#ifdef _WIN32
  WIN32_FIND_DATA FindFileData;
  HANDLE hFind;
//  char tmpsz[1024];

  bool more;
  int len;

  FILE *teste;

  
  more=true;
  hFind = FindFirstFile(L"*", &FindFileData);
  while (hFind != INVALID_HANDLE_VALUE && more) 
  {
//    len=wcslen(FindFileData.cFileName);
//    wcstombs(tmpsz,FindFileData.cFileName,len);
//    tmpsz[len] =0x00;
//    printf ("The first file found is %s\n", tmpsz);
    add(ediritem(FindFileData));
    more = FindNextFile(hFind,&FindFileData);
  } 
  FindClose(hFind);
#else
  DIR* dhandle;

  dhandle = opendir(dirname._str);
  if (!dhandle) { lwarn("unable to open dir name: "+dirname); return; }

  struct dirent* ditem;

  ditem = readdir(dhandle);
  while (ditem){
    add(ediritem(ditem));
    ditem = readdir(dhandle);
  }
  closedir(dhandle);
#endif
}


edir ls(const estr& dirname)
{
  return(dirname);
}

void cd(const estr& dirname)
{
#ifndef __MINGW32CE__
  if (dirname=="~")
    chdir(env()["HOME"]._str);
  else
    chdir(dirname._str);
#endif
}

estr pwd()
{
#ifndef __MINGW32CE__
  char tmpsz[1024];
  getcwd(tmpsz,1024);
  return(estr(tmpsz));
#else
  return(estr(""));
#endif
}

estrarray env()
{
  estrarray tmpenv;
#ifndef __MINGW32CE__
  char** penv=environ;
  int i;
  estr tmps;
  while (*penv){
    tmps=*penv;
    i=tmps.find("=");
    tmpenv.add(tmps.substr(0,i),tmps.substr(i+1));
    ++penv;
  }
#endif
  return(tmpenv);
}

