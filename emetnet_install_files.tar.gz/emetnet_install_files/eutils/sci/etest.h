#ifndef ETEST_H
#define ETEST_H

double etest_fisher(double a,double b,double c,double d);

#endif

