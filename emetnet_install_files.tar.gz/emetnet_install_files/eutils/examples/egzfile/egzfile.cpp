#include <eutils/emain.h>
#include <eutils/efile.h>

int emain()
{
  egzfile f("/Users/joao/ncbi/genbank/gbbct1.seq.gz");
  
  estr data;
  while (f.read(data,1024)>0){
    cout << data;
  }

  return(0);
}
