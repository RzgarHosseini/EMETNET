#include <eutils/esocket.h>
#include <eutils/esystem.h>
#include <stdio.h>

#include <signal.h>

#include <eutils/emain.h>

class cmysocket : public esocket
{
 public: 
  void doRecv();
  void doClose();
};

void cmysocket::doRecv()
{
  estr buffer;
  recv(buffer);
  printf("%i - %s\n",buffer.len(),buffer._str);
}

void cmysocket::doClose()
{
  printf("connection closed!!\n");
}

int emain()
{
  cmysocket socket;

  socket.connect("192.168.1.2",80);

  socket.send("GET / HTTP/1.0\r\n\r\n");

  getSystem()->run();

  return(0);
}
