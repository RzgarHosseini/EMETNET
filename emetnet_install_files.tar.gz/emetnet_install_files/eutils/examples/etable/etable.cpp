#include <eutils/emain.h>
#include <eutils/etable.h>

int main()
{
  eparseArgs(argvc,argv);
  etable t;

/*
  cout << "cols: " << t.cols.size() << " rows: " << t.size() << endl;
  cout << t << endl;

  estrarray arr("col1=val11,col2=val12,col3=val13");
  t.add(arr);
*/

  cout << "cols: " << t.cols.size() << " rows: " << t.size() << endl;
  cout << t << endl;

  t.add("col1","val11");
  t.add("col2","val12");
  t.add("col3","val13");

  cout << "cols: " << t.cols.size() << " rows: " << t.size() << endl;
  cout << t << endl;

  t.add("col1","val21");
  t.add("col2","val22");
  t.add("col3","val23");

  cout << "cols: " << t.cols.size() << " rows: " << t.size() << endl;
  cout << t << endl;
  return(0);
}
