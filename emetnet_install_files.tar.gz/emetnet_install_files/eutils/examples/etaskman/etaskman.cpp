#include <eutils/emain.h>
#include <eutils/ethread.h>
#include <eutils/esystem.h>


int doCalc(int res)
{
  sleep(2);
  cout << "doCalc: " << res << endl;
  return(res);
}

void doTaskDone(etaskman& taskman,etask& task)
{
  cout << " task result: " << task.result << endl;
}


void doAllDone()
{
  cout << "Finished all tasks!!" << endl;
}

int emain()
{
  eparseArgs(argvc,argv);
  etaskman taskman;

  taskman.onAllDone=doAllDone;
  taskman.onTaskDone=doTaskDone;
  taskman.createThread(2);
  int i;
  for (i=0; i<5; ++i)
    taskman.addTask(doCalc,evararray((const int&)i));

  taskman.wait();

  return(0);
}
