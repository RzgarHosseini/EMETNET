#include <eutils/ernd.h>
#include <iostream>

using namespace std;

int main()
{
  cout << "generating 10 random numbers in interval [0:1[ with uniform probability" << endl;
  int i;
  for (i=0; i<10; ++i)
    cout << ernd.uniform() << endl;
  return(0);
}
