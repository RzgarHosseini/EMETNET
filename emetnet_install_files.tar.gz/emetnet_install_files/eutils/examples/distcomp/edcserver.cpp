#include <eutils/emain.h>
#include <eutils/edcserver.h>

int emain()
{
  estr host="";
  epregister(host);
  eparseArgs(argvc,argv);

  if (host.len()==0){
    startServer(12345);
    epruninterpret();
  }else
    startClient(host,12345);

  return(0);
}

