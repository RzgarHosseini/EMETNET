#include <eutils/emain.h>
#include <eutils/eheap.h>
#include <eutils/ernd.h>

int emain()
{
  int i;
  estr tmp;
  eintarray arr,arr2;

  for (i=0; i<10; ++i)
    arr.add(ernd.uniform()*30);
  for (i=0; i<10; ++i)
    arr2.add(ernd.uniform()*30);

  tmp.clear();
  for (i=0; i<arr.size(); ++i)
    { tmp += arr[i]; tmp+=","; }
  cout << "arr1: "<< tmp.substr(0,-2) << endl;

  tmp.clear();
  for (i=0; i<arr2.size(); ++i)
    { tmp += arr2[i]; tmp+=","; }
  cout << "arr2: "<< tmp.substr(0,-2) << endl;
   

  cout << "--- sorting: " << endl;
  eintarray sarr;
  sarr=sort(arr);
  tmp.clear();
  for (i=0; i<arr.size(); ++i)
    { tmp += arr[sarr[i]]; tmp+=","; }
  cout << "arr1: "<< tmp.substr(0,-2) << endl;

  heapsort(arr);
  tmp.clear();
  for (i=0; i<arr.size(); ++i)
    { tmp += arr[i]; tmp+=","; }
  cout << "arr1: "<< tmp.substr(0,-2) << endl;

  heapsort(arr2);
  tmp.clear();
  for (i=0; i<arr2.size(); ++i)
    { tmp += arr2[i]; tmp+=","; }
  cout << "arr2: "<< tmp.substr(0,-2) << endl;


  eintarray sortmi(mergesort(arr,arr2));

  tmp.clear();
  for (i=0; i<sortmi.size(); ++i)
    { if (sortmi[i]<arr.size()) tmp+=arr[sortmi[i]]; else tmp += arr2[sortmi[i]-arr.size()]; tmp+=","; }
  cout << "arrm: "<< tmp.substr(0,-2) << endl;

  eintarray arr3(mergesorted(arr,arr2));

  tmp.clear();
  for (i=0; i<arr3.size(); ++i)
    { tmp += arr3[i]; tmp+=","; }
  cout << "arr3: "<< tmp.substr(0,-2) << endl;

 
  




  return(0);
}

