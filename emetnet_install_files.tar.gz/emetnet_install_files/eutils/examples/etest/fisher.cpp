#include <eutils/emain.h>
#include <eutils/sci/etest.h>

int emain()
{
  ldieif(argvc<5,"syntax: ./fisher <x00> <x01> <x10> <x11>");
  cout << "Fisher's exact test for contigency matrix:"<<endl;
  cout << argv[1] << " " <<argv[2] <<endl;
  cout << argv[3] << " " <<argv[4] <<endl;
  cout << "p-value: " << etest_fisher(estr(argv[1]).d(),estr(argv[2]).d(),estr(argv[3]).d(),estr(argv[4]).d()) << endl;
  return(0);
}

