#include <eutils/sci/ecorr.h>
#include <eutils/ematrix.h>
#include <eutils/ernd.h>

#include <math.h>

int main()
{
  evector x;
  x.create(1000);

  int i;
  for (i=0; i<1000; ++i){
    x[i]=sin((M_PI*(double)i)/50.0);
//    x[i]=ernd.uniform();
  }

  for (i=1; i<100; ++i)
    cout << i << " " << eautocorr(x,i)<<endl;

  return(0);
}
