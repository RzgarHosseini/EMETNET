#include <eutils/estr.h>
#include <eutils/ehashmap.h>
#include <stdio.h>


unsigned int strhash(const estr& key)
{
  int i;
  unsigned int keyhash = 0;
     
  for (i=0; i<key.len(); i++){
    keyhash += key[i];
    keyhash += (keyhash << 10);
    keyhash ^= (keyhash >> 6);
  }
  keyhash += (keyhash << 3);
  keyhash ^= (keyhash >> 11);
  keyhash += (keyhash << 15);

  return(keyhash);
}

int main()
{
  ehashmap<estr,estr> hashmap(strhash);

  hashmap["teste"] = "abc";

  cout << "teste = "<<hashmap["teste"] << endl;


  cout << endl;

  hashmap["teste2"] = "cabeca";
  cout << "teste2 = "<<hashmap["teste2"] << endl;
  cout << "teste = "<<hashmap["teste"] << endl;
  cout << endl;

  hashmap["vinho"] = "roxo";

  cout << "vinho = "<<hashmap["vinho"] << endl;
  cout << "teste2 = "<<hashmap["teste2"] << endl;
  cout << "teste = "<<hashmap["teste"] << endl;
  cout << endl;

  hashmap["test"] = "amarelo";

  cout << "vinho = "<<hashmap["vinho"] << endl;
  cout << "teste2 = "<<hashmap["teste2"] << endl;
  cout << "teste = "<<hashmap["teste"] << endl;
  cout << "test = "<<hashmap["test"] << endl;
  cout << endl;

  hashmap["test"] = "verde";

  cout << "vinho = "<<hashmap["vinho"] << endl;
  cout << "teste2 = "<<hashmap["teste2"] << endl;
  cout << "teste = "<<hashmap["teste"] << endl;
  cout << "test = "<<hashmap["test"] << endl;
  cout << endl;

  return(0);
}

