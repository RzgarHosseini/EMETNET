#include <eutils/ecmpstr.h>
#include <eutils/logger.h>


int main(int argvc, char *argv[])
{
  float res;
  ecmpword cmpword;

  dieif(argvc<2,"syntax: cmpstr <word1> <word2>")

  res=cmpword.compare(argv[1],argv[2]);
  printf("%f\n",res);
  
  return(0);
}
