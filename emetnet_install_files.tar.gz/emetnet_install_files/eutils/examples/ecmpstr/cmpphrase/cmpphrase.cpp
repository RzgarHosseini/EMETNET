#include <eutils/ecmpstr.h>
#include <eutils/logger.h>
#include <eutils/parser.h>

int main(int argvc, char *argv[])
{
  estr sep,ign;
  sep=" ";
  ign="";
  parserRegister(sep,"sep","separation chars");
  parserRegister(ign,"ign","ignore chars");
  parserInit(argvc,argv);
  float res;

  dieif(argvc<2,"syntax: cmpstr <phrase1> <phrase2>")


  eg_cmpphrase.setSeparationChars(sep);
  eg_cmpphrase.setIgnoreChars(ign);

  res=cmpphrase(argv[1],argv[2]);
  printf("%f\n",res);
  
  return(0);
}
