#include <eutils/net/enet.h>

#include <eutils/ernd.h>


int main()
{
  enet net;

  int i;
  for (i=0; i<20; ++i)
    net.addNode();

  for (i=0; i<20; ++i)
    net.addLink(net.nodes[net.nodes.size()*ernd.uniform()],net.nodes[net.nodes.size()*ernd.uniform()]);

  cout << net << endl;
  return(0);
}
