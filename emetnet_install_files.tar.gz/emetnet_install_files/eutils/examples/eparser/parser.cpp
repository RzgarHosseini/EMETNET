#include <eutils/eparser.h>
#include <eutils/estr.h>
#include <eutils/estrarray.h>
#include <eutils/efile.h>
#include <eutils/emain.h>


/////////////////////////////////
//
//    Class example
//

class client
{
 public:
  estrarray basket;
  estr name;
  estr phone;

  client();
  client(const estr& name);

  void order(const estr& type,int quantity);
  void showbasket();
};

client::client(){}
client::client(const estr& _name): name(_name) {}

void client::order(const estr& type,int quantity)
{
  basket.add(type,quantity);
}

void client::showbasket()
{
  cout << basket << endl;
}



/////////////////////////////////
//
//    Function example
//

void showclient(const client& c)
{
  cout << "Name: "<<c.name<<endl;
  cout << "Phone: "<<c.phone<<endl;
}


void interpretscript(const estr& filename)
{
  efile file(filename);

  estr code;

  while (file.readln(code))
    epinterpret(code);
}


int emain()
{
//  getLogger()->level=1;

  // registering class methods and properties:
//  epregisterClassConstructor(client,());                // allows creation of client objects:  c = client();
//  epregisterClassConstructor(client,(const client&));   // same as above but: client("client name") 
  int a;
  epregister(a);

  epregisterClassMethod(client,order);
  epregisterClassMethod(client,showbasket);
  epregisterClassProperty(client,name);
  epregisterClassProperty(client,phone);


  // registering the functions
  epregisterFunc(showclient);

  epregisterFunc(interpretscript);

  // starting parser
  epruninterpret();

  return(0);
}
