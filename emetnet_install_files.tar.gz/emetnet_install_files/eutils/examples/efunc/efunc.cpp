#include <eutils/efunc.h>


void sayhelloworld()
{
  cout << "hello world" << endl;
}

void sayhellojoao(int n)
{
  cout << "Hello Joao " << n<<endl;
}


class myclass
{
 public:
  estr name;

  void sayhello();
};

void myclass::sayhello()
{
  cout << "myclass::sayhello(): " << name << endl;
}

void myfunc(myclass& c)
{
  cout << c.name << endl;
}



int main()
{
  int a;
  a=2;

  myclass c;
  c.name = "< class myclass >";

  efunc myfuncp;

  // pointing efunc to a void function()
  myfuncp = sayhelloworld;
  myfuncp(); // calling the function

  // efunc can also call functions wich take arguments (any arguments)
  myfuncp = sayhellojoao;
  myfuncp(a);
  myfuncp("4");
  myfuncp(5);
  myfuncp();  // efunc will complain there are not enough arguments given

  // efunc can pass your own defined objects to your function
  myfuncp = myfunc;
  myfuncp(&c);

  // efunc can even take pointers to methods
  myfuncp = efunc(c,&myclass::sayhello);
  myfuncp();

  return(0);
}

