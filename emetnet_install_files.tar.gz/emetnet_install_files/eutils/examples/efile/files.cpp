#include <eutils/efile.h>

int main()
{
  efile somefile("somefile.txt");

  cout << " >> file exists? " << somefile.exists() << endl;

  estr str;
  str = " Hellooooo world!\n";

  int i;
  for (i=0; i<10; ++i)
    somefile.write(str);

  somefile.close();

  cout << " >> file exists? " << somefile.exists() << endl;
  cout << " >> file size: " << somefile.size() << endl;

  somefile.read(str);
  cout << " >> file contents: "<<endl << str <<endl;

  cout << " >> file contents (line by line):" << endl;
  somefile.close();

  i=0;
  while(somefile.readln(str)) {
    cout << " line "<<i<<": "<<str<<endl;
    ++i;
  }
  
  return(0);
}
