#include <eutils/eiostream.h>


void sayhello(const estr& s)
{
  printf("sayhello: %s\n",s._str);
}



int main()
{
  cout << "testing ";
  cout << "1 2 3"<<endl;

 
  eredirbuf rdbuf(cout);

  rdbuf.onOutput = sayhello;
  cout << "testing ";
  cout << "1 2 3"<<endl;

  return(0);
}
