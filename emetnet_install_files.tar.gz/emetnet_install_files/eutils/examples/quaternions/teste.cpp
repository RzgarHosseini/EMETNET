
#include <stdio.h>
#include <quaternion.h>
#include <vector3.h>
#include <matrix3.h>

void showQuat(CQuaternion &q)
{
  CVector3 v = q.ux();
  printf("ux: ( %f , %f , %f ) %f\n",v.x,v.y,v.z,v.len());
  v = q.uy();
  printf("uy: ( %f , %f , %f ) %f\n",v.x,v.y,v.z,v.len());
  v = q.uz();
  printf("uz: ( %f , %f , %f ) %f\n\n",v.x,v.y,v.z,v.len());
}

int main()
{
  int i;

  CQuaternion p(10.0,CVector3(1.0,0.0,0.0));
  CQuaternion q(1.0,0.0,0.0,0.0);

  showQuat(q);
 
  

  printf("Beginning rotation around X axis\n");
  for (i=0; i<9; i++){
    q = p * q;
    q.normalize();
    showQuat(q);
  }
  printf("Ended rotation around X axis\n");
  q.rotate(22.5,CVector3(1.0,0.0,0.0));
  showQuat(q);
  q.rotate(45.0,CVector3(0.0,1.0,0.0));
  showQuat(q);

  return(0);
}
