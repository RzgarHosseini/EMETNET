#include <eutils/emain.h>
#include <eutils/evararray.h>
#include <eutils/efile.h>

int emain()
{
  evararray arr;
  epregister(arr);
  eparseArgs(argvc,argv);
  
  efile f("test.dat");

  estr arrstr;
 
  if (f.exists()){
    f.read(arrstr);
    linfo("hello");
    if (arr.unserial(arrstr,0)==-1)
      ldie("unable to unserialize evararray");
    cout << arr << endl;
  }else{
    arr.add(123);
    arr.add("hello world");
    arr.add(2.1234e10);
    cout << arr << endl;
    arr.serial(arrstr);
    f.write(arrstr);
  }
  epruninterpret();

  return(0);
}
