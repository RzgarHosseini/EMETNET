#include <eutils/eregexp.h>
#include <eutils/logger.h>

int main(int argvc,char *argv[])
{
  dieif(argvc < 3,"syntax: teste <pattern> <text> [pos]");

  int pos=0;

  if (argvc == 4)
    pos = estr(argv[3]).i();
  cout << re_strpos(argv[1],argv[2],pos) << endl;


  return(0);
}

