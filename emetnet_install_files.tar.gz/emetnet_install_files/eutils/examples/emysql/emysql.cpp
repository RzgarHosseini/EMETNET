#include <eutils/emysql.h>

int main()
{
  emysql mysql;
  mysql.connect("localhost", "root","ihtmovos","test");

  emresult res;
  res = mysql.query("select * from test");


  cout << res.size() << endl;

/* 
  int i;
  for (i=0; i<res.size(); ++i){
    cout << res[i][2] << endl;
  }
*/
  cout << res << endl;

  return(0);
}

