#include "ecmpstr.h"
#include "estr.h"
#include "logger.h"
#include "eregexp.h"

#include "earray.h"

#ifdef _MSC_VER
#include <direct.h>
#endif

/*
class ecmpword
  bool scCaseSensitive=false;

  // typo check
  bool typoCheck=true;
  
  bool tcHist=true;
  bool tcSwap=true;
  bool tcRemaining=true;

  int   tcHistMaximumTypos=1;
  float tcHistMaximumTyposPerLetter=0.1;

  int   tcSwapMaximumTypos=1;
  float tcSwapMaximumTyposPerLetter=0.1;
  int   tcSwapMaximumDistance=1;
*/

#define ABS(a) ((a)>0?(a):-(a))
#define MIN(a,b) (a>b?b:a)
#define MAX(a,b) (a<b?b:a)

// auxiliary functions implemented at the end of the file
int strdist(char *str1, char *str2);







// target is used to tune the ammount of computation that goes into a match
//  i.e.: if you are not interested in fuzzy matching like checking for typos
//        you would just put target = 0.9

//        when the compare function reaches the maximum possible match of 0.9 it
//        stops comparing the strings and returns(0.0)

float ecmpword::compare(const estr &word1, const estr &word2,float target)
{
  float res;

  res = 1.0;
  // if they are the same, return complete match
  if (!strcmp(word1._str,word2._str)) return(res);    //1.0


  // best match will give 0.9
  res = 0.9;
  if (res<=target) return(0.0);
  // if they are not the same, lets check for case sensitivity

  //TODO: Correct this!!!
#ifndef _MSC_VER
  if (!strcasecmp(word1._str,word2._str)) return(res); //0.9
#endif

  // best match will give 0.8
  res = 0.8;
  if (res<=target) return(0.0);
   // if still not matched, check for typo's
  int chistsum,chistsub;
  int chist[256]; // char distribution difference between words
  int i;
  for (i=0;i<256; ++i) chist[i]=0;

  char *p1,*p2;

  for (p1=word1._str; *p1; ++p1)
    ++chist[(unsigned char)*p1];
  for (p2=word2._str; *p2; ++p2)
    --chist[(unsigned char)*p2];

  chistsum=0; chistsub=0;
  for (i=0;i<256;++i) if (chist[i]>0) chistsum+=chist[i]; else chistsub-=chist[i];

  if (word1.len() == word2.len()){
    int dist;

    dist=strdist(word1._str,word2._str);

    if (dist==2)
      return(0.8);
    else
      return(0.6*(1.0-(float)dist/(float)(word1.len()*(word1.len()+1))));
  }
//else if (word1.len() != word2.len()){
	estr tmpsz1,tmpsz2;
	tmpsz1.reserve(word1.len()+1);
	tmpsz2.reserve(word2.len()+1);
    char *pt1,*pt2;

    int histdiff;
    int dlen;

    dlen = ABS(word1.len() - word2.len());

    // histogram real diff factor independent of length diff
    histdiff = (chistsum+chistsub - dlen)/2;

    // copy strings removing chars that do not have equal counts 
    for (p1=word1._str,pt1=tmpsz1._str; *p1; ++p1)
      if (!chist[(unsigned char)*p1]) { *pt1=*p1; ++pt1; }
    *pt1=0x00;
    for (p2=word2._str,pt2=tmpsz2._str; *p2; ++p2)
      if (!chist[(unsigned char)*p2]) { *pt2=*p2; ++pt2; }
    *pt2=0x00;

    // strings should now have the same size
    float lostinfo;
    lostinfo = (float)(pt1-tmpsz1._str)/(float)MAX(word1.len(),word2.len());

    bool are_equal;
    are_equal = !strcmp(tmpsz1._str,tmpsz2._str);

/*
    cout << "s1: "<<tmpsz1 << " , s2: " << tmpsz2<<endl;
    cout << "are_equal: "<<are_equal<<endl;
    cout << "lostinfo: " << lostinfo << endl;
    cout << "histdiff: " << histdiff << endl;
    cout << "dlen: " << dlen << endl;
*/
    // if it is not equal after removing all different characters then
    // consider the string to be different
    if (!are_equal) return(0.0);

    if (are_equal && histdiff==0 && dlen==1){
      // in this case one of the strings matches completely the other
      // and there is only one extra char on one of the strings
      return(0.7);
    }
    dlen += 3;
    return(0.5*lostinfo*16.0/(dlen*dlen));  
//  }
}

/*
class ecmpphrase
  ecmpword cmpword;

  bool phraseSpaceSensitive=false;
  estr psChars = " \t\n\r";
  
  bool phrasePunctuationSensitive=false;
  estr ppChars = ",.:;/?()'\"[]{}*&^%$#@!~`_-<>\\|=+";

  bool wordOrderCompare=true;
  int   wocSwapMaximumSwaps=1;
  float wocSwapMaximumSwapsPerWord=0.1;
  int   wocSwapMaximumDistance=1;
*/

ecmpphrase::ecmpphrase()
{
  setSeparationChars(" ");
  setIgnoreChars("");
}


void ecmpphrase::setSeparationChars(estr chars)
{
  psChars=chars;
  if (chars.size())
    psCharsRE.compile(psChars);
}

void ecmpphrase::setIgnoreChars(estr chars)
{
  piChars=chars;
  if (chars.size())
    piCharsRE.compile(piChars);
}


float ecmpphrase::compare(const estr &str1, const estr &str2, float target)
{
  estr s1,s2;

  if (piChars.size()){
    s1=re_replace(str1,piCharsRE,"");
    s2=re_replace(str2,piCharsRE,"");
  }else{
    s1=str1;
    s2=str2;
  }


//  cout <<"s1: "<<s1<<" ,s2: "<<s2<<endl;
  if (!strcmp(s1._str,s2._str)) return(1.0);

  // TODO: Fix this
#ifndef _MSC_VER
  if (!strcasecmp(s1._str,s2._str)) return(0.90);
#endif

  estrarray a1,a2;

  a1=re_explode(s1,psCharsRE); a2=re_explode(s2,psCharsRE);

  

  // we are in fact matching two string lists here!
  if (!a1.size() && !a2.size()) return(1.0);
  if (!a1.size() || !a2.size()) return(0.0);

  int i,j;
  earray<earray<float> > matched;
  earray<float> matched1;
  earray<float> matched2;
/*
  float matched[a1.size()][a2.size()];
  float matched1[a1.size()];
  float matched2[a2.size()];
*/

  for (i=0;i<a1.size();++i){
    matched1.add(-1.0);
	matched.add(earray<float>());
	for (j=0;j<a2.size(); ++j){
      matched[i].add(-1.0);
	}
  }
  for (j=0;j<a2.size(); ++j)
    matched2.add(-1.0);
  

  float r;
  for (i=0; i<a1.size(); ++i){
//    if (matched1[i]=1.0) continue;
    for (j=0; j<a2.size(); ++j){
//      if (matched2[j]=1.0) continue;

      //   the reason for the MAX in the target
      // is that we should not spend resources on matching something
      // worse if it has already been matched better
      r=cmpword.compare(a1.values(i),a2.values(j),MAX(matched1[i],matched2[j]));
//      printf("%s,%s - %f\n",a1.values(i)._str,a2.values(j)._str,r);
      matched[i][j]=r;
      matched1[i]=MAX(matched1[i],r);
      matched2[j]=MAX(matched2[j],r);
    }
  }

  if (a1.size()==a2.size()){
    // if order is conserved, but there is a typo somewhere
    float mmax=1.0;
    float smax1=0.0;
    float smax2=0.0;
    float mdiag=1.0;
    float sdiag=0.0;
    for (i=0; i<a1.size(); ++i){
      mdiag=mdiag*matched[i][i];
      sdiag+=matched[i][i];

      mmax=mmax*matched1[i];
      smax1+=matched1[i];
      smax2+=matched2[i];
    }

//    printf("mdiag: %f  mmax: %f\n",mdiag,mmax);
    if (mdiag >= mmax) return(mdiag);

    return(0.6*(smax1+smax2)/(2.0*a1.size()));
  }

// else if (a1.size() != a2.size() ){
    // if order is conserved, but there is a typo somewhere
    float smax1=0.0;
    float smax2=0.0;
    float mmin1=1.0;
    float mmin2=1.0;
    int imin1,imin2;
    int tsize1,tsize2;

    tsize1=0;
    for (i=0; i<a1.size(); ++i){
      tsize1+=a1.values(i).size();
      smax1+=matched1[i];
      if (mmin1>matched1[i]){
        mmin1=matched1[i];
        imin1=i;
      }
    }
    tsize2=0;
    for (j=0; j<a2.size(); ++j){
      tsize2+=a2.values(j).size();
      smax2+=matched2[j];
      if (mmin2>matched2[j]){
        mmin2=matched2[j];
        imin2=j;
      }
    }

    int dlen;
    float lostinfo;

    dlen=ABS(a1.size()-a2.size());
    if (dlen==1){
      if (a1.size()<a2.size()){
        mmin1=mmin2;
        lostinfo = 1.0-0.8*(float)a2.values(imin2).size()/(float)tsize2;
      }else
        lostinfo = 1.0-0.8*(float)a1.values(imin1).size()/(float)tsize1;

//      cout << "lostinfo: " << lostinfo << endl;
      
      return(MIN(0.7,(smax1+smax2-mmin1)/(a1.size()+a2.size()-1)*lostinfo));
    }

    return(0.5*(smax1+smax2)/(a1.size()+a2.size()));
//  }
}



/*
class ematchstrings
  ecmpword cmpword;
*/

eintarray ematchstrings::match(const estrarray &arr1, const estrarray &arr2)
{
  return(eintarray());
}




/*
class ematchitems
  ematchstr matchstr;
*/

template <class T>
eintarray ematchitems<T>::match(const ebasicarray<T> &arr1, const ebasicarray<T> &arr2)
{
  ldie("function match is not done yet!");
  return(eintarray());
}


ecmpword      eg_cmpword;
ecmpphrase    eg_cmpphrase;
ematchstrings eg_matchstrings;

float cmpstr(const estr &str1, const estr &str2,float target)
{
  return(eg_cmpword.compare(str1,str2,target));
}

float cmpword(const estr &str1, const estr &str2,float target)
{
  return(eg_cmpword.compare(str1,str2,target));
}

float cmpphrase(const estr &str1, const estr &str2,float target)
{
  return(eg_cmpphrase.compare(str1,str2,target));
}

eintarray cmpstrings(const estrarray &arr1, const estrarray &arr2)
{
  return(eg_matchstrings.match(arr1,arr2));
}









///////////////////////////////////////////////////////////////
//
//  Word auxiliary function
//

int strdist(char *str1, char *str2)
{
  char *pstr1,*pstr2;
  char *pstr1f,*pstr1b;

  int dst;

  dst=0;
  pstr1 = str1;  pstr2 = str2;
  pstr1f = pstr1; pstr1b = pstr1;

  while (*pstr2){
    if(*pstr1f == *pstr2){
      dst += (pstr1f-pstr1);
      ++pstr2; ++pstr1;
      pstr1f = pstr1; pstr1b = pstr1;
    }
    else if (*pstr1b == *pstr2){
      dst += (pstr1-pstr1b);
      ++pstr2; ++pstr1;
      pstr1f = pstr1; pstr1b = pstr1;
    }
    else{
      if (pstr1b <= str1 && !*pstr1f){
        dst += (pstr1f-pstr1b);
        ++pstr2; ++pstr1;
        pstr1f = pstr1; pstr1b = pstr1;
      }

      if (pstr1b > str1)
        --pstr1b;
      if (*pstr1f)
        ++pstr1f;
    }
  }
  return(dst);
}

