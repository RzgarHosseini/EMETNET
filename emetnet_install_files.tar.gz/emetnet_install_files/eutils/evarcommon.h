#ifndef EVARCOMMON_H
#define EVARCOMMON_H

#include "eutils.h"

void epregisterCommon();


#endif

