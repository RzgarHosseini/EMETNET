#include "csocket.h"

#include <stdio.h>
#include <stdlib.h>

class csocket_parser : public csocket
{
 public:
  cbuffer buffer;
  void doRecv();

  csocket_parser();
  ~csocket_parser();
};

void csocket_parser::doRecv()
{
  do{
    len = recv(buffer.buf(),buffer.bleft());
    if (len!=-1){
      bufsz[len] = 0x00;
      printf("%i - %s\n",len,bufsz);
    }
  } while (len>0);
}
