#ifndef ESYSTEM_OSX_H
#define ESYSTEM_OSX_H

#include "eutils-config.h"

#include "earray.h"
#include "efunc.h"


class esystem
{
 public:
  int waitfd;
  bool waiting;

  earray<int> fds;
  vector<void*> fdrefs;
  vector<CFRunLoopSourceRef> fdsources;
  ebasicarray<efunc*> funcs;
  ebasicarray<evar*> datas;

  vector<CFRunLoopTimerRef> tmrefs;
  ebasicarray<efunc*> tmfuncs;

  void addtimer(const efunc& func,double secs,double repeat);

  static esystem *cursystem;
  ProcessSerialNumber PSN;

  esystem();

//  bool processMessages();
//  bool processMessagesWait();
  void process();
  void run();

  static void handleTimerCallback(CFRunLoopTimerRef tmref, void *info);
  static void handleSocketCallback(CFSocketRef sref, CFSocketCallBackType callBackTypes, CFDataRef address, const void *data, void *info);
  static void handleFileCallback(CFFileDescriptorRef fdref, CFOptionFlags callBackTypes, void *info);
  

  void addSocket(int fd,CFOptionFlags flags,efunc *func,evar *data=0x00);
  void removeSocket(int fd);

  void add(int fd,const efunc& func,evar *data=0x00);

  void addfunc(int fd,efunc *func);
  void remove(int fd);

  void wait(int fd=-1);  
};

//extern esystem fdwatch;

esystem *getSystem();

#endif

