#ifndef __EPCLASS__
#define __EPCLASS__

///////////////////////////////////////////////////////////////////////////////
//
//  Classes
//

template <class T>
class epclassMethodBase;
template <class T>
class epclassPropertyBase;

template <class T>
class epclass
{
 public:
  static int id;
  static estr name;
  static earrayof<epclassMethodBase<T>*,estr> methods;
  static earrayof<epclassPropertyBase<T>*,estr> properties;
};


#include "evarclassmethod.h"
#include "evarclassproperty.h"


template <class T>
int epclass<T>::id=0;

template <class T>
estr epclass<T>::name;

template <class T>
earrayof<epclassMethodBase<T>*,estr> epclass<T>::methods;

template <class T>
earrayof<epclassPropertyBase<T>*,estr> epclass<T>::properties;



int epclassCount=0;

template <class T>
void epclassAssignId()
{
  if (!epclass<T>::id){ 
    ++epclassCount;
    epclass<T>::id = epclassCount;
  }
}

#define epregisterClass( c )  _epregisterClass<c>( #c )
template <class T>
void _epregisterClass(const estr& classname)
{
  epclassAssignId<T>();
  epclass<T>::name = classname;
}



#define epregisterClassMethod2(c,m,r,a)  _epregisterClassMethod<c,r (c::*)a>(#c,#m,&c::m)
#define epregisterClassMethod(c,m)  _epregisterClassMethod<c>(#c,#m,&c::m)
template <typename T,typename F>
void _epregisterClassMethod(const estr& classname,const estr& methodname,F method)
{
  _epregisterClass<T>(classname);
  epclass<T>::methods.add(methodname,new epclassMethod<T,F>(method));
}

#define epregisterClassProperty(c,p)  _epregisterClassProperty<c>(#c,#p,&c::p)
template <class T,class P>
void _epregisterClassProperty(const estr& classname,const estr& propertyname,P T::*property)
{
  _epregisterClass<T>(classname);
  epclass<T>::properties.add(propertyname,new epclassProperty<T,P>(property));
}


#endif

