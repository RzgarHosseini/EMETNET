#ifndef __EVARBASE__
#define __EVARBASE__

#include "evararray.h"

class evar;

class evarBase
{
 public:
  int pcount;

  evarBase():pcount(0) {}

  virtual int  getClassId()=0;
  virtual estr getClassName()=0;

  virtual evarBase* copy()=0;

  virtual evar  call(const estr& methodname,evararray& args)=0;
  virtual evar  get(const estr& propertyname)=0;
  virtual void  set(const estr& propertyname,evar& value)=0;
  // all evarType's have defined:
  // T* get();

  virtual ostream& outstream(ostream& stream)=0;
};

#endif

