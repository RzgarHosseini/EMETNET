#ifndef __EPCLASSMETHOD__
#define __EPCLASSMETHOD__

#include "evararray.h"

class evar;

template <class T>
class epclassMethodBase
{
 public:
  virtual evar call(T* obj,evararray& args)=0;
};

template <class T,class F>
class epclassMethod : public epclassMethodBase<T>
{
 public:
  F method;
  epclassMethod(F method);
  evar call(T* obj,evararray& args);
};


#include "evarmethodcalls.h"

template <class T,class F>
epclassMethod<T,F>::epclassMethod(F _method): method(_method) {}

template <class T,class F>
evar epclassMethod<T,F>::call(T* obj,evararray& args)
{
  return(classMethodCall(obj,method,args));
}

#endif

