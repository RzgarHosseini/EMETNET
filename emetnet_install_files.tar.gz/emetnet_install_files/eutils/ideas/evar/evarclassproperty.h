#ifndef __EPCLASSPROPERTY__
#define __EPCLASSPROPERTY__

class evar;

template <class T>
class epclassPropertyBase
{
 public:
  virtual evar get(T* obj)=0;
  virtual void  set(T* obj,evar& value)=0;
};

template <class T,class P>
class epclassProperty : public epclassPropertyBase<T>
{
 public:
  P T::*property;
  epclassProperty(P T::*property);
  virtual evar get(T* obj);
  virtual void set(T* obj,evar& value);
};


#include "evar.h"

template <class T,class P>
epclassProperty<T,P>::epclassProperty(P T::*_property): property(_property) {}

template <class T,class P>
evar epclassProperty<T,P>::get(T* obj)
{
  return( (obj->*property) );
}

template <class T,class P>
void epclassProperty<T,P>::set(T* obj,evar& value)
{
  (obj->*property) = *value.get<P>();
}

#endif

