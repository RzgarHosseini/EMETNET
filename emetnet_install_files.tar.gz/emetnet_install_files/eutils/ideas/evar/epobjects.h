
///////////////////////////////////////////////////////////////////////////////
//
//  Object Lists
//

earrayof<evar*,estr> objects;


#define epregister( obj )  _epregister(obj, #obj)

template <class T>
void _epregister(T& object,const estr& objname)
{
  epclassAssignId<T>();

  objects.add(objname,new evar(&object));
}


template <class R>
R* epget(const estr& objname)
{
  if (objects.findkey(objname)!=-1)
    return(objects[objname]->get<R>());

  lwarn("object: "+objname+" not found, while getting value");
  return((R*)0x00);
}

template <class P>
void epset(const estr& objname,P value)
{
  if (objects.findkey(objname)!=-1)
    { objects[objname]->get<P>() = value; return; }

  lwarn("object: "+objname+" not found, while setting value (type: "+epclass<P>::className+")");
}


template <class R>
R* epcall(const estr& objname,const estr& methodname)
{
  evararray arr;

  if (objects.findkey(objname)!=-1)
    { return(objects[objname]->call(methodname,arr)).get<R>(); }

  lwarn("object: "+objname+" not found, while calling method: "+methodname);
}





template <class R>
R* epcall(const estr& objname,const estr& methodname,const estr& args)
{
  evararray arr;
  splitArgs(arr,args);
  if (objects.findkey(objname)!=-1)
    { return(objects[objname]->call(methodname,arr)).get<R>(); }

  lwarn("object: "+objname+" not found, while calling method: "+methodname+" args: "+args);
}

template <class R>
R* epget(const estr& objname,const estr& propertyname)
{
  if (objects.findkey(objname)!=-1)
    { return(objects[objname]->get(propertyname)).get<R>(); }

  lwarn("object not found");
}

template <class P>
void epset(const estr& objname,const estr& propertyname,P value)
{
  if (objects.findkey(objname)!=-1){
    objects[objname]->set(propertyname,value);
    return;
  }

  lwarn("object not found");
}



template <class A1>
void call(void (*pfunc)(A1),const estr& str)
{
  A1* a;
  a=epget<A1>(str);
  if (a)
    return((*pfunc)(*a));
  lwarn("variable "+str+" does not exist, or is not convertible to type "+epclass<A1>::name+"("+estr(epclass<A1>::id)+") for this function");
}



