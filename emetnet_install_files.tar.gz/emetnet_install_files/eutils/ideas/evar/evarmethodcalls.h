#ifndef __EPMETHODCALLS__
#define __EPMETHODCALLS__

//////////////////////////////
//
//  Method Call templates 
//


//TODO: Make sure that if arguments cannot be converted to the right types, then do not call the function!!


#include "evar.h"

template <class T>
evar classMethodCall(T* obj,void (T::*method)(),evararray& args)
{
  (obj->*method)();
  return(evar());
}
template <class T,class A1>
evar classMethodCall(T* obj,void (T::*method)(A1),evararray& args)
{
  if (args.size()>=1)
    (obj->*method)( *args[0].get<A1>() );
  return(evar());
}
template <class T,class A1,class A2>
evar classMethodCall(T* obj,void (T::*method)(A1,A2),evararray& args)
{
  if (args.size()>=2)
    (obj->*method)( *args[0].get<A1>() , *args[1].get<A2>() );

  return(evar());
}
template <class T,class A1,class A2,class A3>
evar classMethodCall(T* obj,void (T::*method)(A1,A2,A3),evararray& args)
{
  if (args.size()>=3)
    (obj->*method)( *args[0].get<A1>() , *args[1].get<A2>() , *args[2].get<A3>() );
  return(evar());
}
template <class T,class A1,class A2,class A3,class A4>
evar classMethodCall(T* obj,void (T::*method)(A1,A2,A3,A4),evararray& args)
{
  if (args.size()>=4)
    (obj->*method)( *args[0].get<A1>() , *args[1].get<A2>() , *args[2].get<A3>() , *args[3].get<A4>() );
  return(evar());
}


template <class T,class R>
evar classMethodCall(T* obj,R (T::*method)(),evararray& args)
{
  return( (obj->*method)() );
}
template <class T,class R,class A1>
evar classMethodCall(T* obj,R (T::*method)(A1),evararray& args)
{
  if (args.size()>=1)
    return( (obj->*method)( *args[0].get<A1>() ) );
  return(evar());
}
template <class T,class R,class A1,class A2>
evar classMethodCall(T* obj,R (T::*method)(A1,A2),evararray& args)
{
  if (args.size()>=2)
    return( (obj->*method)( *args[0].get<A1>() , *args[1].get<A2>() ) );
  return(evar());
}
template <class T,class R,class A1,class A2,class A3>
evar classMethodCall(T* obj,R (T::*method)(A1,A2,A3),evararray& args)
{
  if (args.size()>=3)
    return( (obj->*method)( *args[0].get<A1>() , *args[1].get<A2>() , *args[2].get<A3>()) );
  return(evar());
}
template <class T,class R,class A1,class A2,class A3,class A4>
evar classMethodCall(T* obj,R (T::*method)(A1,A2,A3,A4),evararray& args)
{
  if (args.size()>=3)
    return( (obj->*method)( *args[0].get<A1>() , *args[1].get<A2>() , *args[2].get<A3>() , *args[3].get<A4>()) );
  return(evar());
}


template <class T,class R>
evar classMethodCall(T* obj,R (T::*method)() const,evararray& args)
{
  return( (obj->*method)() );
}
template <class T,class R,class A1>
evar classMethodCall(T* obj,R (T::*method)(A1) const,evararray& args)
{
  if (args.size()>=1)
    return( (obj->*method)( *args[0].get<A1>() ) );
  return(evar());
}
template <class T,class R,class A1,class A2>
evar classMethodCall(T* obj,R (T::*method)(A1,A2) const,evararray& args)
{
  if (args.size()>=2)
    return( (obj->*method)( *args[0].get<A1>() , *args[1].get<A2>() ) );
  return(evar());
}
template <class T,class R,class A1,class A2,class A3>
evar classMethodCall(T* obj,R (T::*method)(A1,A2,A3) const,evararray& args)
{
  if (args.size()>=3)
    return( (obj->*method)( *args[0].get<A1>() , *args[1].get<A2>() , *args[2].get<A3>()) );
  return(evar());
}
template <class T,class R,class A1,class A2,class A3,class A4>
evar classMethodCall(T* obj,R (T::*method)(A1,A2,A3,A4) const,evararray& args)
{
  if (args.size()>=3)
    return( (obj->*method)( *args[0].get<A1>() , *args[1].get<A2>() , *args[2].get<A3>() , *args[3].get<A4>() ));
  return(evar());
}



//TODO: verify that values passed by reference to a function, will be changed in the passed variable
template <class T,class R,class A1>
evar classMethodCall(T* obj,R (T::*method)(A1&),evararray& args)
{
  if (args.size()>=1)
    return( (obj->*method)( *args[0].get<A1>() ) );
  return(evar());
}

// All possible combination of Arguments passed by reference for 2 ARGUMENTS
template <class T,class R,class A1,class A2>
evar classMethodCall(T* obj,R (T::*method)(A1&,A2&) const,evararray& args)
{
  if (args.size()>=2)
    return( (obj->*method)( *args[0].get<A1>() , *args[1].get<A2>() ) );
  return(evar());
}
template <class T,class R,class A1,class A2>
evar classMethodCall(T* obj,R (T::*method)(A1&,A2) const,evararray& args)
{
  if (args.size()>=2)
    return( (obj->*method)( *args[0].get<A1>() , *args[1].get<A2>() ) );
  return(evar());
}template <class T,class R,class A1,class A2>
evar classMethodCall(T* obj,R (T::*method)(A1,A2&) const,evararray& args)
{
  if (args.size()>=2)
    return( (obj->*method)( *args[0].get<A1>() , *args[1].get<A2>() ) );
  return(evar());
}

// All possible combination of Arguments passed by reference for 3 ARGUMENTS!!!
template <class T,class R,class A1,class A2,class A3>
evar classMethodCall(T* obj,R (T::*method)(A1&,A2&,A3&) const,evararray& args)
{
  if (args.size()>=3)
    return( (obj->*method)( *args[0].get<A1>() , *args[1].get<A2>() , *args[2].get<A3>()) );
  return(evar());
}
template <class T,class R,class A1,class A2,class A3>
evar classMethodCall(T* obj,R (T::*method)(A1&,A2,A3) const,evararray& args)
{
  if (args.size()>=3)
    return( (obj->*method)( *args[0].get<A1>() , *args[1].get<A2>() , *args[2].get<A3>()) );
  return(evar());
}
template <class T,class R,class A1,class A2,class A3>
evar classMethodCall(T* obj,R (T::*method)(A1,A2&,A3) const,evararray& args)
{
  if (args.size()>=3)
    return( (obj->*method)( *args[0].get<A1>() , *args[1].get<A2>() , *args[2].get<A3>()) );
  return(evar());
}
template <class T,class R,class A1,class A2,class A3>
evar classMethodCall(T* obj,R (T::*method)(A1,A2,A3&) const,evararray& args)
{
  if (args.size()>=3)
    return( (obj->*method)( *args[0].get<A1>() , *args[1].get<A2>() , *args[2].get<A3>()) );
  return(evar());
}
template <class T,class R,class A1,class A2,class A3>
evar classMethodCall(T* obj,R (T::*method)(A1,A2&,A3&) const,evararray& args)
{
  if (args.size()>=3)
    return( (obj->*method)( *args[0].get<A1>() , *args[1].get<A2>() , *args[2].get<A3>()) );
  return(evar());
}
template <class T,class R,class A1,class A2,class A3>
evar classMethodCall(T* obj,R (T::*method)(A1&,A2,A3&) const,evararray& args)
{
  if (args.size()>=3)
    return( (obj->*method)( *args[0].get<A1>() , *args[1].get<A2>() , *args[2].get<A3>()) );
  return(evar());
}
template <class T,class R,class A1,class A2,class A3>
evar classMethodCall(T* obj,R (T::*method)(A1&,A2&,A3) const,evararray& args)
{
  if (args.size()>=3)
    return( (obj->*method)( *args[0].get<A1>() , *args[1].get<A2>() , *args[2].get<A3>()) );
  return(evar());
}







//////////////////////////////////////////////
//
//  End of method call templates
//

#endif

