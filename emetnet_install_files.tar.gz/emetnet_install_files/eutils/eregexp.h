#ifndef __EREGEXP__
#define __EREGEXP__

#include "eutils.h"

#include <sys/types.h>

#ifdef EUTILS_HAVE_REGEX
#include <regex.h>
#endif

#include <stdio.h>

#include "estr.h"
#include "estrarray.h"

class eregexp
{
 private:
#ifdef EUTILS_HAVE_REGEX
  regex_t reg;
  size_t nmatch;
  regmatch_t *pmatch;
#endif
  bool compiled;
 public:
  int b;
  int e;

  eregexp();
  eregexp(const estr &str);
  eregexp(const estr &str,int nmatch);
  ~eregexp();
  
  void compile(const estr &matchstr, int cflags=0x00);
  int match(const estr &text, int pos=0, int eflags=0x00);
};

int re_strpos(const estr &haystack,eregexp &needle,int pos=0);

estr re_match(const estr &str,eregexp &re,int pos=0);
void re_match(const estr &str,eregexp &re,estr& res,int pos=0);


estrarray re_explode(const estr &str,eregexp &re);
estr re_replace(const estr &str,eregexp &re,const estr &replacestr);

estrarray &mre_explode(const estr &str,eregexp &re,estrarray &list);

inline int re_strpos(const estr &haystack,const estr &needle,int pos=0)
{
  eregexp re(needle);
  return(re_strpos(haystack,re,pos));
}

inline estr re_match(const estr &str,const estr &match,int pos=0)
{
  eregexp re(match);
  return(re_match(str,re,pos));
}

inline bool grep(estr &str,eregexp &re,estr& ret,int pos=0)
{
  re_match(str,re,ret,pos);
  if (re.b==-1) return(false);
//  cout << "re.b: "<<re.b<<endl;
  str.del(re.b,re.e-re.b);
  return(true); 
}

inline bool grep(estr &str,const estr &match,estr& ret,int pos=0)
{
  eregexp re(match);
  re_match(str,re,ret,pos);
  if (re.b==-1) return(false);
//  cout << "re.b: "<<re.b<<endl;
  str.del(re.b,re.e-re.b);
  return(true); 
}

inline estr grep(estr &str,const estr &match,int pos=0)
{
  eregexp re(match);
  estr ret;
  re_match(str,re,ret,pos);
  if (re.b==-1) return("");
//  cout << "re.b: "<<re.b<<endl;
  str.del(re.b,re.e-re.b);
  return(ret); 
}

extern eregexp refloat;
extern eregexp reint;

inline bool grepdouble(estr &str,double& ret,int pos=0)
{
  refloat.match(str);
  if (refloat.b==-1) return(false);
  
  sscanf(&str[refloat.b],"%lg",&ret);
  return(true);
/*
  static estr sret;
  if (grep(str,refloat,sret,pos)){
    ret=sret.d(); return(true);
  }
  return(false);
*/
}

inline bool grepfloat(estr &str,float& ret,int pos=0)
{
  estr sret;
  if (grep(str,refloat,sret,pos)){
    ret=sret.f(); return(true);
  }
  return(false);
}

inline bool grepint(estr &str,int& ret,int pos=0)
{
  estr sret;
  if (grep(str,reint,sret,pos)){
    ret=sret.i(); return(true);
  }
  return(false);
}


inline estr re_replace(const estr &str,const estr &sep,const estr &replacestr)
{
  eregexp re(sep);
  return(re_replace(str,re,replacestr));
}

inline estrarray re_explode(const estr &str,const estr &sep)
{
  eregexp re(sep);
  return(re_explode(str,re));
}

inline estrarray &mre_explode(const estr &str,const estr &sep,estrarray &list)
{
  eregexp re(sep);
  return(mre_explode(str,re,list));
}

#endif

