#include <stdio.h>
#include <fcntl.h>
#include <sstream>

#include "evar.h"
#include "eiostream.h"
#include "logger.h"

#ifndef _MSC_VER
#include <unistd.h>
#endif

#ifdef WIN32
 #include <windows.h>
#endif

#undef logger
#undef printf

#include "eterm.h"



static elogger *logger = 0x00;

//#include "eparser.h"


elogger *getLogger()
{
  if (logger==0x00)
    logger=new elogger;
  return(logger);
}

/*
void ldie(const estr &diemsg,const estr& function)
{
  lerror(diemsg,function);
  exit(1);
}
*/

CDebugLine::CDebugLine()
{
}

CDebugLine::CDebugLine(int _level, const estr& _file, const estr& _function, int _line, const estr& _message,const estr& _module): level(_level),file(_file),function(_function),line(_line),message(_message),module(_module)
{
}


elogger::elogger():trace(false),logtofile(false),maxlines(200),level(3)
{
  // WARNING: logger constructor should not call any functions that
  //   may output debugging info

//  estr msg = "Starting debug log:\n";
  
//  logfd = open("debug.log",O_WRONLY | O_TRUNC | O_CREAT, OF_READWRITE);
//  write(logfd,msg.c_str(),msg.length());
}

elogger::~elogger()
{
//  close(logfd);
}

/*
void elogger::setOutput(void (*aoutput_func)(estr msg))
{
  output_func = aoutput_func;
}
*/


void elogger::showOutput(const estr& msg)
{
  if (logtofile){
//    int fd = open("debug.log",O_WRONLY | O_APPEND);
//    msg += "\n";
//    write(logfd,msg.c_str(),msg.length());
//    close(fd); 
  }  
//  if (onOutput.isSet())
//    onOutput.call(msg);
//  else
    cerr << msg << endl;
}

void elogger::start(const estr& _function,const estr& _section)
{
  sections.push_back(section);
  functions.push_back(function);
  
  section = _section;
  function = _function;
  
  if (trace) showOutput(estr("-> "+section+": "+function));
}  

void elogger::stop()
{
  if (trace) showOutput(estr("<- "+section+": "+function));
  
  if (sections.size()>0){
    section = sections.front();
    function = functions.front();
    sections.pop_front();
    functions.pop_front();
  }
  else{
    section = "";
    function = ""; 
  }  
}  

void elogger::error(const estr& file,const estr& function,int line,const estr& msg,const estr& module)
{
  debug(6,file,function,line,"!error!: "+msg,module);
}

inline estr getname(const estr& filename)
{
  estr str=filename;
  int i=str.find(".");
  if (i==-1) return(str);
  return(str.substr(0,i));
}

bool elogger::inModules(int mlevel,const estr& _modules,const estr& _function,const estr& _file)
{
  if (mlevel>=level || modules.findkey("all")!=-1 && mlevel>=modules["all"]) return(true);

  int i;
  estrarray _marr(_modules);
  for (i=0; i<_marr.size(); ++i){
    if (modules.findkey(_marr[i])!=-1 && mlevel>=modules[_marr[i]] || modules.findkey(getname(_file))!=-1 && mlevel>=modules[getname(_file)] || modules.findkey(_function)!=-1 && mlevel>=modules[_function])
      return(true);
  }
  return(false);
}

#include "ethread.h"

emutex mutexDebug;

void elogger::debug(int mlevel,const estr& file,const estr& function,int line,const estr& message,const estr& module)
{
  mutexDebug.lock();
  if (debuglines.size()>maxlines){
    delete debuglines.front();
    debuglines.pop_front();
  }

  debuglines.push_back(new CDebugLine(level,file,function,line,message,module));
  mutexDebug.unlock();

  const char *symbol;
  estr colorstr;
  
  switch (mlevel){
    case 0:symbol="   "; colorstr = etermSetColor(tcBlue); break;
    case 1:symbol=".  "; colorstr = etermSetColor(tcBlue); break;
    case 2:symbol="i  "; colorstr = etermSetColor(tcGreen); break;
    case 3:symbol="I  "; colorstr = etermSetColor(tcGreen); break;
    case 4:symbol="S  "; break;
    case 5:symbol="!! "; colorstr = etermSetColor(tcYellow,true); break;
    case 6:symbol="E! "; colorstr = etermSetColor(tcRed,true); break;
  }

  if (inModules(mlevel,module,file,function))
    showOutput(colorstr+estr(symbol)+"["+module+"] "+function+"(): "+message+etermUnsetColor());
//    showOutput(colorstr+estr(symbol)+file+":"+estr(line)+" "+function+":: ["+module+"]"+message+etermUnsetColor());
}

void elogger::print(const estr& msg)
{
  showOutput(msg);
//  debug(3,"","",0,msg);
}

void print(const estr& msg)
{
  getLogger()->print(msg);
}
  
