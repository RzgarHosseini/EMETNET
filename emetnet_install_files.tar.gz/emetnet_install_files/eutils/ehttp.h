#ifndef EHTTP_H
#define EHTTP_H

#include "esocket.h"
#include "estr.h"


class ehttp //: public esocket
{
 public: 
  esocket socket;

  int protstate;

  estrarray sendHeaders;
  estrarray headers;
  estr header;
  estr data;

  estr retversion;
  estr retstrcode;
  int  retcode;
  
  bool get(estr url);

  void clear();

  void doRecv();
  void doClose();
};

#endif

