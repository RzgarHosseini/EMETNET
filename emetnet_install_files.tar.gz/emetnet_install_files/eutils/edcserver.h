#ifndef EDCSERVER_H
#define EDCSERVER_H

#include "esocket.h"

class edcclient : public esocket
{
 public:
  estr data;
  int outpipe;

  void doRecv();
  void doClose();

  int doHandleCall(const estr& data,int i);
  int doHandleEval(const estr& data,int i);
  void sendResult(const evar& var);
  void sendOutput();
};

class edcserver;

class edcserverClient : public esocket
{
 public:
  edcserver *server;
  estr data;
  evar result;

  bool isBusy;

  edcserverClient(edcserver *server);

  void call(const estr& cmd,const evararray& arr); 
  void eval(const estr& cmd); 
  void doRecv();
  int doHandleOutput(const estr& data,int i);
  int doHandleResult(const estr& data,int i);
};

class edcserver : public eserver
{
 public:
  bool showResult;

  edcserver();

  efunc onAllReady;
  void doIncoming();
  void doAllReady();
  void doReady(edcserverClient *dclient);
  edcserverClient& getClient(int i);
};

void registerServer();
void startServer(int port);
void startClient(const estr& hostname,int port);

#endif

