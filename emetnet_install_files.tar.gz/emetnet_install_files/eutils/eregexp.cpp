#include "eregexp.h"

#include "logger.h"
#include "evar.h"

eregexp refloat("^-?[0-9]*\\.?[0-9]+([eE]-?[0-9]+)?([ 	]+|$)");
eregexp reint("^-?[0-9]+([ 	]+|$)");



#ifdef EUTILS_HAVE_REGEX
eregexp::eregexp(): nmatch(1),pmatch(0x00),compiled(false)
{
 pmatch = new regmatch_t[nmatch];
}
#else
eregexp::eregexp(): compiled(false)
{
}
#endif

#ifdef EUTILS_HAVE_REGEX
eregexp::eregexp(const estr &str): nmatch(1),pmatch(0x00),compiled(false)
{
 pmatch = new regmatch_t[nmatch];
 if (str.len())
   compile(str);
}
#else
eregexp::eregexp(const estr& str): compiled(false)
{
}
#endif

#ifdef EUTILS_HAVE_REGEX
eregexp::eregexp(const estr &str,int _nmatch): nmatch(_nmatch),pmatch(0x00),compiled(false)
{
 pmatch = new regmatch_t[nmatch];
 if (str.len())
   compile(str);
}
#else
eregexp::eregexp(const estr& str,int _nmatch): compiled(false)
{
}
#endif


eregexp::~eregexp()
{
#ifdef EUTILS_HAVE_REGEX
  if (compiled){
    regfree(&reg);
    compiled=false;
  }
  if (pmatch){
    delete pmatch;
    pmatch=0x00;
  }
#endif
}

void eregexp::compile(const estr &matchstr, int cflags)
{
#ifdef EUTILS_HAVE_REGEX
  if (compiled){
    regfree(&reg);
    compiled=false;
  }
  cflags = cflags | REG_EXTENDED;
  compiled=true;
  ldieif(regcomp(&reg,matchstr._str,cflags),"error compiling regex: "+matchstr);
#endif
}

#define dcheck(a,b) dieif(a,b)

int eregexp::match(const estr &text, int pos, int eflags)
{
#ifdef EUTILS_HAVE_REGEX
  lderrorif(pos>text.len(),"eregexp: pos is bigger than string size");

  if (pos==text.len()) { b=-1; e=-1; return(-1); }

  int res;
  res = regexec(&reg,&text._str[pos],nmatch,pmatch,eflags);
  if (res==REG_NOMATCH){ b=-1; e=-1; return(-1); }
  
  if (res==0){
    b=pos+pmatch[0].rm_so;
    e=pos+pmatch[0].rm_eo;
    return(pos+pmatch[0].rm_so);
  }
  else{
    b=-1; e=-1;
    lerror("eregexp: error matching pattern");
    return(-1);
  }
#else
  ldie("regular expressions not compiled!!!");
  return(-1);
#endif

}

int re_strpos(const estr &haystack,eregexp &needle,int pos)
{
  return(needle.match(haystack,pos));
}

void re_match(const estr &str,eregexp &match,estr& res,int pos)
{
  match.match(str,pos);
  if (match.b==-1) return;
  res=str.substr(match.b,match.e-match.b);
}


estr re_match(const estr &str,eregexp &match,int pos)
{
  match.match(str,pos);
  if (match.b==-1) return("");
  return(str.substr(match.b,match.e-match.b));
}

estrarray re_explode(const estr &str,eregexp &re)
{
  estrarray res;
  int i,k;

  k=0;
  i=re.match(str);
  while (i!=-1 && i<str.len()){
    if (i!=k)
      res.add(str.substr(k,i-k));
//  cout << str.substr(k,i-k) << endl;
//  cout << "re.b: "<< re.b <<" ,re.e: "<<re.e<<endl;
    k=re.e;
    i=re.match(str,re.e);
  }
  
  res.add(str.substr(k));
  return(res);
}

estrarray &mre_explode(const estr &str,eregexp &re,estrarray &list)
{
  int i,k;
  list.clear();

  k=0;
  i=re.match(str);
  while (i!=-1 && i<str.len()){
    list.add(str.substr(k,i-k));
//  cout << "re.b: "<< re.b <<" ,re.e: "<<re.e<<endl;
    k=re.e;
    i=re.match(str,re.e);
  }
  
  list.add(str.substr(k));

  return(list);
}

estr re_replace(const estr &str,eregexp &re,const estr &replace)
{
  estr res;
  int i,k;

  k=0;
  i=re.match(str);
  while (i!=-1 && i<str.len()){
    res += str.substr(k,i-k);
    res += replace;
//    cout << str.substr(k,i-k) << endl;
//    cout << "re.b: "<< re.b <<" ,re.e: "<<re.e<<endl;
    k=re.e;
    i=re.match(str,re.e);
  }
  res += str.substr(k);
  return(res);
}

