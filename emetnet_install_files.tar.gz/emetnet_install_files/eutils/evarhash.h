#ifndef __EVARHASH__
#define __EVARHASH__

#include "eutils.h"
#include "ehashmap.h"

class evar;

typedef estrhashof<evar> evarhash;

#endif

