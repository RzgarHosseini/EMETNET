#ifndef _BUFFER_
#define _BUFFER_

#include "eutils-config.h"

const int BUFFER_ALLOC_SIZE = 1024;

class cbuffer
{
 public:
  int bsize;
  int bindex;
  char *fbuffer;

  inline char *buf()
    { return(&buffer[bindex]); }
  inline int  bleft()
    { return(size-bindex); }
  inline void wrote(int length)
    { if (length>0) bindex+=length; if (bindex==bsize) expand(); }
  inline void clear()
    { bindex=0; }
  inline void expand()
    { bsize+=BUFFER_ALLOC_SIZE; fbuffer=(char*)realloc(fbuffer,bsize); }

  cbuffer(int size);
  ~cbuffer();
}

#endif
