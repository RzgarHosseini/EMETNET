#ifndef __EQUATERNION__
#define __EQUATERNION__

#include "eutils.h"

#include "vector3.h"
#include "matrix3.h"

class equaternion
{
 public:
  float x,y,z,w;

  equaternion();
  equaternion(float angle,evector3 vector);
  equaternion(float x,float y, float z, float w);

  float len();
  
  equaternion rotate(float angle,evector3 vector);
  equaternion rotatef(float angle,float x, float y, float z);

  evector3 ux();
  evector3 uy();
  evector3 uz();
  evector3 vec();

  equaternion operator *(equaternion a);

  void normalize();
  equaternion unit();
  equaternion conj();
  
  equaternion operator +(equaternion a);
  equaternion operator -(equaternion a);

  equaternion operator +=(equaternion a);
  equaternion operator -=(equaternion a);

  equaternion operator *(float a);
  equaternion operator /(float a);


  equaternion operator *(evector3 a);

  ematrix3 mRotation();
  
  evector3 spherical();
};

equaternion qSpherical(float lon, float lat, float angle);
equaternion qCartesian(evector3 vec);

#endif

