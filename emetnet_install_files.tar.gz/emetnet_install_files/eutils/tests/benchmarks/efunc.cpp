#include <eutils/efunc.h>
#include <eutils/etimer.h>
#include <iomanip>

int callfunc(int i)
{
  return(i*i);
}

int main()
{
  int i,i2;
  double ti,tm;
  etimer t1,t2;

  t1.reset();

  t2.reset();
  for (i=0; i<1000000; ++i){
  }
  ti=t2.lap();
  cout << "1000000 cycle takes: "<<setprecision(12)<<ti<<"msecs"<< endl;

  t2.reset();
  for (i=0; i<1000000; ++i){
    t1.lap();
  }
  tm=t2.lap();
  cout << "1000000 measurements takes: "<<setprecision(12)<<tm<<"msecs"<< endl;


  t2.reset();
  for (i=0; i<1000000; ++i){
    callfunc(i);
  }
  tm=t2.lap();
  cout << "1000000 direct call takes: "<<setprecision(12)<<tm<<"msecs"<< endl;

  int (*pfunc)(int) = callfunc;

  t2.reset();
  for (i=0; i<1000000; ++i){
    (*pfunc)(i);
  }
  tm=t2.lap();
  cout << "1000000 pointer func call takes: "<<setprecision(12)<<tm<<"msecs"<< endl;

  efunc f=callfunc;

  t2.reset();
  for (i=0; i<1000000; ++i){
    f(i);
  }
  tm=t2.lap();
  cout << "1000000 efunc call takes: "<<setprecision(12)<<tm<<"msecs"<< endl;

  return(0);
}
