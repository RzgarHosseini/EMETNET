#ifndef ESOCKET_H
#define ESOCKET_H

#include "eutils.h"

#ifdef _WIN32
 #include <winsock2.h>
 #include <windows.h>
#else
 #include <sys/socket.h>
 #include <sys/types.h>
 #include <netinet/in.h>
 #include <netdb.h>
#endif

#include "estr.h"
#include "earray.h"

#include "efunc.h"


class eudpsocket
{
 public:
  int                fhsock;
  struct sockaddr_in faddr_in;
  estr               faddress;
  int                fport;
#ifdef _WIN32
  WSAEVENT wsaEvent;
#endif

  efunc onReceive;
  efunc onClose;

  eudpsocket();
  eudpsocket(int hsock,struct sockaddr_in addr_in);
  virtual ~eudpsocket();

  void setCallback();

//  bool connect(const estr& address,int port);
  bool listen(int port,const estr& address="0.0.0.0",bool reuseAddress=false);
  void close();
  void shutdown();

  void setBroadcast(bool value);
  void setReuseAddress(bool value);
  void setBlocking(bool value);

  // user defined functions
  virtual void doClose();
  virtual void doRecv();
  virtual void doSend();

  // internal functions
  void _doRecv();
  void _doClose();

  bool sendto(const estr& data,const estr& address,int port);
  int recvfrom(estr& data,estr& address,int& port);

/*
  int recv(estr& buffer);

  inline int recv(char *buffer, int len,int flags=0){
    return(::recv(fhsock,buffer,len,flags));
  }

  inline int send(const estr& buffer){
    return(send(buffer._str,buffer.len()));
  }

  inline int send(char *buffer, int len, int flags=0){
    return(::send(fhsock,buffer,len,flags));
  }
*/
};

class esocket
{
 public:
  int                fhsock;
  struct sockaddr_in faddr_in;
  estr               faddress;
  int                fport;
#ifdef _WIN32
  WSAEVENT wsaEvent;
#endif

  efunc onReceive;
  efunc onClose;

  esocket();
  esocket(int hsock,struct sockaddr_in addr_in);
  virtual ~esocket();

  void init();
  void setCallback();

  bool connect(const estr& address,int port);
  void close();
  void shutdown();

  void setBlocking(bool value);

  // user defined functions
  virtual void doClose();
  virtual void doRecv();
  virtual void doSend();

  // internal functions
  void _doRecv();
  void _doClose();

  int recv(estr& buffer);

  inline int recv(char *buffer, int len,int flags=0){
    return(::recv(fhsock,buffer,len,flags));
  }

  inline int send(const estr& buffer){
    return(send(buffer._str,buffer.len()));
  }

  inline int send(char *buffer, int len, int flags=0){
    return(::send(fhsock,buffer,len,flags));
  }
};

class eserver
{
 public:
  int                fhsock;
  struct sockaddr_in faddr_in;
  estr               faddress;
  int                fport;
#ifdef _WIN32
  WSAEVENT wsaEvent;
#endif


  efunc onIncoming;

  earray<esocket> sockets;

  eserver();
  virtual ~eserver();
 
  void close();

  virtual void doAccept();
  virtual void doIncoming();
  bool listen(int port,const estr& address="0.0.0.0");

  esocket *accept();
  bool accept(esocket &socket);
};

#endif
