#include "efuncbase.h"

efuncBase::efuncBase(): pcount(0) {}
efuncBase::~efuncBase() {}

