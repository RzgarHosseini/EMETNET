
#include "estrhashof.h"

#include "estr.h"
#include "ehashfunc.h"

unsigned int estr_oaat_hash(const estr& str)
{ return(oaat_hash(str._str,str.len())); }

unsigned int estr_lookup3_hash(const estr& str)
{ return(hashlittle(str._str,str.len(),0x75483842)); }

unsigned int estr_sf_hash(const estr& str)
{ return(SuperFastHash(str._str,str.len())); }

template <>
void estrhashof<evar>::addvar(evar& evarkey,evar& var)
{
  add(evarkey.get<estr>(),var);
}
